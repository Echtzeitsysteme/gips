// Generated from LogicNGPseudoBoolean.g4 by ANTLR 4.9.3

  package org.logicng.io.parsers;

  import java.util.LinkedHashSet;
  import org.logicng.formulas.*;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class LogicNGPseudoBooleanParser extends ParserWithFormula {
	static { RuntimeMetaData.checkVersion("4.9.3", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		NUMBER=1, LITERAL=2, TRUE=3, FALSE=4, LBR=5, RBR=6, NOT=7, AND=8, OR=9, 
		IMPL=10, EQUIV=11, MUL=12, ADD=13, EQ=14, LE=15, LT=16, GE=17, GT=18, 
		WS=19;
	public static final int
		RULE_formula = 0, RULE_constant = 1, RULE_comparison = 2, RULE_simp = 3, 
		RULE_lit = 4, RULE_conj = 5, RULE_disj = 6, RULE_impl = 7, RULE_equiv = 8, 
		RULE_mul = 9, RULE_add = 10;
	private static String[] makeRuleNames() {
		return new String[] {
			"formula", "constant", "comparison", "simp", "lit", "conj", "disj", "impl", 
			"equiv", "mul", "add"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, "'$true'", "'$false'", "'('", "')'", "'~'", "'&'", 
			"'|'", "'=>'", "'<=>'", "'*'", null, "'='", "'<='", "'<'", "'>='", "'>'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "NUMBER", "LITERAL", "TRUE", "FALSE", "LBR", "RBR", "NOT", "AND", 
			"OR", "IMPL", "EQUIV", "MUL", "ADD", "EQ", "LE", "LT", "GE", "GT", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "LogicNGPseudoBoolean.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }


	  public Formula getParsedFormula() {
	    return formula().f;
	  }

	public LogicNGPseudoBooleanParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class FormulaContext extends ParserRuleContext {
		public Formula f;
		public EquivContext equiv;
		public TerminalNode EOF() { return getToken(LogicNGPseudoBooleanParser.EOF, 0); }
		public EquivContext equiv() {
			return getRuleContext(EquivContext.class,0);
		}
		public FormulaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formula; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterFormula(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitFormula(this);
		}
	}

	public final FormulaContext formula() throws RecognitionException {
		FormulaContext _localctx = new FormulaContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_formula);
		try {
			setState(28);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EOF:
				enterOuterAlt(_localctx, 1);
				{
				setState(22);
				match(EOF);
				((FormulaContext)_localctx).f =  f.verum();
				}
				break;
			case NUMBER:
			case LITERAL:
			case TRUE:
			case FALSE:
			case LBR:
			case NOT:
				enterOuterAlt(_localctx, 2);
				{
				setState(24);
				((FormulaContext)_localctx).equiv = equiv();
				setState(25);
				match(EOF);
				((FormulaContext)_localctx).f =  ((FormulaContext)_localctx).equiv.f;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConstantContext extends ParserRuleContext {
		public Formula f;
		public TerminalNode TRUE() { return getToken(LogicNGPseudoBooleanParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(LogicNGPseudoBooleanParser.FALSE, 0); }
		public ConstantContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constant; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterConstant(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitConstant(this);
		}
	}

	public final ConstantContext constant() throws RecognitionException {
		ConstantContext _localctx = new ConstantContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_constant);
		try {
			setState(34);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TRUE:
				enterOuterAlt(_localctx, 1);
				{
				setState(30);
				match(TRUE);
				((ConstantContext)_localctx).f =  f.verum();
				}
				break;
			case FALSE:
				enterOuterAlt(_localctx, 2);
				{
				setState(32);
				match(FALSE);
				((ConstantContext)_localctx).f =  f.falsum();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ComparisonContext extends ParserRuleContext {
		public Formula f;
		public AddContext e;
		public Token n;
		public TerminalNode EQ() { return getToken(LogicNGPseudoBooleanParser.EQ, 0); }
		public AddContext add() {
			return getRuleContext(AddContext.class,0);
		}
		public TerminalNode NUMBER() { return getToken(LogicNGPseudoBooleanParser.NUMBER, 0); }
		public TerminalNode LE() { return getToken(LogicNGPseudoBooleanParser.LE, 0); }
		public TerminalNode LT() { return getToken(LogicNGPseudoBooleanParser.LT, 0); }
		public TerminalNode GE() { return getToken(LogicNGPseudoBooleanParser.GE, 0); }
		public TerminalNode GT() { return getToken(LogicNGPseudoBooleanParser.GT, 0); }
		public ComparisonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparison; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitComparison(this);
		}
	}

	public final ComparisonContext comparison() throws RecognitionException {
		ComparisonContext _localctx = new ComparisonContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_comparison);
		try {
			setState(61);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(36);
				((ComparisonContext)_localctx).e = add();
				setState(37);
				match(EQ);
				setState(38);
				((ComparisonContext)_localctx).n = match(NUMBER);
				((ComparisonContext)_localctx).f =  f.pbc(CType.EQ, Integer.parseInt((((ComparisonContext)_localctx).n!=null?((ComparisonContext)_localctx).n.getText():null)), ((ComparisonContext)_localctx).e.literals, ((ComparisonContext)_localctx).e.coeffs);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(41);
				((ComparisonContext)_localctx).e = add();
				setState(42);
				match(LE);
				setState(43);
				((ComparisonContext)_localctx).n = match(NUMBER);
				((ComparisonContext)_localctx).f =  f.pbc(CType.LE, Integer.parseInt((((ComparisonContext)_localctx).n!=null?((ComparisonContext)_localctx).n.getText():null)), ((ComparisonContext)_localctx).e.literals, ((ComparisonContext)_localctx).e.coeffs);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(46);
				((ComparisonContext)_localctx).e = add();
				setState(47);
				match(LT);
				setState(48);
				((ComparisonContext)_localctx).n = match(NUMBER);
				((ComparisonContext)_localctx).f =  f.pbc(CType.LT, Integer.parseInt((((ComparisonContext)_localctx).n!=null?((ComparisonContext)_localctx).n.getText():null)), ((ComparisonContext)_localctx).e.literals, ((ComparisonContext)_localctx).e.coeffs);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(51);
				((ComparisonContext)_localctx).e = add();
				setState(52);
				match(GE);
				setState(53);
				((ComparisonContext)_localctx).n = match(NUMBER);
				((ComparisonContext)_localctx).f =  f.pbc(CType.GE, Integer.parseInt((((ComparisonContext)_localctx).n!=null?((ComparisonContext)_localctx).n.getText():null)), ((ComparisonContext)_localctx).e.literals, ((ComparisonContext)_localctx).e.coeffs);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(56);
				((ComparisonContext)_localctx).e = add();
				setState(57);
				match(GT);
				setState(58);
				((ComparisonContext)_localctx).n = match(NUMBER);
				((ComparisonContext)_localctx).f =  f.pbc(CType.GT, Integer.parseInt((((ComparisonContext)_localctx).n!=null?((ComparisonContext)_localctx).n.getText():null)), ((ComparisonContext)_localctx).e.literals, ((ComparisonContext)_localctx).e.coeffs);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SimpContext extends ParserRuleContext {
		public Formula f;
		public Token NUMBER;
		public Token LITERAL;
		public ConstantContext constant;
		public ComparisonContext comparison;
		public EquivContext equiv;
		public TerminalNode NUMBER() { return getToken(LogicNGPseudoBooleanParser.NUMBER, 0); }
		public TerminalNode LITERAL() { return getToken(LogicNGPseudoBooleanParser.LITERAL, 0); }
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public ComparisonContext comparison() {
			return getRuleContext(ComparisonContext.class,0);
		}
		public TerminalNode LBR() { return getToken(LogicNGPseudoBooleanParser.LBR, 0); }
		public EquivContext equiv() {
			return getRuleContext(EquivContext.class,0);
		}
		public TerminalNode RBR() { return getToken(LogicNGPseudoBooleanParser.RBR, 0); }
		public SimpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterSimp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitSimp(this);
		}
	}

	public final SimpContext simp() throws RecognitionException {
		SimpContext _localctx = new SimpContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_simp);
		try {
			setState(78);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(63);
				((SimpContext)_localctx).NUMBER = match(NUMBER);
				((SimpContext)_localctx).f =  ((((SimpContext)_localctx).NUMBER!=null?((SimpContext)_localctx).NUMBER.getText():null).startsWith("~") ? f.literal((((SimpContext)_localctx).NUMBER!=null?((SimpContext)_localctx).NUMBER.getText():null).substring(1, (((SimpContext)_localctx).NUMBER!=null?((SimpContext)_localctx).NUMBER.getText():null).length()), false) : f.literal((((SimpContext)_localctx).NUMBER!=null?((SimpContext)_localctx).NUMBER.getText():null), true));
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(65);
				((SimpContext)_localctx).LITERAL = match(LITERAL);
				((SimpContext)_localctx).f =  ((((SimpContext)_localctx).LITERAL!=null?((SimpContext)_localctx).LITERAL.getText():null).startsWith("~") ? f.literal((((SimpContext)_localctx).LITERAL!=null?((SimpContext)_localctx).LITERAL.getText():null).substring(1, (((SimpContext)_localctx).LITERAL!=null?((SimpContext)_localctx).LITERAL.getText():null).length()), false) : f.literal((((SimpContext)_localctx).LITERAL!=null?((SimpContext)_localctx).LITERAL.getText():null), true));
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(67);
				((SimpContext)_localctx).constant = constant();
				((SimpContext)_localctx).f =  ((SimpContext)_localctx).constant.f;
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(70);
				((SimpContext)_localctx).comparison = comparison();
				((SimpContext)_localctx).f =  ((SimpContext)_localctx).comparison.f;
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(73);
				match(LBR);
				setState(74);
				((SimpContext)_localctx).equiv = equiv();
				setState(75);
				match(RBR);
				((SimpContext)_localctx).f =  ((SimpContext)_localctx).equiv.f;
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LitContext extends ParserRuleContext {
		public Formula f;
		public LitContext a;
		public SimpContext simp;
		public TerminalNode NOT() { return getToken(LogicNGPseudoBooleanParser.NOT, 0); }
		public LitContext lit() {
			return getRuleContext(LitContext.class,0);
		}
		public SimpContext simp() {
			return getRuleContext(SimpContext.class,0);
		}
		public LitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lit; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterLit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitLit(this);
		}
	}

	public final LitContext lit() throws RecognitionException {
		LitContext _localctx = new LitContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_lit);
		try {
			setState(87);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOT:
				enterOuterAlt(_localctx, 1);
				{
				setState(80);
				match(NOT);
				setState(81);
				((LitContext)_localctx).a = lit();
				((LitContext)_localctx).f =  f.not(((LitContext)_localctx).a.f);
				}
				break;
			case NUMBER:
			case LITERAL:
			case TRUE:
			case FALSE:
			case LBR:
				enterOuterAlt(_localctx, 2);
				{
				setState(84);
				((LitContext)_localctx).simp = simp();
				((LitContext)_localctx).f =  ((LitContext)_localctx).simp.f;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConjContext extends ParserRuleContext {
		public Formula f;
		public LitContext a;
		public LitContext b;
		public List<LitContext> lit() {
			return getRuleContexts(LitContext.class);
		}
		public LitContext lit(int i) {
			return getRuleContext(LitContext.class,i);
		}
		public List<TerminalNode> AND() { return getTokens(LogicNGPseudoBooleanParser.AND); }
		public TerminalNode AND(int i) {
			return getToken(LogicNGPseudoBooleanParser.AND, i);
		}
		public ConjContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conj; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterConj(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitConj(this);
		}
	}

	public final ConjContext conj() throws RecognitionException {
		ConjContext _localctx = new ConjContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_conj);
		LinkedHashSet<Formula> literals = new LinkedHashSet<>(); 
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			((ConjContext)_localctx).a = lit();
			literals.add(((ConjContext)_localctx).a.f);
			setState(97);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AND) {
				{
				{
				setState(91);
				match(AND);
				setState(92);
				((ConjContext)_localctx).b = lit();
				literals.add(((ConjContext)_localctx).b.f);
				}
				}
				setState(99);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			((ConjContext)_localctx).f =  f.and(literals);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DisjContext extends ParserRuleContext {
		public Formula f;
		public ConjContext a;
		public ConjContext b;
		public List<ConjContext> conj() {
			return getRuleContexts(ConjContext.class);
		}
		public ConjContext conj(int i) {
			return getRuleContext(ConjContext.class,i);
		}
		public List<TerminalNode> OR() { return getTokens(LogicNGPseudoBooleanParser.OR); }
		public TerminalNode OR(int i) {
			return getToken(LogicNGPseudoBooleanParser.OR, i);
		}
		public DisjContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_disj; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterDisj(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitDisj(this);
		}
	}

	public final DisjContext disj() throws RecognitionException {
		DisjContext _localctx = new DisjContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_disj);
		LinkedHashSet<Formula> conjunctions = new LinkedHashSet<>();
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(102);
			((DisjContext)_localctx).a = conj();
			conjunctions.add(((DisjContext)_localctx).a.f);
			setState(110);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==OR) {
				{
				{
				setState(104);
				match(OR);
				setState(105);
				((DisjContext)_localctx).b = conj();
				conjunctions.add(((DisjContext)_localctx).b.f);
				}
				}
				setState(112);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			((DisjContext)_localctx).f =  f.or(conjunctions);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImplContext extends ParserRuleContext {
		public Formula f;
		public DisjContext a;
		public ImplContext b;
		public DisjContext disj() {
			return getRuleContext(DisjContext.class,0);
		}
		public TerminalNode IMPL() { return getToken(LogicNGPseudoBooleanParser.IMPL, 0); }
		public ImplContext impl() {
			return getRuleContext(ImplContext.class,0);
		}
		public ImplContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_impl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterImpl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitImpl(this);
		}
	}

	public final ImplContext impl() throws RecognitionException {
		ImplContext _localctx = new ImplContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_impl);
		Formula[] operands = new Formula[2];
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115);
			((ImplContext)_localctx).a = disj();
			operands[0] =((ImplContext)_localctx).a.f;
			setState(121);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==IMPL) {
				{
				setState(117);
				match(IMPL);
				setState(118);
				((ImplContext)_localctx).b = impl();
				operands[1] = ((ImplContext)_localctx).b.f;
				}
			}

			((ImplContext)_localctx).f =  operands[1] == null ? operands[0] : f.implication(operands[0], operands[1]);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EquivContext extends ParserRuleContext {
		public Formula f;
		public ImplContext a;
		public EquivContext b;
		public ImplContext impl() {
			return getRuleContext(ImplContext.class,0);
		}
		public TerminalNode EQUIV() { return getToken(LogicNGPseudoBooleanParser.EQUIV, 0); }
		public EquivContext equiv() {
			return getRuleContext(EquivContext.class,0);
		}
		public EquivContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_equiv; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterEquiv(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitEquiv(this);
		}
	}

	public final EquivContext equiv() throws RecognitionException {
		EquivContext _localctx = new EquivContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_equiv);
		Formula[] operands = new Formula[2];
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(125);
			((EquivContext)_localctx).a = impl();
			operands[0] =((EquivContext)_localctx).a.f;
			setState(131);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==EQUIV) {
				{
				setState(127);
				match(EQUIV);
				setState(128);
				((EquivContext)_localctx).b = equiv();
				operands[1] = ((EquivContext)_localctx).b.f;
				}
			}

			((EquivContext)_localctx).f =  operands[1] == null ? operands[0] : f.equivalence(operands[0], operands[1]);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MulContext extends ParserRuleContext {
		public Literal l;
		public int c;
		public Token LITERAL;
		public Token NUMBER;
		public Token num;
		public Token lt;
		public TerminalNode LITERAL() { return getToken(LogicNGPseudoBooleanParser.LITERAL, 0); }
		public List<TerminalNode> NUMBER() { return getTokens(LogicNGPseudoBooleanParser.NUMBER); }
		public TerminalNode NUMBER(int i) {
			return getToken(LogicNGPseudoBooleanParser.NUMBER, i);
		}
		public TerminalNode MUL() { return getToken(LogicNGPseudoBooleanParser.MUL, 0); }
		public MulContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mul; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterMul(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitMul(this);
		}
	}

	public final MulContext mul() throws RecognitionException {
		MulContext _localctx = new MulContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_mul);
		try {
			setState(147);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(135);
				((MulContext)_localctx).LITERAL = match(LITERAL);
				((MulContext)_localctx).l =  ((((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null).startsWith("~") ? f.literal((((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null).substring(1, (((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null).length()), false) : f.literal((((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null), true)); ((MulContext)_localctx).c =  1;
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(137);
				((MulContext)_localctx).NUMBER = match(NUMBER);
				((MulContext)_localctx).l =  f.literal((((MulContext)_localctx).NUMBER!=null?((MulContext)_localctx).NUMBER.getText():null), true); ((MulContext)_localctx).c =  1;
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(139);
				((MulContext)_localctx).NUMBER = match(NUMBER);
				setState(140);
				match(MUL);
				setState(141);
				((MulContext)_localctx).LITERAL = match(LITERAL);
				((MulContext)_localctx).l =  ((((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null).startsWith("~") ? f.literal((((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null).substring(1, (((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null).length()), false) : f.literal((((MulContext)_localctx).LITERAL!=null?((MulContext)_localctx).LITERAL.getText():null), true)); ((MulContext)_localctx).c =  Integer.parseInt((((MulContext)_localctx).NUMBER!=null?((MulContext)_localctx).NUMBER.getText():null));
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(143);
				((MulContext)_localctx).num = match(NUMBER);
				setState(144);
				match(MUL);
				setState(145);
				((MulContext)_localctx).lt = match(NUMBER);
				((MulContext)_localctx).l =  f.literal((((MulContext)_localctx).lt!=null?((MulContext)_localctx).lt.getText():null), true); ((MulContext)_localctx).c =  Integer.parseInt((((MulContext)_localctx).num!=null?((MulContext)_localctx).num.getText():null));
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AddContext extends ParserRuleContext {
		public List<Literal> literals;
		public List<Integer> coeffs;
		public MulContext m1;
		public Token ADD;
		public MulContext m2;
		public List<MulContext> mul() {
			return getRuleContexts(MulContext.class);
		}
		public MulContext mul(int i) {
			return getRuleContext(MulContext.class,i);
		}
		public List<TerminalNode> ADD() { return getTokens(LogicNGPseudoBooleanParser.ADD); }
		public TerminalNode ADD(int i) {
			return getToken(LogicNGPseudoBooleanParser.ADD, i);
		}
		public AddContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_add; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).enterAdd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LogicNGPseudoBooleanListener ) ((LogicNGPseudoBooleanListener)listener).exitAdd(this);
		}
	}

	public final AddContext add() throws RecognitionException {
		AddContext _localctx = new AddContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_add);
		((AddContext)_localctx).literals =  new ArrayList<>(); ((AddContext)_localctx).coeffs =  new ArrayList<>();
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(149);
			((AddContext)_localctx).m1 = mul();
			_localctx.literals.add(((AddContext)_localctx).m1.l); _localctx.coeffs.add(((AddContext)_localctx).m1.c);
			setState(157);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ADD) {
				{
				{
				setState(151);
				((AddContext)_localctx).ADD = match(ADD);
				setState(152);
				((AddContext)_localctx).m2 = mul();
				_localctx.literals.add(((AddContext)_localctx).m2.l); _localctx.coeffs.add((((AddContext)_localctx).ADD!=null?((AddContext)_localctx).ADD.getText():null).equals("+") ? ((AddContext)_localctx).m2.c : -((AddContext)_localctx).m2.c);
				}
				}
				setState(159);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\25\u00a3\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\3\2\3\2\3\2\3\2\3\2\3\2\5\2\37\n\2\3\3\3\3\3\3\3\3\5\3%"+
		"\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4@\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3"+
		"\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\5\5Q\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3"+
		"\6\5\6Z\n\6\3\7\3\7\3\7\3\7\3\7\3\7\7\7b\n\7\f\7\16\7e\13\7\3\7\3\7\3"+
		"\b\3\b\3\b\3\b\3\b\3\b\7\bo\n\b\f\b\16\br\13\b\3\b\3\b\3\t\3\t\3\t\3\t"+
		"\3\t\3\t\5\t|\n\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\n\5\n\u0086\n\n\3\n\3"+
		"\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\5\13\u0096"+
		"\n\13\3\f\3\f\3\f\3\f\3\f\3\f\7\f\u009e\n\f\f\f\16\f\u00a1\13\f\3\f\2"+
		"\2\r\2\4\6\b\n\f\16\20\22\24\26\2\2\2\u00aa\2\36\3\2\2\2\4$\3\2\2\2\6"+
		"?\3\2\2\2\bP\3\2\2\2\nY\3\2\2\2\f[\3\2\2\2\16h\3\2\2\2\20u\3\2\2\2\22"+
		"\177\3\2\2\2\24\u0095\3\2\2\2\26\u0097\3\2\2\2\30\31\7\2\2\3\31\37\b\2"+
		"\1\2\32\33\5\22\n\2\33\34\7\2\2\3\34\35\b\2\1\2\35\37\3\2\2\2\36\30\3"+
		"\2\2\2\36\32\3\2\2\2\37\3\3\2\2\2 !\7\5\2\2!%\b\3\1\2\"#\7\6\2\2#%\b\3"+
		"\1\2$ \3\2\2\2$\"\3\2\2\2%\5\3\2\2\2&\'\5\26\f\2\'(\7\20\2\2()\7\3\2\2"+
		")*\b\4\1\2*@\3\2\2\2+,\5\26\f\2,-\7\21\2\2-.\7\3\2\2./\b\4\1\2/@\3\2\2"+
		"\2\60\61\5\26\f\2\61\62\7\22\2\2\62\63\7\3\2\2\63\64\b\4\1\2\64@\3\2\2"+
		"\2\65\66\5\26\f\2\66\67\7\23\2\2\678\7\3\2\289\b\4\1\29@\3\2\2\2:;\5\26"+
		"\f\2;<\7\24\2\2<=\7\3\2\2=>\b\4\1\2>@\3\2\2\2?&\3\2\2\2?+\3\2\2\2?\60"+
		"\3\2\2\2?\65\3\2\2\2?:\3\2\2\2@\7\3\2\2\2AB\7\3\2\2BQ\b\5\1\2CD\7\4\2"+
		"\2DQ\b\5\1\2EF\5\4\3\2FG\b\5\1\2GQ\3\2\2\2HI\5\6\4\2IJ\b\5\1\2JQ\3\2\2"+
		"\2KL\7\7\2\2LM\5\22\n\2MN\7\b\2\2NO\b\5\1\2OQ\3\2\2\2PA\3\2\2\2PC\3\2"+
		"\2\2PE\3\2\2\2PH\3\2\2\2PK\3\2\2\2Q\t\3\2\2\2RS\7\t\2\2ST\5\n\6\2TU\b"+
		"\6\1\2UZ\3\2\2\2VW\5\b\5\2WX\b\6\1\2XZ\3\2\2\2YR\3\2\2\2YV\3\2\2\2Z\13"+
		"\3\2\2\2[\\\5\n\6\2\\c\b\7\1\2]^\7\n\2\2^_\5\n\6\2_`\b\7\1\2`b\3\2\2\2"+
		"a]\3\2\2\2be\3\2\2\2ca\3\2\2\2cd\3\2\2\2df\3\2\2\2ec\3\2\2\2fg\b\7\1\2"+
		"g\r\3\2\2\2hi\5\f\7\2ip\b\b\1\2jk\7\13\2\2kl\5\f\7\2lm\b\b\1\2mo\3\2\2"+
		"\2nj\3\2\2\2or\3\2\2\2pn\3\2\2\2pq\3\2\2\2qs\3\2\2\2rp\3\2\2\2st\b\b\1"+
		"\2t\17\3\2\2\2uv\5\16\b\2v{\b\t\1\2wx\7\f\2\2xy\5\20\t\2yz\b\t\1\2z|\3"+
		"\2\2\2{w\3\2\2\2{|\3\2\2\2|}\3\2\2\2}~\b\t\1\2~\21\3\2\2\2\177\u0080\5"+
		"\20\t\2\u0080\u0085\b\n\1\2\u0081\u0082\7\r\2\2\u0082\u0083\5\22\n\2\u0083"+
		"\u0084\b\n\1\2\u0084\u0086\3\2\2\2\u0085\u0081\3\2\2\2\u0085\u0086\3\2"+
		"\2\2\u0086\u0087\3\2\2\2\u0087\u0088\b\n\1\2\u0088\23\3\2\2\2\u0089\u008a"+
		"\7\4\2\2\u008a\u0096\b\13\1\2\u008b\u008c\7\3\2\2\u008c\u0096\b\13\1\2"+
		"\u008d\u008e\7\3\2\2\u008e\u008f\7\16\2\2\u008f\u0090\7\4\2\2\u0090\u0096"+
		"\b\13\1\2\u0091\u0092\7\3\2\2\u0092\u0093\7\16\2\2\u0093\u0094\7\3\2\2"+
		"\u0094\u0096\b\13\1\2\u0095\u0089\3\2\2\2\u0095\u008b\3\2\2\2\u0095\u008d"+
		"\3\2\2\2\u0095\u0091\3\2\2\2\u0096\25\3\2\2\2\u0097\u0098\5\24\13\2\u0098"+
		"\u009f\b\f\1\2\u0099\u009a\7\17\2\2\u009a\u009b\5\24\13\2\u009b\u009c"+
		"\b\f\1\2\u009c\u009e\3\2\2\2\u009d\u0099\3\2\2\2\u009e\u00a1\3\2\2\2\u009f"+
		"\u009d\3\2\2\2\u009f\u00a0\3\2\2\2\u00a0\27\3\2\2\2\u00a1\u009f\3\2\2"+
		"\2\r\36$?PYcp{\u0085\u0095\u009f";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}