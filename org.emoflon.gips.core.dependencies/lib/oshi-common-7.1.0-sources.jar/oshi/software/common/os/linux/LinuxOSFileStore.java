/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.linux;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.software.common.AbstractOSFileStore;
import oshi.software.os.OSFileStore;

/**
 * OSFileStore implementation
 */
@ThreadSafe
public class LinuxOSFileStore extends AbstractOSFileStore {

    private final LinuxFileSystem fs;
    private String logicalVolume;
    private String description;
    private String fsType;

    private long freeSpace;
    private long usableSpace;
    private long totalSpace;
    private long freeInodes;
    private long totalInodes;

    public LinuxOSFileStore(String name, String volume, String label, String mount, String options, String uuid,
            boolean local, String logicalVolume, String description, String fsType, long freeSpace, long usableSpace,
            long totalSpace, long freeInodes, long totalInodes, LinuxFileSystem fs) {
        super(name, volume, label, mount, options, uuid, local);
        this.fs = fs;
        this.logicalVolume = logicalVolume;
        this.description = description;
        this.fsType = fsType;
        this.freeSpace = freeSpace;
        this.usableSpace = usableSpace;
        this.totalSpace = totalSpace;
        this.freeInodes = freeInodes;
        this.totalInodes = totalInodes;
    }

    @Override
    public String getLogicalVolume() {
        return this.logicalVolume;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public String getType() {
        return this.fsType;
    }

    @Override
    public long getFreeSpace() {
        return this.freeSpace;
    }

    @Override
    public long getUsableSpace() {
        return this.usableSpace;
    }

    @Override
    public long getTotalSpace() {
        return this.totalSpace;
    }

    @Override
    public long getFreeInodes() {
        return this.freeInodes;
    }

    @Override
    public long getTotalInodes() {
        return this.totalInodes;
    }

    @Override
    public boolean updateAttributes() {
        // Fast path: query space/inode stats directly on the known mount point
        long[] vfs = fs.queryStatvfs(getMount());
        if (vfs != null) {
            long ts = vfs[2];
            long us = vfs[3];
            long frs = vfs[4];
            // If native methods failed use JVM methods
            if (ts == 0L) {
                java.io.File f = new java.io.File(getMount());
                ts = f.getTotalSpace();
                us = f.getUsableSpace();
                frs = f.getFreeSpace();
            }
            updateSpaceAndInodes(frs, us, ts, vfs[1], vfs[0]);
            return true;
        }
        // Fall back to full enumeration if the direct call failed
        for (OSFileStore fileStore : fs.getFileStoreMatching(getName(), LinuxFileSystem.buildUuidMap(), isLocal())) {
            if (getVolume().equals(fileStore.getVolume()) && getMount().equals(fileStore.getMount())) {
                updateFrom(fileStore);
                return true;
            }
        }
        return false;
    }

    private void updateSpaceAndInodes(long freeSpace, long usableSpace, long totalSpace, long freeInodes,
            long totalInodes) {
        this.freeSpace = freeSpace;
        this.usableSpace = usableSpace;
        this.totalSpace = totalSpace;
        this.freeInodes = freeInodes;
        this.totalInodes = totalInodes;
    }

    private void updateFrom(OSFileStore fileStore) {
        this.logicalVolume = fileStore.getLogicalVolume();
        this.description = fileStore.getDescription();
        this.fsType = fileStore.getType();
        this.freeSpace = fileStore.getFreeSpace();
        this.usableSpace = fileStore.getUsableSpace();
        this.totalSpace = fileStore.getTotalSpace();
        this.freeInodes = fileStore.getFreeInodes();
        this.totalInodes = fileStore.getTotalInodes();
    }
}
