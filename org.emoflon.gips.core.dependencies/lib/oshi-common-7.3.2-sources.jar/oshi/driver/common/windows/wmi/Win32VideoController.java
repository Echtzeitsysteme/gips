/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.common.windows.wmi;

import oshi.annotation.concurrent.ThreadSafe;

/**
 * Constants and property enum for WMI class {@code Win32_VideoController}.
 */
@ThreadSafe
public class Win32VideoController {

    /**
     * The WMI class name.
     */
    public static final String WIN32_VIDEO_CONTROLLER = "Win32_VideoController";

    /**
     * Video Controller properties.
     */
    public enum VideoControllerProperty {
        /** ADAPTERCOMPATIBILITY property. */
        ADAPTERCOMPATIBILITY,
        /** ADAPTERRAM property. */
        ADAPTERRAM,
        /** CONFIGMANAGERERRORCODE property. */
        CONFIGMANAGERERRORCODE,
        /** DRIVERVERSION property. */
        DRIVERVERSION,
        /** NAME property. */
        NAME,
        /** PNPDEVICEID property. */
        PNPDEVICEID
    }

    /**
     * Constructor.
     */
    protected Win32VideoController() {
    }

    /**
     * Queries video controller information.
     *
     * @param h An instantiated {@link WmiQueryExecutor}.
     * @return Video controller information.
     */
    public static WmiResult<VideoControllerProperty> queryVideoController(WmiQueryExecutor h) {
        WmiQuery<VideoControllerProperty> query = new WmiQuery<>(WIN32_VIDEO_CONTROLLER, VideoControllerProperty.class);
        return h.queryWMI(query);
    }
}
