/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.os;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.List;

import oshi.annotation.PublicApi;
import oshi.annotation.concurrent.Immutable;
import oshi.annotation.concurrent.ThreadSafe;

/**
 * Provides key statistics for TCP and UDP network protocols, including aggregate counters and per-connection details.
 * <p>
 * Use {@link #getTCPv4Stats()} and {@link #getTCPv6Stats()} for aggregate TCP counters (connections established,
 * active, passive, failures, resets, and segment counts). Use {@link #getUDPv4Stats()} and {@link #getUDPv6Stats()} for
 * aggregate UDP counters (datagrams sent, received, and errors).
 * <p>
 * Use {@link #getConnections()} to list individual active TCP and UDP connections, each represented as an
 * {@link IPConnection} with local/remote addresses, ports, state, and owning process ID.
 * <p>
 * Example: listing active TCP connections:
 *
 * <pre>{@code
 * InternetProtocolStats ipStats = os.getInternetProtocolStats();
 * for (IPConnection conn : ipStats.getConnections()) {
 *     if (conn.getType().startsWith("tcp")) {
 *         String local = addrToString(conn.getLocalAddress());
 *         String foreign = addrToString(conn.getForeignAddress());
 *         System.out.printf("%s:%d -> %s:%d (%s)%n", local, conn.getLocalPort(), foreign, conn.getForeignPort(),
 *                 conn.getState());
 *     }
 * }
 *
 * // Helper to safely convert address bytes to a string
 * static String addrToString(byte[] addr) {
 *     try {
 *         return addr.length > 0 ? InetAddress.getByAddress(addr).getHostAddress() : "*";
 *     } catch (UnknownHostException e) {
 *         return "?";
 *     }
 * }
 * }</pre>
 *
 * <b>Platform notes:</b> On macOS, connection information requires elevated permissions. Without elevated permissions,
 * TCP segment data is estimated.
 *
 * @see TcpStats
 * @see UdpStats
 * @see IPConnection
 */
@PublicApi
@ThreadSafe
public interface InternetProtocolStats {

    /**
     * Get the TCP stats for IPv4 connections.
     * <p>
     * On macOS connection information requires elevated permissions. Without elevated permissions, segment data is
     * estimated.
     *
     * @return a {@link TcpStats} object encapsulating the stats.
     */
    TcpStats getTCPv4Stats();

    /**
     * Get the TCP stats for IPv6 connections, if available. If not available separately, these may be 0 and included in
     * IPv4 connections.
     *
     * @return a {@link TcpStats} object encapsulating the stats.
     */
    TcpStats getTCPv6Stats();

    /**
     * Get the UDP stats for IPv4 datagrams.
     *
     * @return a {@link UdpStats} object encapsulating the stats.
     */
    UdpStats getUDPv4Stats();

    /**
     * Get the UDP stats for IPv6 datagrams, if available. If not available separately, these may be 0 and included in
     * IPv4 datagrams.
     *
     * @return a {@link UdpStats} object encapsulating the stats.
     */
    UdpStats getUDPv6Stats();

    /**
     * Gets a list of TCP and UDP connections.
     *
     * @return A list of {@link IPConnection} objects for TCP and UDP connections.
     */
    List<IPConnection> getConnections();

    /**
     * Encapsulates statistics associated with a TCP connection.
     */
    @PublicApi
    @Immutable
    final class TcpStats {
        private final long connectionsEstablished;
        private final long connectionsActive;
        private final long connectionsPassive;
        private final long connectionFailures;
        private final long connectionsReset;
        private final long segmentsSent;
        private final long segmentsReceived;
        private final long segmentsRetransmitted;
        private final long inErrors;
        private final long outResets;

        /**
         * Constructs a new TcpStats instance with the given counters.
         *
         * @param connectionsEstablished TCP connections currently established
         * @param connectionsActive      active connection openings
         * @param connectionsPassive     passive connection openings
         * @param connectionFailures     failed connection attempts
         * @param connectionsReset       connections reset
         * @param segmentsSent           segments sent
         * @param segmentsReceived       segments received
         * @param segmentsRetransmitted  segments retransmitted
         * @param inErrors               segments received in error
         * @param outResets              resets sent
         */
        public TcpStats(long connectionsEstablished, long connectionsActive, long connectionsPassive,
                long connectionFailures, long connectionsReset, long segmentsSent, long segmentsReceived,
                long segmentsRetransmitted, long inErrors, long outResets) {
            this.connectionsEstablished = connectionsEstablished;
            this.connectionsActive = connectionsActive;
            this.connectionsPassive = connectionsPassive;
            this.connectionFailures = connectionFailures;
            this.connectionsReset = connectionsReset;
            this.segmentsSent = segmentsSent;
            this.segmentsReceived = segmentsReceived;
            this.segmentsRetransmitted = segmentsRetransmitted;
            this.inErrors = inErrors;
            this.outResets = outResets;
        }

        /**
         * Connections Established is the number of TCP connections for which the current state is either ESTABLISHED or
         * CLOSE-WAIT
         *
         * @return the connectionsEstablished
         */
        public long getConnectionsEstablished() {
            return connectionsEstablished;
        }

        /**
         * Connections Active is the number of times TCP connections have made a direct transition to the SYN-SENT state
         * from the CLOSED state. In other words, it shows a number of connections which are initiated by the local
         * computer. The value is a cumulative total.
         *
         * @return the connectionsActive
         */
        public long getConnectionsActive() {
            return connectionsActive;
        }

        /**
         * Connections Passive is the number of times TCP connections have made a direct transition to the SYN-RCVD
         * state from the LISTEN state. In other words, it shows a number of connections to the local computer, which
         * are initiated by remote computers. The value is a cumulative total.
         *
         * @return the connectionsPassive
         */
        public long getConnectionsPassive() {
            return connectionsPassive;
        }

        /**
         * Connection Failures is the number of times TCP connections have made a direct transition to the CLOSED state
         * from the SYN-SENT state or the SYN-RCVD state, plus the number of times TCP connections have made a direct
         * transition to the LISTEN state from the SYN-RCVD state.
         *
         * @return the connectionFailures
         */
        public long getConnectionFailures() {
            return connectionFailures;
        }

        /**
         * Connections Reset is the number of times TCP connections have made a direct transition to the CLOSED state
         * from either the ESTABLISHED state or the CLOSE-WAIT state.
         *
         * @return the connectionsReset
         */
        public long getConnectionsReset() {
            return connectionsReset;
        }

        /**
         * Segments Sent is the number of segments sent, including those on current connections, but excluding those
         * containing only retransmitted bytes.
         *
         * @return the segmentsSent
         */
        public long getSegmentsSent() {
            return segmentsSent;
        }

        /**
         * Segments Received is the number of segments received, including those received in error. This count includes
         * segments received on currently established connections.
         *
         * @return the segmentsReceived
         */
        public long getSegmentsReceived() {
            return segmentsReceived;
        }

        /**
         * Segments Retransmitted is the number of segments retransmitted, that is, segments transmitted containing one
         * or more previously transmitted bytes.
         *
         * @return the segmentsRetransmitted
         */
        public long getSegmentsRetransmitted() {
            return segmentsRetransmitted;
        }

        /**
         * The number of errors received.
         *
         * @return the inErrors
         */
        public long getInErrors() {
            return inErrors;
        }

        /**
         * The number of segments transmitted with the reset flag set.
         *
         * @return the outResets
         */
        public long getOutResets() {
            return outResets;
        }

        @Override
        public String toString() {
            return "TcpStats [connectionsEstablished=" + connectionsEstablished + ", connectionsActive="
                    + connectionsActive + ", connectionsPassive=" + connectionsPassive + ", connectionFailures="
                    + connectionFailures + ", connectionsReset=" + connectionsReset + ", segmentsSent=" + segmentsSent
                    + ", segmentsReceived=" + segmentsReceived + ", segmentsRetransmitted=" + segmentsRetransmitted
                    + ", inErrors=" + inErrors + ", outResets=" + outResets + "]";
        }
    }

    /**
     * Encapsulates statistics associated with a UDP connection.
     */
    @PublicApi
    @Immutable
    final class UdpStats {
        private final long datagramsSent;
        private final long datagramsReceived;
        private final long datagramsNoPort;
        private final long datagramsReceivedErrors;

        /**
         * Constructs a new UdpStats instance with the given counters.
         *
         * @param datagramsSent           datagrams sent
         * @param datagramsReceived       datagrams received
         * @param datagramsNoPort         datagrams received with no application at destination port
         * @param datagramsReceivedErrors datagrams that could not be delivered
         */
        public UdpStats(long datagramsSent, long datagramsReceived, long datagramsNoPort,
                long datagramsReceivedErrors) {
            this.datagramsSent = datagramsSent;
            this.datagramsReceived = datagramsReceived;
            this.datagramsNoPort = datagramsNoPort;
            this.datagramsReceivedErrors = datagramsReceivedErrors;
        }

        /**
         * Datagrams Sent is the number of UDP datagrams sent from the entity.
         *
         * @return the datagramsSent
         */
        public long getDatagramsSent() {
            return datagramsSent;
        }

        /**
         * Datagrams Received is the number of UDP datagrams delivered to UDP users.
         *
         * @return the datagramsReceived
         */
        public long getDatagramsReceived() {
            return datagramsReceived;
        }

        /**
         * Datagrams No Port is the number of received UDP datagrams for which there was no application at the
         * destination port.
         *
         * @return the datagramsNoPort
         */
        public long getDatagramsNoPort() {
            return datagramsNoPort;
        }

        /**
         * Datagrams Received Errors is the number of received UDP datagrams that could not be delivered for reasons
         * other than the lack of an application at the destination port.
         *
         * @return the datagramsReceivedErrors
         */
        public long getDatagramsReceivedErrors() {
            return datagramsReceivedErrors;
        }

        @Override
        public String toString() {
            return "UdpStats [datagramsSent=" + datagramsSent + ", datagramsReceived=" + datagramsReceived
                    + ", datagramsNoPort=" + datagramsNoPort + ", datagramsReceivedErrors=" + datagramsReceivedErrors
                    + "]";
        }
    }

    /**
     * The TCP connection state as described in RFC 793.
     */
    @PublicApi
    enum TcpState {
        /** Unknown state. */
        UNKNOWN,
        /** Connection closed. */
        CLOSED,
        /** Waiting for a connection request. */
        LISTEN,
        /** Waiting for acknowledgment of a connection request. */
        SYN_SENT,
        /** Waiting for acknowledgment of a connection request after having received one. */
        SYN_RECV,
        /** Connection established. */
        ESTABLISHED,
        /** Waiting for a connection termination request from the remote TCP. */
        FIN_WAIT_1,
        /** Waiting for a connection termination request from the remote TCP after sending one. */
        FIN_WAIT_2,
        /** Waiting for a connection termination request from the local user. */
        CLOSE_WAIT,
        /** Waiting for acknowledgment of a connection termination request. */
        CLOSING,
        /** Waiting for acknowledgment of the connection termination request sent to the remote TCP. */
        LAST_ACK,
        /** Waiting for enough time to pass to be sure the remote TCP received acknowledgment. */
        TIME_WAIT,
        /** No state. */
        NONE;
    }

    /**
     * Encapsulates information associated with an IP connection.
     */
    @PublicApi
    @Immutable
    final class IPConnection {
        private final String type;
        private final byte[] localAddress;
        private final int localPort;
        private final byte[] foreignAddress;
        private final int foreignPort;
        private final TcpState state;
        private final int transmitQueue;
        private final int receiveQueue;
        private int owningProcessId;

        /**
         * Constructs a new IPConnection instance.
         *
         * @param type            the protocol type (e.g., tcp4, tcp6, udp4, udp6)
         * @param localAddress    the local address bytes
         * @param localPort       the local port
         * @param foreignAddress  the remote address bytes
         * @param foreignPort     the remote port
         * @param state           the TCP state
         * @param transmitQueue   the transmit queue size
         * @param receiveQueue    the receive queue size
         * @param owningProcessId the PID of the owning process
         */
        public IPConnection(String type, byte[] localAddress, int localPort, byte[] foreignAddress, int foreignPort,
                TcpState state, int transmitQueue, int receiveQueue, int owningProcessId) {
            this.type = type;
            this.localAddress = Arrays.copyOf(localAddress, localAddress.length);
            this.localPort = localPort;
            this.foreignAddress = Arrays.copyOf(foreignAddress, foreignAddress.length);
            this.foreignPort = foreignPort;
            this.state = state;
            this.transmitQueue = transmitQueue;
            this.receiveQueue = receiveQueue;
            this.owningProcessId = owningProcessId;
        }

        /**
         * Returns the connection protocol type, e.g., tcp4, tcp6, tcp46, udp4, udp6, udp46
         *
         * @return The protocol type
         */
        public String getType() {
            return type;
        }

        /**
         * Gets the local address. For IPv4 addresses this is a 4-byte array. For IPv6 addresses this is a 16-byte
         * array.
         * <p>
         * On Unix operating systems, the 16-bit value may be truncated, giving only the high order bytes. IPv6
         * addresses ending in zeroes should be considered suspect.
         *
         * @return The local address, or an empty array if the listener can accept a connection on any interface.
         */
        public byte[] getLocalAddress() {
            return Arrays.copyOf(localAddress, localAddress.length);
        }

        /**
         * Gets the local port.
         *
         * @return The local port, or 0 if unknown, or any port.
         */
        public int getLocalPort() {
            return localPort;
        }

        /**
         * Gets the foreign/remote address. For IPv4 addresses this is a 4-byte array. For IPv6 addresses this is a
         * 16-byte array.
         * <p>
         * On Unix operating systems, this value may be truncated. IPv6 addresses ending in zeroes should be considered
         * suspect.
         *
         * @return The foreign/remote address, or an empty array if unknown. An empty array will also result if
         */
        public byte[] getForeignAddress() {
            return Arrays.copyOf(foreignAddress, foreignAddress.length);
        }

        /**
         * Gets the foreign/remote port.
         *
         * @return The foreign/remote port, or 0 if unknown.
         */
        public int getForeignPort() {
            return foreignPort;
        }

        /**
         * Gets the connection state (TCP connections only).
         *
         * @return The connection state if known or relevant, null otherwise.
         */
        public TcpState getState() {
            return state;
        }

        /**
         * Gets the size of the transmit queue. Not available on Windows.
         *
         * @return The size of the transmit queue, or 0 if unknown.
         */
        public int getTransmitQueue() {
            return transmitQueue;
        }

        /**
         * Gets the size of the receive queue. Not available on Windows.
         *
         * @return The size of the receive queue, or 0 if unknown.
         */
        public int getReceiveQueue() {
            return receiveQueue;
        }

        /**
         * Gets the id of the process which holds this connection.
         *
         * @return The process id of the process which holds this connection if known, -1 otherwise.
         */
        public int getowningProcessId() {
            return owningProcessId;
        }

        @Override
        public String toString() {
            String localIp = "*";
            try {
                localIp = InetAddress.getByAddress(localAddress).toString();
            } catch (UnknownHostException e) { // NOSONAR squid:S108
            }
            String foreignIp = "*";
            try {
                foreignIp = InetAddress.getByAddress(foreignAddress).toString();
            } catch (UnknownHostException e) { // NOSONAR squid:S108
            }
            return "IPConnection [type=" + type + ", localAddress=" + localIp + ", localPort=" + localPort
                    + ", foreignAddress=" + foreignIp + ", foreignPort=" + foreignPort + ", state=" + state
                    + ", transmitQueue=" + transmitQueue + ", receiveQueue=" + receiveQueue + ", owningProcessId="
                    + owningProcessId + "]";
        }
    }
}
