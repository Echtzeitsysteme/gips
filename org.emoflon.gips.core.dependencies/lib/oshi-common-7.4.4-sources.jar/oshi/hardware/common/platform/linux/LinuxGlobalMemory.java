/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.linux;

import static oshi.util.Memoizer.defaultExpiration;
import static oshi.util.Memoizer.memoize;

import java.util.List;
import java.util.function.Supplier;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.VirtualMemory;
import oshi.hardware.common.AbstractGlobalMemory;
import oshi.util.FileUtil;
import oshi.util.ParseUtil;
import oshi.util.linux.ProcPath;
import oshi.util.tuples.Pair;

/**
 * Memory obtained by /proc/meminfo and sysinfo.totalram
 */
@ThreadSafe
public final class LinuxGlobalMemory extends AbstractGlobalMemory {

    private final long pageSize;

    /**
     * Constructor.
     *
     * @param pageSize the system page size in bytes
     */
    public LinuxGlobalMemory(long pageSize) {
        this.pageSize = pageSize;
    }

    private final Supplier<Pair<Long, Long>> availTotal = memoize(LinuxGlobalMemory::readMemInfo, defaultExpiration());

    private final Supplier<VirtualMemory> vm = memoize(this::createVirtualMemory);

    @Override
    public long getAvailable() {
        return availTotal.get().getA();
    }

    @Override
    public long getTotal() {
        return availTotal.get().getB();
    }

    @Override
    public long getPageSize() {
        return pageSize;
    }

    @Override
    public VirtualMemory getVirtualMemory() {
        return vm.get();
    }

    /**
     * Updates instance variables from reading /proc/meminfo. While most of the information is available in the sysinfo
     * structure, the most accurate calculation of MemAvailable is only available from reading this pseudo-file. The
     * maintainers of the Linux Kernel have indicated this location will be kept up to date if the calculation changes:
     * see https://git.kernel.org/cgit/linux/kernel/git/torvalds/linux.git/commit/?
     * id=34e431b0ae398fc54ea69ff85ec700722c9da773
     * <p>
     * Internally, reading /proc/meminfo is faster than sysinfo because it only spends time populating the memory
     * components of the sysinfo structure.
     *
     * @return A pair containing available and total memory in bytes
     */
    private static Pair<Long, Long> readMemInfo() {
        return parseMemInfo(FileUtil.readFile(ProcPath.MEMINFO));
    }

    /**
     * Parses {@code /proc/meminfo} into a pair of (available, total) bytes. Uses {@code MemAvailable} when present,
     * otherwise estimates it from {@code MemFree + Active(file) + Inactive(file) + SReclaimable}. Package-private for
     * testing.
     *
     * @param procMemInfo the lines of {@code /proc/meminfo}
     * @return a pair of (available, total) memory in bytes
     */
    static Pair<Long, Long> parseMemInfo(List<String> procMemInfo) {
        long memFree = 0L;
        long activeFile = 0L;
        long inactiveFile = 0L;
        long sReclaimable = 0L;

        long memTotal = 0L;
        long memAvailable;

        for (String checkLine : procMemInfo) {
            String[] memorySplit = ParseUtil.whitespaces.split(checkLine, 2);
            if (memorySplit.length > 1) {
                switch (memorySplit[0]) {
                    case "MemTotal:":
                        memTotal = ParseUtil.parseDecimalMemorySizeToBinary(memorySplit[1]);
                        break;
                    case "MemAvailable:":
                        memAvailable = ParseUtil.parseDecimalMemorySizeToBinary(memorySplit[1]);
                        // We're done!
                        return new Pair<>(memAvailable, memTotal);
                    case "MemFree:":
                        memFree = ParseUtil.parseDecimalMemorySizeToBinary(memorySplit[1]);
                        break;
                    case "Active(file):":
                        activeFile = ParseUtil.parseDecimalMemorySizeToBinary(memorySplit[1]);
                        break;
                    case "Inactive(file):":
                        inactiveFile = ParseUtil.parseDecimalMemorySizeToBinary(memorySplit[1]);
                        break;
                    case "SReclaimable:":
                        sReclaimable = ParseUtil.parseDecimalMemorySizeToBinary(memorySplit[1]);
                        break;
                    default:
                        // do nothing with other lines
                        break;
                }
            }
        }
        // We didn't find MemAvailable so we estimate from other fields
        return new Pair<>(memFree + activeFile + inactiveFile + sReclaimable, memTotal);
    }

    private VirtualMemory createVirtualMemory() {
        return new LinuxVirtualMemory(this);
    }
}
