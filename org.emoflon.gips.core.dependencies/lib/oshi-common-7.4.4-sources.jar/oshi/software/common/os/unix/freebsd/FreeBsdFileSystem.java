/*
 * Copyright 2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.freebsd;

import java.io.File;
import java.nio.file.PathMatcher;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oshi.software.common.AbstractFileSystem;
import oshi.software.os.OSFileStore;
import oshi.util.ExecutingCommand;
import oshi.util.FileSystemUtil;
import oshi.util.ParseUtil;
import oshi.util.tuples.Pair;

/**
 * Abstract base for the FreeBSD FileSystem. Parses the mount table and builds the file stores; the JNA and FFM
 * subclasses supply the statfs reads.
 */
public abstract class FreeBsdFileSystem extends AbstractFileSystem {

    public static final String OSHI_FREEBSD_FS_PATH_EXCLUDES = "oshi.os.freebsd.filesystem.path.excludes";
    public static final String OSHI_FREEBSD_FS_PATH_INCLUDES = "oshi.os.freebsd.filesystem.path.includes";
    public static final String OSHI_FREEBSD_FS_VOLUME_EXCLUDES = "oshi.os.freebsd.filesystem.volume.excludes";
    public static final String OSHI_FREEBSD_FS_VOLUME_INCLUDES = "oshi.os.freebsd.filesystem.volume.includes";

    private static final List<PathMatcher> FS_PATH_EXCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_FREEBSD_FS_PATH_EXCLUDES);
    private static final List<PathMatcher> FS_PATH_INCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_FREEBSD_FS_PATH_INCLUDES);
    private static final List<PathMatcher> FS_VOLUME_EXCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_FREEBSD_FS_VOLUME_EXCLUDES);
    private static final List<PathMatcher> FS_VOLUME_INCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_FREEBSD_FS_VOLUME_INCLUDES);

    @Override
    public List<OSFileStore> getFileStores(boolean localOnly) {
        // TODO map mount point to UUID?
        // is /etc/fstab useful for this?
        Map<String, String> uuidMap = parseGeomPartList(ExecutingCommand.runNative("geom part list"));

        List<OSFileStore> fsList = new ArrayList<>();

        // Get inode usage data
        Pair<Map<String, Long>, Map<String, Long>> inodes = parseDfInodes(ExecutingCommand.runNative("df -i"));
        Map<String, Long> inodeFreeMap = inodes.getA();
        Map<String, Long> inodeTotalMap = inodes.getB();

        // Get mount table
        for (String fs : ExecutingCommand.runNative("mount -p")) {
            String[] split = ParseUtil.whitespaces.split(fs);
            if (split.length < 5) {
                continue;
            }
            // 1st field is volume name
            // 2nd field is mount point
            // 3rd field is fs type
            // 4th field is options
            // other fields ignored
            String volume = split[0];
            String path = split[1];
            String type = split[2];
            String options = split[3];

            // Skip non-local drives if requested, and exclude pseudo file systems
            boolean isLocal = !NETWORK_FS_TYPES.contains(type);
            if ((localOnly && !isLocal)
                    || !path.equals("/") && (PSEUDO_FS_TYPES.contains(type) || FileSystemUtil.isFileStoreExcluded(path,
                            volume, FS_PATH_INCLUDES, FS_PATH_EXCLUDES, FS_VOLUME_INCLUDES, FS_VOLUME_EXCLUDES))) {
                continue;
            }

            String name = path.substring(path.lastIndexOf('/') + 1);
            // Special case for /, pull last element of volume instead
            if (name.isEmpty()) {
                name = volume.substring(volume.lastIndexOf('/') + 1);
            }
            File f = new File(path);
            long totalSpace = f.getTotalSpace();
            long usableSpace = f.getUsableSpace();
            long freeSpace = f.getFreeSpace();

            String description;
            if (volume.startsWith("/dev") || path.equals("/")) {
                description = "Local Disk";
            } else if (volume.equals("tmpfs")) {
                description = "Ram Disk";
            } else if (NETWORK_FS_TYPES.contains(type)) {
                description = "Network Disk";
            } else {
                description = "Mount Point";
            }
            // Match UUID
            String uuid = uuidMap.getOrDefault(name, "");

            fsList.add(new FreeBsdOSFileStore(this, name, volume, name, path, options, uuid, isLocal, "", description,
                    type, freeSpace, usableSpace, totalSpace, inodeFreeMap.getOrDefault(path, 0L),
                    inodeTotalMap.getOrDefault(path, 0L)));
        }
        return fsList;
    }

    @Override
    public long getOpenFileDescriptors() {
        return queryOpenFiles();
    }

    @Override
    public long getMaxFileDescriptors() {
        return queryMaxFiles();
    }

    @Override
    public long getMaxFileDescriptorsPerProcess() {
        // On FreeBSD there is no process-specific system-wide limit, so the general limit is returned.
        return getMaxFileDescriptors();
    }

    /**
     * Parses {@code geom part list} output into a map of device-name to rawuuid.
     *
     * @param geomOutput the lines from {@code geom part list}
     * @return a map of device-name to rawuuid
     */
    static Map<String, String> parseGeomPartList(List<String> geomOutput) {
        Map<String, String> uuidMap = new HashMap<>();
        String device = "";
        for (String line : geomOutput) {
            if (line.contains("Name: ")) {
                device = line.substring(line.lastIndexOf(' ') + 1);
            }
            // If we aren't working with a current partition, continue
            if (device.isEmpty()) {
                continue;
            }
            line = line.trim();
            if (line.startsWith("rawuuid:")) {
                uuidMap.put(device, line.substring(line.lastIndexOf(' ') + 1));
                device = "";
            }
        }
        return uuidMap;
    }

    /**
     * Parses {@code df -i} output into inode free and total maps keyed by mount point.
     *
     * @param dfOutput the lines from {@code df -i}
     * @return a {@link Pair} of (inodeFreeMap, inodeTotalMap) both keyed by mount point
     */
    static Pair<Map<String, Long>, Map<String, Long>> parseDfInodes(List<String> dfOutput) {
        Map<String, Long> inodeFreeMap = new HashMap<>();
        Map<String, Long> inodeTotalMap = new HashMap<>();
        for (String line : dfOutput) {
            /*- Sample Output:
            Filesystem    1K-blocks   Used   Avail Capacity iused  ifree %iused  Mounted on
            /dev/twed0s1a   2026030 584112 1279836    31%    2751 279871    1%   /
            */
            if (!line.startsWith("Filesystem")) {
                String[] split = ParseUtil.whitespaces.split(line);
                if (split.length > 8) {
                    long ifree = ParseUtil.parseLongOrDefault(split[6], 0L);
                    long iused = ParseUtil.parseLongOrDefault(split[5], 0L);
                    // Key by mount point (last column) to match later lookup
                    inodeFreeMap.put(split[8], ifree);
                    inodeTotalMap.put(split[8], iused + ifree);
                }
            }
        }
        return new Pair<>(inodeFreeMap, inodeTotalMap);
    }

    /**
     * Reads {@code kern.openfiles} via the subclass's sysctl mechanism.
     *
     * @return the current count of open file descriptors system-wide
     */
    protected abstract long queryOpenFiles();

    /**
     * Reads {@code kern.maxfiles} via the subclass's sysctl mechanism.
     *
     * @return the system-wide limit on open file descriptors
     */
    protected abstract long queryMaxFiles();
}
