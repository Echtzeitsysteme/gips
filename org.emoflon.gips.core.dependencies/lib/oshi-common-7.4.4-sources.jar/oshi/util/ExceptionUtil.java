/*
 * Copyright 2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util;

import java.util.Arrays;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.OptionalLong;

import org.slf4j.Logger;

import oshi.annotation.concurrent.ThreadSafe;

/**
 * Utility methods for reducing repetitive exception handling boilerplate, particularly around FFM (Foreign Function and
 * Memory) native calls that require catching {@link Throwable}.
 */
@ThreadSafe
public final class ExceptionUtil {

    private ExceptionUtil() {
    }

    /**
     * Logs a throwable at the given level, substituting its message into the format string and attaching the throwable
     * itself as the log event's cause via SLF4J's implicit-cause handling. Level dispatch is delegated to
     * {@link LogUtil#logAtLevel(Logger, LogLevel, String, Object...)}.
     * <p>
     * The caller's arguments fill the leading {@code {}} placeholders in order, and the throwable's message fills one
     * final placeholder, so {@code msg} should carry one {@code {}} per argument plus a trailing one. For example,
     * {@code logAtLevel(log, DEBUG, "Failed to read {}: {}", t, path)} logs the path and then the exception message.
     * <p>
     * Public so other modules (e.g., {@code oshi-core-ffm}) can share this dispatch instead of duplicating it.
     *
     * @param log   the logger to use
     * @param level the level at which to log
     * @param msg   the log message (use {} for each argument, then one for the exception message)
     * @param t     the throwable to log
     * @param args  the arguments filling the leading {} placeholders, if any
     */
    public static void logAtLevel(Logger log, LogLevel level, String msg, Throwable t, Object... args) {
        // Append the exception message and the throwable itself; SLF4J takes the trailing throwable as the cause.
        Object[] all = Arrays.copyOf(args, args.length + 2);
        all[args.length] = t.getMessage();
        all[args.length + 1] = t;
        LogUtil.logAtLevel(log, level, msg, all);
    }

    /**
     * A supplier that may throw any {@link Throwable}, including checked exceptions.
     *
     * @param <T> the type of result supplied
     */
    @FunctionalInterface
    public interface ThrowingSupplier<T> {
        /**
         * Gets a result.
         *
         * @return a result
         * @throws Throwable if unable to compute
         */
        T get() throws Throwable;
    }

    /**
     * An int-returning supplier that may throw any {@link Throwable}.
     */
    @FunctionalInterface
    public interface ThrowingIntSupplier {
        /**
         * Gets an int result.
         *
         * @return an int result
         * @throws Throwable if unable to compute
         */
        int getAsInt() throws Throwable;
    }

    /**
     * A long-returning supplier that may throw any {@link Throwable}.
     */
    @FunctionalInterface
    public interface ThrowingLongSupplier {
        /**
         * Gets a long result.
         *
         * @return a long result
         * @throws Throwable if unable to compute
         */
        long getAsLong() throws Throwable;
    }

    /**
     * A boolean-returning supplier that may throw any {@link Throwable}.
     */
    @FunctionalInterface
    public interface ThrowingBooleanSupplier {
        /**
         * Gets a boolean result.
         *
         * @return a boolean result
         * @throws Throwable if unable to compute
         */
        boolean getAsBoolean() throws Throwable;
    }

    /**
     * A double-returning supplier that may throw any {@link Throwable}.
     */
    @FunctionalInterface
    public interface ThrowingDoubleSupplier {
        /**
         * Gets a double result.
         *
         * @return a double result
         * @throws Throwable if unable to compute
         */
        double getAsDouble() throws Throwable;
    }

    /**
     * A runnable that may throw any {@link Throwable}.
     */
    @FunctionalInterface
    public interface ThrowingRunnable {
        /**
         * Performs the operation.
         *
         * @throws Throwable if unable to perform
         */
        void run() throws Throwable;
    }

    /**
     * Executes the supplier, returning its result on success or the default value if any {@link Throwable} is thrown.
     *
     * @param <T>          the result type
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @return the supplier's result or the default value
     */
    public static <T> T getOrDefault(ThrowingSupplier<T> supplier, T defaultValue) {
        try {
            return supplier.get();
        } catch (Throwable t) {
            return defaultValue;
        }
    }

    /**
     * Executes the supplier, returning its result on success or the default value if any {@link Throwable} is thrown.
     * Logs the exception at debug level.
     *
     * @param <T>          the result type
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param msg          the log message (use {} for the exception message placeholder)
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static <T> T getOrDefault(ThrowingSupplier<T> supplier, T defaultValue, Logger log, String msg,
            Object... args) {
        return getOrDefault(supplier, defaultValue, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the supplier, returning its result on success or the default value if any {@link Throwable} is thrown.
     * Logs the exception at the specified level.
     *
     * @param <T>          the result type
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param level        the level at which to log the exception
     * @param msg          the log message (use {} for the exception message placeholder)
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static <T> T getOrDefault(ThrowingSupplier<T> supplier, T defaultValue, Logger log, LogLevel level,
            String msg, Object... args) {
        try {
            return supplier.get();
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return defaultValue;
        }
    }

    /**
     * Executes the int supplier, returning its result on success or the default value on failure.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @return the supplier's result or the default value
     */
    public static int getIntOrDefault(ThrowingIntSupplier supplier, int defaultValue) {
        try {
            return supplier.getAsInt();
        } catch (Throwable t) {
            return defaultValue;
        }
    }

    /**
     * Executes the int supplier, returning its result on success or the default value on failure. Logs the exception at
     * debug level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static int getIntOrDefault(ThrowingIntSupplier supplier, int defaultValue, Logger log, String msg,
            Object... args) {
        return getIntOrDefault(supplier, defaultValue, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the int supplier, returning its result on success or the default value on failure. Logs the exception at
     * the specified level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param level        the level at which to log the exception
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static int getIntOrDefault(ThrowingIntSupplier supplier, int defaultValue, Logger log, LogLevel level,
            String msg, Object... args) {
        try {
            return supplier.getAsInt();
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return defaultValue;
        }
    }

    /**
     * Executes the long supplier, returning its result on success or the default value on failure.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @return the supplier's result or the default value
     */
    public static long getLongOrDefault(ThrowingLongSupplier supplier, long defaultValue) {
        try {
            return supplier.getAsLong();
        } catch (Throwable t) {
            return defaultValue;
        }
    }

    /**
     * Executes the long supplier, returning its result on success or the default value on failure. Logs the exception
     * at debug level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static long getLongOrDefault(ThrowingLongSupplier supplier, long defaultValue, Logger log, String msg,
            Object... args) {
        return getLongOrDefault(supplier, defaultValue, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the long supplier, returning its result on success or the default value on failure. Logs the exception
     * at the specified level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param level        the level at which to log the exception
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static long getLongOrDefault(ThrowingLongSupplier supplier, long defaultValue, Logger log, LogLevel level,
            String msg, Object... args) {
        try {
            return supplier.getAsLong();
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return defaultValue;
        }
    }

    /**
     * Executes the boolean supplier, returning its result on success or the default value on failure.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @return the supplier's result or the default value
     */
    public static boolean getBooleanOrDefault(ThrowingBooleanSupplier supplier, boolean defaultValue) {
        try {
            return supplier.getAsBoolean();
        } catch (Throwable t) {
            return defaultValue;
        }
    }

    /**
     * Executes the boolean supplier, returning its result on success or the default value on failure. Logs the
     * exception at debug level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static boolean getBooleanOrDefault(ThrowingBooleanSupplier supplier, boolean defaultValue, Logger log,
            String msg, Object... args) {
        return getBooleanOrDefault(supplier, defaultValue, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the boolean supplier, returning its result on success or the default value on failure. Logs the
     * exception at the specified level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param level        the level at which to log the exception
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static boolean getBooleanOrDefault(ThrowingBooleanSupplier supplier, boolean defaultValue, Logger log,
            LogLevel level, String msg, Object... args) {
        try {
            return supplier.getAsBoolean();
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return defaultValue;
        }
    }

    /**
     * Executes the double supplier, returning its result on success or the default value on failure.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @return the supplier's result or the default value
     */
    public static double getDoubleOrDefault(ThrowingDoubleSupplier supplier, double defaultValue) {
        try {
            return supplier.getAsDouble();
        } catch (Throwable t) {
            return defaultValue;
        }
    }

    /**
     * Executes the double supplier, returning its result on success or the default value on failure. Logs the exception
     * at debug level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static double getDoubleOrDefault(ThrowingDoubleSupplier supplier, double defaultValue, Logger log,
            String msg, Object... args) {
        return getDoubleOrDefault(supplier, defaultValue, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the double supplier, returning its result on success or the default value on failure. Logs the exception
     * at the specified level.
     *
     * @param supplier     the operation to attempt
     * @param defaultValue the value to return on failure
     * @param log          the logger to use
     * @param level        the level at which to log the exception
     * @param msg          the log message
     * @param args         the arguments filling the leading {} placeholders, if any
     * @return the supplier's result or the default value
     */
    public static double getDoubleOrDefault(ThrowingDoubleSupplier supplier, double defaultValue, Logger log,
            LogLevel level, String msg, Object... args) {
        try {
            return supplier.getAsDouble();
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return defaultValue;
        }
    }

    /**
     * Executes the supplier, wrapping the result in an {@link Optional}. Returns {@link Optional#empty()} on failure.
     *
     * @param <T>      the result type
     * @param supplier the operation to attempt
     * @param log      the logger to use
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     * @return an Optional containing the result, or empty on failure
     */
    public static <T> Optional<T> getOptional(ThrowingSupplier<T> supplier, Logger log, String msg, Object... args) {
        return getOptional(supplier, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the supplier, wrapping the result in an {@link Optional}. Returns {@link Optional#empty()} on failure.
     * Logs the exception at the specified level.
     *
     * @param <T>      the result type
     * @param supplier the operation to attempt
     * @param log      the logger to use
     * @param level    the level at which to log the exception
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     * @return an Optional containing the result, or empty on failure
     */
    public static <T> Optional<T> getOptional(ThrowingSupplier<T> supplier, Logger log, LogLevel level, String msg,
            Object... args) {
        try {
            return Optional.ofNullable(supplier.get());
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return Optional.empty();
        }
    }

    /**
     * Executes the int supplier, wrapping the result in an {@link OptionalInt}. Returns {@link OptionalInt#empty()} on
     * failure.
     *
     * @param supplier the operation to attempt
     * @param log      the logger to use
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     * @return an OptionalInt containing the result, or empty on failure
     */
    public static OptionalInt getOptionalInt(ThrowingIntSupplier supplier, Logger log, String msg, Object... args) {
        return getOptionalInt(supplier, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the int supplier, wrapping the result in an {@link OptionalInt}. Returns {@link OptionalInt#empty()} on
     * failure. Logs the exception at the specified level.
     *
     * @param supplier the operation to attempt
     * @param log      the logger to use
     * @param level    the level at which to log the exception
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     * @return an OptionalInt containing the result, or empty on failure
     */
    public static OptionalInt getOptionalInt(ThrowingIntSupplier supplier, Logger log, LogLevel level, String msg,
            Object... args) {
        try {
            return OptionalInt.of(supplier.getAsInt());
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return OptionalInt.empty();
        }
    }

    /**
     * Executes the long supplier, wrapping the result in an {@link OptionalLong}. Returns {@link OptionalLong#empty()}
     * on failure.
     *
     * @param supplier the operation to attempt
     * @param log      the logger to use
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     * @return an OptionalLong containing the result, or empty on failure
     */
    public static OptionalLong getOptionalLong(ThrowingLongSupplier supplier, Logger log, String msg, Object... args) {
        return getOptionalLong(supplier, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the long supplier, wrapping the result in an {@link OptionalLong}. Returns {@link OptionalLong#empty()}
     * on failure. Logs the exception at the specified level.
     *
     * @param supplier the operation to attempt
     * @param log      the logger to use
     * @param level    the level at which to log the exception
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     * @return an OptionalLong containing the result, or empty on failure
     */
    public static OptionalLong getOptionalLong(ThrowingLongSupplier supplier, Logger log, LogLevel level, String msg,
            Object... args) {
        try {
            return OptionalLong.of(supplier.getAsLong());
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
            return OptionalLong.empty();
        }
    }

    /**
     * Executes the runnable, silently swallowing any {@link Throwable}.
     *
     * @param runnable the operation to attempt
     */
    public static void runSilently(ThrowingRunnable runnable) {
        try {
            runnable.run();
        } catch (Throwable t) {
            // intentionally silent
        }
    }

    /**
     * Executes the runnable, logging any {@link Throwable} at debug level.
     *
     * @param runnable the operation to attempt
     * @param log      the logger to use
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     */
    public static void runOrLog(ThrowingRunnable runnable, Logger log, String msg, Object... args) {
        runOrLog(runnable, log, LogLevel.DEBUG, msg, args);
    }

    /**
     * Executes the runnable, logging any {@link Throwable} at the specified level.
     *
     * @param runnable the operation to attempt
     * @param log      the logger to use
     * @param level    the level at which to log the exception
     * @param msg      the log message
     * @param args     the arguments filling the leading {} placeholders, if any
     */
    public static void runOrLog(ThrowingRunnable runnable, Logger log, LogLevel level, String msg, Object... args) {
        try {
            runnable.run();
        } catch (Throwable t) {
            logAtLevel(log, level, msg, t, args);
        }
    }
}
