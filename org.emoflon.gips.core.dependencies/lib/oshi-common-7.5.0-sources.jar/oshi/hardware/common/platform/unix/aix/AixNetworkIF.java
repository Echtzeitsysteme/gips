/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.unix.aix;

import java.net.NetworkInterface;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.common.AbstractNetworkIF;

/**
 * Abstract base for AIX NetworkIF. {@link #updateAttributes()} populates fields from a per-interface stats POJO that
 * subclasses fetch from their respective perfstat driver.
 */
@ThreadSafe
public abstract class AixNetworkIF extends AbstractNetworkIF {

    /** Per-interface stats fields the AIX HAL reads. JNA and FFM concrete subclasses both fill this. */
    public static final class IfStats {
        public long bytesSent;
        public long bytesRecv;
        public long packetsSent;
        public long packetsRecv;
        public long outErrors;
        public long inErrors;
        public long collisions;
        public long inDrops;
        public long speed;
    }

    /**
     * Constructs a new {@code AixNetworkIF}.
     *
     * @param netint the underlying network interface
     * @throws InstantiationException if the instance could not be constructed
     */
    protected AixNetworkIF(NetworkInterface netint) throws InstantiationException {
        super(netint);
    }

    @Override
    public boolean updateAttributes() {
        IfStats stats = queryStats();
        if (stats == null) {
            return false;
        }
        this.bytesSent = stats.bytesSent;
        this.bytesRecv = stats.bytesRecv;
        this.packetsSent = stats.packetsSent;
        this.packetsRecv = stats.packetsRecv;
        this.outErrors = stats.outErrors;
        this.inErrors = stats.inErrors;
        this.collisions = stats.collisions;
        this.inDrops = stats.inDrops;
        this.speed = stats.speed;
        this.timeStamp = System.currentTimeMillis();
        return true;
    }

    /**
     * Looks up this interface's per-interface stats from the subclass's perfstat data source.
     *
     * @return stats POJO, or {@code null} if no entry was found for this interface name
     */
    protected abstract @Nullable IfStats queryStats();
}
