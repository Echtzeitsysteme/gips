/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.common.unix.aix;

import java.util.List;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;
import oshi.util.tuples.Pair;
import oshi.util.tuples.Triplet;

/**
 * Utility to query lscfg
 */
@ThreadSafe
public final class Lscfg {

    private Lscfg() {
    }

    /**
     * Query {@code lscfg -vp} to get all hardware devices
     *
     * @return A list of the output
     */
    public static List<String> queryAllDevices() {
        return ExecutingCommand.runNative("lscfg -vp");
    }

    /**
     * Parse the output of {@code lscfg -vp} to get backplane info
     *
     * @param lscfg The output of a previous call to {@code lscfg -vp}
     * @return A triplet with backplane model, serial number, and version
     */
    public static Triplet<@Nullable String, @Nullable String, @Nullable String> queryBackplaneModelSerialVersion(
            List<String> lscfg) {
        final String planeMarker = "WAY BACKPLANE";
        final String modelMarker = "Part Number";
        final String serialMarker = "Serial Number";
        final String versionMarker = "Version";
        final String locationMarker = "Physical Location";

        // 1 WAY BACKPLANE :
        // Serial Number...............YL10243490FB
        // Part Number.................80P4315
        // Customer Card ID Number.....26F4
        // CCIN Extender...............1
        // FRU Number.................. 80P4315
        // Version.....................RS6K
        // Hardware Location Code......U0.1-P1
        // Physical Location: U0.1-P1

        String model = null;
        String serialNumber = null;
        String version = null;
        boolean planeFlag = false;
        for (final String checkLine : lscfg) {
            if (!planeFlag && checkLine.contains(planeMarker)) {
                planeFlag = true;
            } else if (planeFlag) {
                if (checkLine.contains(modelMarker)) {
                    model = ParseUtil.removeLeadingDots(ParseUtil.getTextAfterString(checkLine, modelMarker).trim());
                } else if (checkLine.contains(serialMarker)) {
                    serialNumber = ParseUtil
                            .removeLeadingDots(ParseUtil.getTextAfterString(checkLine, serialMarker).trim());
                } else if (checkLine.contains(versionMarker)) {
                    version = ParseUtil
                            .removeLeadingDots(ParseUtil.getTextAfterString(checkLine, versionMarker).trim());
                } else if (checkLine.contains(locationMarker)) {
                    break;
                }
            }
        }
        return new Triplet<>(model, serialNumber, version);
    }

    /**
     * Query {@code lscfg -vl device} to get hardware info
     *
     * @param device The disk to get the model and serial from
     * @return A pair containing the model and serial number for the device, or null if not found
     */
    public static Pair<@Nullable String, @Nullable String> queryModelSerial(String device) {
        return parseModelSerial(ExecutingCommand.runNative("lscfg -vl " + device), device);
    }

    /**
     * Parse the output of {@code lscfg -vl device} to get the model and serial number
     *
     * @param lscfg  The output of a previous call to {@code lscfg -vl device}
     * @param device The disk the output describes
     * @return A pair containing the model and serial number for the device, either of which may be null if not found
     */
    public static Pair<@Nullable String, @Nullable String> parseModelSerial(List<String> lscfg, String device) {
        String modelMarker = "Machine Type and Model";
        String serialMarker = "Serial Number";
        String model = null;
        String serial = null;
        for (String s : lscfg) {
            // Default model to description at end of first line. Locate the device literally (split would treat it
            // as a regex); a device at the very end of the line leaves an empty remainder, so no model is derived.
            if (model == null && s.contains(device)) {
                String locDesc = s.substring(s.indexOf(device) + device.length()).trim();
                int idx = locDesc.indexOf(' ');
                if (idx > 0) {
                    model = locDesc.substring(idx).trim();
                }
            }
            if (s.contains(modelMarker)) {
                model = ParseUtil.removeLeadingDots(ParseUtil.getTextAfterString(s, modelMarker).trim());
            } else if (s.contains(serialMarker)) {
                serial = ParseUtil.removeLeadingDots(ParseUtil.getTextAfterString(s, serialMarker).trim());
            }
        }
        return new Pair<>(model, serial);
    }
}
