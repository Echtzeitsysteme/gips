/*
 * Copyright 2018-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.common.windows.perfmon;

import java.util.Objects;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.Immutable;

/**
 * Encapsulates the three string components of a PDH performance counter path, plus whether it refers to the base
 * (SecondValue) of a multi-value counter.
 */
@Immutable
public final class PerfCounter {

    private final String object;
    private final @Nullable String instance;
    private final String counter;
    private final boolean baseCounter;

    /**
     * Suffix appended to counter names in enum definitions to indicate that the SecondValue (base) should be read
     * instead of the FirstValue.
     */
    public static final String BASE_SUFFIX = "_Base";

    /**
     * Creates a PerfCounter.
     *
     * @param objectName   the PDH object name
     * @param instanceName the instance name, or {@code null} for a counter with no instance filter
     * @param counterName  the counter name (may end with _Base for SecondValue)
     */
    public PerfCounter(String objectName, @Nullable String instanceName, String counterName) {
        this.object = objectName;
        this.instance = instanceName;
        this.baseCounter = counterName.endsWith(BASE_SUFFIX);
        this.counter = this.baseCounter ? counterName.substring(0, counterName.length() - BASE_SUFFIX.length())
                : counterName;
    }

    /**
     * Gets the PDH object name.
     *
     * @return Returns the object.
     */
    public String getObject() {
        return object;
    }

    /**
     * Gets the PDH instance name.
     *
     * @return Returns the instance.
     */
    public @Nullable String getInstance() {
        return instance;
    }

    /**
     * Gets the PDH counter name.
     *
     * @return Returns the counter.
     */
    public String getCounter() {
        return counter;
    }

    /**
     * Checks whether this is a base (SecondValue) counter.
     *
     * @return Returns whether the counter is a base counter
     */
    public boolean isBaseCounter() {
        return baseCounter;
    }

    /**
     * Returns the path for this counter
     *
     * @return A string representing the counter path
     */
    public String getCounterPath() {
        StringBuilder sb = new StringBuilder();
        sb.append('\\').append(object);
        if (instance != null) {
            sb.append('(').append(instance).append(')');
        }
        sb.append('\\').append(counter);
        return sb.toString();
    }

    /**
     * Strips the {@link #BASE_SUFFIX} from a counter name if present.
     *
     * @param counterName The counter name, possibly ending with {@code _Base}
     * @return The counter name without the {@code _Base} suffix, or the original name if the suffix is not present
     */
    public static String stripBaseSuffix(String counterName) {
        if (counterName.endsWith(BASE_SUFFIX)) {
            return counterName.substring(0, counterName.length() - BASE_SUFFIX.length());
        }
        return counterName;
    }

    /**
     * Tests whether a counter name has the {@link #BASE_SUFFIX}.
     *
     * @param counterName The counter name to test
     * @return true if the counter name ends with {@code _Base}
     */
    public static boolean isBase(String counterName) {
        return counterName.endsWith(BASE_SUFFIX);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PerfCounter)) {
            return false;
        }
        PerfCounter other = (PerfCounter) o;
        return baseCounter == other.baseCounter && Objects.equals(object, other.object)
                && Objects.equals(instance, other.instance) && Objects.equals(counter, other.counter);
    }

    @Override
    public int hashCode() {
        return Objects.hash(object, instance, counter, baseCounter);
    }
}
