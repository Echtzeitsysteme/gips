/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.common.windows.wmi;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;

/**
 * Constants, property enums, and WHERE clause builder for WMI class {@code Win32_Process}.
 */
@ThreadSafe
public class Win32Process {

    /**
     * The WMI class name.
     */
    public static final String WIN32_PROCESS = "Win32_Process";

    /**
     * Process command lines.
     */
    public enum CommandLineProperty {
        /** PROCESSID property. */
        PROCESSID,
        /** COMMANDLINE property. */
        COMMANDLINE
    }

    /**
     * Process properties accessible from WTSEnumerateProcesses in Vista+.
     */
    public enum ProcessXPProperty {
        /** PROCESSID property. */
        PROCESSID,
        /** NAME property. */
        NAME,
        /** KERNELMODETIME property. */
        KERNELMODETIME,
        /** USERMODETIME property. */
        USERMODETIME,
        /** THREADCOUNT property. */
        THREADCOUNT,
        /** PAGEFILEUSAGE property. */
        PAGEFILEUSAGE,
        /** HANDLECOUNT property. */
        HANDLECOUNT,
        /** EXECUTABLEPATH property. */
        EXECUTABLEPATH
    }

    /**
     * Constructor.
     */
    protected Win32Process() {
    }

    /**
     * Builds the WMI class name with optional WHERE clause filtering by process IDs.
     *
     * @param pids Process IDs to filter, or {@code null} to query all processes
     * @return the WMI class name with WHERE clause appended if pids is non-null
     */
    public static String buildWmiClassNameWithPidFilter(@Nullable Collection<Integer> pids) {
        if (pids == null || pids.isEmpty()) {
            return WIN32_PROCESS;
        }
        return WIN32_PROCESS + " WHERE ProcessID="
                + pids.stream().map(String::valueOf).collect(Collectors.joining(" OR PROCESSID="));
    }

    /**
     * Returns process command lines.
     *
     * @param h           An instantiated {@link WmiQueryExecutor}.
     * @param pidsToQuery Process IDs to query for command lines. Pass {@code null} to query all processes.
     * @return A {@link WmiResult} containing process IDs and command lines.
     */
    public static WmiResult<CommandLineProperty> queryCommandLines(WmiQueryExecutor h,
            @Nullable Set<Integer> pidsToQuery) {
        WmiQuery<CommandLineProperty> commandLineQuery = new WmiQuery<>(buildWmiClassNameWithPidFilter(pidsToQuery),
                CommandLineProperty.class);
        return h.queryWMI(commandLineQuery);
    }

    /**
     * Returns process info.
     *
     * @param h    An instantiated {@link WmiQueryExecutor}.
     * @param pids Process IDs to query, or {@code null} to query all processes.
     * @return Information on the provided processes.
     */
    public static WmiResult<ProcessXPProperty> queryProcesses(WmiQueryExecutor h, @Nullable Collection<Integer> pids) {
        WmiQuery<ProcessXPProperty> processQueryXP = new WmiQuery<>(buildWmiClassNameWithPidFilter(pids),
                ProcessXPProperty.class);
        return h.queryWMI(processQueryXP);
    }
}
