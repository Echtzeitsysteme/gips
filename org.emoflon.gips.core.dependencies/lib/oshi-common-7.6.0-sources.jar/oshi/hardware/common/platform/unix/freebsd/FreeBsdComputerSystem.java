/*
 * Copyright 2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.unix.freebsd;

import static oshi.util.Memoizer.memoize;

import java.util.List;
import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.Immutable;
import oshi.hardware.Baseboard;
import oshi.hardware.Firmware;
import oshi.hardware.common.AbstractComputerSystem;
import oshi.hardware.common.platform.unix.UnixBaseboard;
import oshi.util.Constants;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;
import oshi.util.Util;
import oshi.util.tuples.Quintet;

/**
 * Abstract base for the FreeBSD ComputerSystem. Reads the manufacturer, model and serial from the kenv/dmidecode output
 * the backends supply.
 */
@Immutable
public abstract class FreeBsdComputerSystem extends AbstractComputerSystem {

    private final Supplier<Quintet<String, String, String, String, String>> manufModelSerialUuidVers = memoize(
            this::readDmiDecode);

    @Override
    public String getManufacturer() {
        return manufModelSerialUuidVers.get().getA();
    }

    @Override
    public String getModel() {
        return manufModelSerialUuidVers.get().getB();
    }

    @Override
    public String getSerialNumber() {
        return manufModelSerialUuidVers.get().getC();
    }

    @Override
    public String getHardwareUUID() {
        return manufModelSerialUuidVers.get().getD();
    }

    @Override
    public Firmware createFirmware() {
        return new FreeBsdFirmware();
    }

    @Override
    public Baseboard createBaseboard() {
        return new UnixBaseboard(manufModelSerialUuidVers.get().getA(), manufModelSerialUuidVers.get().getB(),
                manufModelSerialUuidVers.get().getC(), manufModelSerialUuidVers.get().getE());
    }

    /**
     * Reads {@code kern.hostuuid} via the subclass's sysctl mechanism. Used as a fallback when {@code dmidecode} does
     * not yield a UUID (commonly the case without root).
     *
     * @return the host UUID, or {@link oshi.util.Constants#UNKNOWN} if the sysctl read fails
     */
    protected abstract String queryHostUuid();

    private Quintet<String, String, String, String, String> readDmiDecode() {
        // Only works with root permissions but it's all we've got
        Quintet<@Nullable String, @Nullable String, @Nullable String, @Nullable String, @Nullable String> dmi = parseDmiDecode(
                ExecutingCommand.runNative("dmidecode -t system"));
        String manufacturer = dmi.getA();
        String model = dmi.getB();
        String serialNumber = dmi.getC();
        String uuid = dmi.getD();
        String version = dmi.getE();
        // If we get to end and haven't assigned, use fallback
        if (Util.isBlank(serialNumber)) {
            serialNumber = querySystemSerialNumber();
        }
        if (Util.isBlank(uuid)) {
            uuid = queryHostUuid();
        }
        return new Quintet<>(ParseUtil.getStringValueOrUnknown(manufacturer), ParseUtil.getStringValueOrUnknown(model),
                ParseUtil.getStringValueOrUnknown(serialNumber), ParseUtil.getStringValueOrUnknown(uuid),
                ParseUtil.getStringValueOrUnknown(version));
    }

    /**
     * Parses the output of {@code dmidecode -t system} into its manufacturer, model, serial number, UUID, and version
     * fields. Any field not present in the output is returned as {@code null}; the caller applies fallbacks.
     *
     * @param dmidecode the lines emitted by {@code dmidecode -t system}
     * @return a {@link Quintet} of manufacturer, model, serial number, UUID, and version
     */
    static Quintet<@Nullable String, @Nullable String, @Nullable String, @Nullable String, @Nullable String> parseDmiDecode(
            List<String> dmidecode) {
        String manufacturer = null;
        String model = null;
        String serialNumber = null;
        String uuid = null;
        String version = null;

        final String manufacturerMarker = "Manufacturer:";
        final String productNameMarker = "Product Name:";
        final String serialNumMarker = "Serial Number:";
        final String uuidMarker = "UUID:";
        final String versionMarker = "Version:";

        for (final String checkLine : dmidecode) {
            if (checkLine.contains(manufacturerMarker)) {
                manufacturer = ParseUtil.getTextAfterString(checkLine, manufacturerMarker).trim();
            } else if (checkLine.contains(productNameMarker)) {
                model = ParseUtil.getTextAfterString(checkLine, productNameMarker).trim();
            } else if (checkLine.contains(serialNumMarker)) {
                serialNumber = ParseUtil.getTextAfterString(checkLine, serialNumMarker).trim();
            } else if (checkLine.contains(uuidMarker)) {
                uuid = ParseUtil.getTextAfterString(checkLine, uuidMarker).trim();
            } else if (checkLine.contains(versionMarker)) {
                version = ParseUtil.getTextAfterString(checkLine, versionMarker).trim();
            }
        }
        return new Quintet<>(manufacturer, model, serialNumber, uuid, version);
    }

    private static String querySystemSerialNumber() {
        String marker = "system.hardware.serial =";
        for (String checkLine : ExecutingCommand.runNative("lshal")) {
            if (checkLine.contains(marker)) {
                return ParseUtil.getSingleQuoteStringValue(checkLine);
            }
        }
        return Constants.UNKNOWN;
    }
}
