/*
 * Copyright 2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.unix.freebsd;

import static oshi.util.Memoizer.defaultExpiration;
import static oshi.util.Memoizer.memoize;

import java.util.List;
import java.util.function.Supplier;

import oshi.hardware.common.AbstractVirtualMemory;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;

/**
 * Abstract base for the FreeBSD VirtualMemory. Swap total and the paging counters come from the sysctl hooks the
 * subclasses implement ({@code vm.swap_total}, {@code vm.stats.vm.v_swappgsin} and {@code v_swappgsout}); swap usage is
 * read here from {@code swapinfo -k}.
 */
public abstract class FreeBsdVirtualMemory extends AbstractVirtualMemory {

    private final FreeBsdGlobalMemory global;

    private final Supplier<Long> used = memoize(FreeBsdVirtualMemory::querySwapUsed, defaultExpiration());
    private final Supplier<Long> total = memoize(this::querySwapTotal, defaultExpiration());
    private final Supplier<Long> pagesIn = memoize(this::queryPagesIn, defaultExpiration());
    private final Supplier<Long> pagesOut = memoize(this::queryPagesOut, defaultExpiration());

    /**
     * Constructs a new {@code FreeBsdVirtualMemory}.
     *
     * @param global the backing global memory
     */
    protected FreeBsdVirtualMemory(FreeBsdGlobalMemory global) {
        this.global = global;
    }

    @Override
    public long getSwapUsed() {
        return used.get();
    }

    @Override
    public long getSwapTotal() {
        return total.get();
    }

    @Override
    public long getVirtualMax() {
        return this.global.getTotal() + getSwapTotal();
    }

    @Override
    public long getVirtualInUse() {
        return this.global.getTotal() - this.global.getAvailable() + getSwapUsed();
    }

    @Override
    public long getSwapPagesIn() {
        return pagesIn.get();
    }

    @Override
    public long getSwapPagesOut() {
        return pagesOut.get();
    }

    /**
     * Reads {@code vm.swap_total} via the subclass's sysctl mechanism.
     *
     * @return the total swap size in bytes
     */
    protected abstract long querySwapTotal();

    /**
     * Reads {@code vm.stats.vm.v_swappgsin} via the subclass's sysctl mechanism.
     *
     * @return the cumulative pages-in count
     */
    protected abstract long queryPagesIn();

    /**
     * Reads {@code vm.stats.vm.v_swappgsout} via the subclass's sysctl mechanism.
     *
     * @return the cumulative pages-out count
     */
    protected abstract long queryPagesOut();

    // Pure command-line: swapinfo -k. Used bytes is column index 2, KB → bytes via << 10.
    private static long querySwapUsed() {
        return sumSwapUsed(ExecutingCommand.runNative("swapinfo -k"));
    }

    /**
     * Aggregates the "Used" column across every {@code swapinfo -k} device row. If a "Total" summary row is present
     * (e.g. when invoked with {@code -h} or {@code -T}) its value takes precedence; otherwise per-device rows are
     * summed. The header row and blank lines are skipped.
     *
     * @param swapInfoLines all lines from {@code swapinfo -k}, including the header
     * @return the total bytes of swap currently in use
     */
    static long sumSwapUsed(List<String> swapInfoLines) {
        long sum = 0L;
        long totalRow = -1L;
        for (String line : swapInfoLines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("Device")) {
                continue;
            }
            if (trimmed.startsWith("Total")) {
                totalRow = parseSwapUsed(trimmed);
                continue;
            }
            sum += parseSwapUsed(trimmed);
        }
        return totalRow >= 0L ? totalRow : sum;
    }

    /**
     * Extracts the "Used" column (index 2) from a single {@code swapinfo -k} data row and converts the KB value to
     * bytes. Returns 0 when the line is too short to be valid (fewer than 5 whitespace-separated columns).
     *
     * @param swapInfoRow a single data row from {@code swapinfo -k} (caller should trim leading whitespace)
     * @return the bytes used on this swap device
     */
    static long parseSwapUsed(String swapInfoRow) {
        String[] split = ParseUtil.whitespaces.split(swapInfoRow, -1);
        if (split.length < 5) {
            return 0L;
        }
        return ParseUtil.parseLongOrDefault(split[2], 0L) << 10;
    }
}
