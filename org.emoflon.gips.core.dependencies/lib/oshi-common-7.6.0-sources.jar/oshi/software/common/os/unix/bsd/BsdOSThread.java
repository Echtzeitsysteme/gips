/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.bsd;

import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.software.common.AbstractOSThread;
import oshi.software.os.OSProcess;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;

/**
 * Abstract base shared by the BSD-family OSThread implementations (FreeBSD, OpenBSD, DragonFly, NetBSD). Holds the
 * field storage, the trivial accessors, and the shared {@code ps} thread-row parsing. Differences in the available
 * columns (thread-id keyword, name, elapsed/cpu time, thread address) are handled by checking which keys are present.
 * Platform-specific work (the ordered column list and the {@code ps} command used to refresh a single thread) is
 * provided by the per-platform subclasses.
 */
@ThreadSafe
public abstract class BsdOSThread extends AbstractOSThread {

    /**
     * Constructs a new {@code BsdOSThread}.
     *
     * @param processId the owning process ID
     */
    protected BsdOSThread(int processId) {
        super(processId);
    }

    @Override
    public boolean updateAttributes() {
        List<BsdPsThreadKeyword> cols = psThreadKeywords();
        BsdPsThreadKeyword idKey = threadIdKeyword(cols);
        BsdPsThreadKeyword lastKey = cols.get(cols.size() - 1);
        // There is no -p switch for a single thread, so refresh the owning process's thread rows and filter to ours.
        String idStr = Integer.toString(this.threadId);
        for (String psOutput : ExecutingCommand.runNative(psThreadCommand() + " -p " + getOwningProcessId())) {
            Map<BsdPsThreadKeyword, String> threadMap = ParseUtil.stringToEnumMap(BsdPsThreadKeyword.class, cols,
                    psOutput.trim(), ' ');
            if (threadMap.containsKey(lastKey) && idStr.equals(threadMap.get(idKey))) {
                return updateAttributes(threadMap);
            }
        }
        this.state = OSProcess.State.INVALID;
        return false;
    }

    /**
     * Populates this thread's attributes from a parsed {@code ps} thread row. Shared by every BSD platform; differences
     * in the available columns are handled by checking which keys are present in the map.
     * <p>
     * Synchronized for the same reasons as {@link BsdOSProcess#updateAttributes(Map)}: it is the only writer of this
     * object's fields, reached both from {@link #updateAttributes()} and from each platform's constructor, and the lock
     * both makes the field set update atomically and makes the {@link BsdOSProcess#monotonic(long, long)}
     * read-modify-write safe against a racing refresh.
     *
     * @param threadMap the parsed {@code ps} columns for this thread
     * @return {@code true} once the attributes are populated
     */
    protected synchronized boolean updateAttributes(Map<BsdPsThreadKeyword, String> threadMap) {
        // Thread id: lwp (FreeBSD), tid (OpenBSD/DragonFly), or lid (NetBSD)
        this.threadId = ParseUtil.parseIntOrDefault(threadIdValue(threadMap), 0);
        String stateValue = ParseUtil.getStringValueOrEmpty(threadMap.get(BsdPsThreadKeyword.STATE));
        // An absent state column falls through to OTHER rather than failing the whole update
        this.state = BsdOSProcess.getStateFromOutput(stateValue.isEmpty() ? ' ' : stateValue.charAt(0));
        // Name: tdname (FreeBSD), args (OpenBSD/NetBSD), or absent (DragonFly leaves the default empty string)
        if (threadMap.containsKey(BsdPsThreadKeyword.TDNAME)) {
            this.name = threadMap.get(BsdPsThreadKeyword.TDNAME);
        } else if (threadMap.containsKey(BsdPsThreadKeyword.ARGS)) {
            this.name = threadMap.get(BsdPsThreadKeyword.ARGS);
        }
        // Kernel/user time: FreeBSD reports systime separately (time is user+sys); the others fold kernel time into a
        // single cputime/time column. Clamp both against a decrease; see BsdOSProcess.monotonic(long, long).
        if (threadMap.containsKey(BsdPsThreadKeyword.SYSTIME)) {
            long sysTime = ParseUtil.parseDHMSOrDefault(threadMap.get(BsdPsThreadKeyword.SYSTIME), 0L);
            this.kernelTime = BsdOSProcess.monotonic(this.kernelTime, sysTime);
            this.userTime = BsdOSProcess.monotonic(this.userTime,
                    ParseUtil.parseDHMSOrDefault(threadMap.get(BsdPsThreadKeyword.TIME), 0L) - sysTime);
        } else if (threadMap.containsKey(BsdPsThreadKeyword.CPUTIME)) {
            this.kernelTime = 0L;
            this.userTime = BsdOSProcess.monotonic(this.userTime,
                    ParseUtil.parseDHMSOrDefault(threadMap.get(BsdPsThreadKeyword.CPUTIME), 0L));
        } else {
            this.kernelTime = 0L;
            this.userTime = BsdOSProcess.monotonic(this.userTime,
                    ParseUtil.parseDHMSOrDefault(threadMap.get(BsdPsThreadKeyword.TIME), 0L));
        }
        // Start/up time: derived from the ps elapsed-time column where present; DragonFly's thread ps has none.
        long now = System.currentTimeMillis();
        if (threadMap.containsKey(BsdPsThreadKeyword.ETIMES) || threadMap.containsKey(BsdPsThreadKeyword.ETIME)) {
            BsdPsThreadKeyword elapsedKey = threadMap.containsKey(BsdPsThreadKeyword.ETIMES) ? BsdPsThreadKeyword.ETIMES
                    : BsdPsThreadKeyword.ETIME;
            long elapsedTime = ParseUtil.parseDHMSOrDefault(threadMap.get(elapsedKey), 0L);
            this.upTime = elapsedTime < 1L ? 1L : elapsedTime;
            this.startTime = now - this.upTime;
        } else {
            this.startTime = now;
            this.upTime = 1L;
        }
        this.startMemoryAddress = threadMap.containsKey(BsdPsThreadKeyword.TDADDR)
                ? ParseUtil.hexStringToLong(threadMap.get(BsdPsThreadKeyword.TDADDR), 0L)
                : 0L;
        this.contextSwitches = ParseUtil.parseLongOrDefault(threadMap.get(BsdPsThreadKeyword.NVCSW), 0L)
                + ParseUtil.parseLongOrDefault(threadMap.get(BsdPsThreadKeyword.NIVCSW), 0L);
        this.majorFaults = ParseUtil.parseLongOrDefault(threadMap.get(BsdPsThreadKeyword.MAJFLT), 0L);
        this.minorFaults = ParseUtil.parseLongOrDefault(threadMap.get(BsdPsThreadKeyword.MINFLT), 0L);
        this.priority = ParseUtil.parseIntOrDefault(threadMap.get(BsdPsThreadKeyword.PRI), 0);
        return true;
    }

    private static @Nullable String threadIdValue(Map<BsdPsThreadKeyword, String> threadMap) {
        if (threadMap.containsKey(BsdPsThreadKeyword.LWP)) {
            return threadMap.get(BsdPsThreadKeyword.LWP);
        }
        if (threadMap.containsKey(BsdPsThreadKeyword.TID)) {
            return threadMap.get(BsdPsThreadKeyword.TID);
        }
        return threadMap.get(BsdPsThreadKeyword.LID);
    }

    private static BsdPsThreadKeyword threadIdKeyword(List<BsdPsThreadKeyword> cols) {
        if (cols.contains(BsdPsThreadKeyword.LWP)) {
            return BsdPsThreadKeyword.LWP;
        }
        if (cols.contains(BsdPsThreadKeyword.TID)) {
            return BsdPsThreadKeyword.TID;
        }
        return BsdPsThreadKeyword.LID;
    }

    /**
     * Returns this platform's ordered {@code ps} thread column keys, used to parse thread rows positionally.
     *
     * @return the ordered thread column keys
     */
    protected abstract List<BsdPsThreadKeyword> psThreadKeywords();

    /**
     * Returns the {@code ps} command (without the trailing {@code -p <pid>}) used to enumerate this process's threads
     * when refreshing a single thread.
     *
     * @return the {@code ps} command prefix
     */
    protected abstract String psThreadCommand();
}
