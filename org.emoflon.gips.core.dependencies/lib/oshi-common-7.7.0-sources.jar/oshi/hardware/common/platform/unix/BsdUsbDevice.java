/*
 * Copyright 2021-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.unix;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.Immutable;
import oshi.hardware.UsbDevice;
import oshi.hardware.common.AbstractUsbDevice;
import oshi.util.ExecutingCommand;

/**
 * Shared USB device implementation for BSDs that use {@code usbdevs -v} to enumerate devices (NetBSD, OpenBSD).
 */
@Immutable
public final class BsdUsbDevice extends AbstractUsbDevice {

    /**
     * Constructs a new {@code BsdUsbDevice}.
     *
     * @param name             the device name
     * @param vendor           the vendor
     * @param vendorId         the vendor ID
     * @param productId        the product ID
     * @param serialNumber     the serial number
     * @param uniqueDeviceId   the unique device ID
     * @param connectedDevices the devices connected to this one
     */
    public BsdUsbDevice(String name, String vendor, String vendorId, String productId, String serialNumber,
            @Nullable String uniqueDeviceId, List<UsbDevice> connectedDevices) {
        super(name, vendor, vendorId, productId, serialNumber, uniqueDeviceId, connectedDevices);
    }

    /**
     * Instantiates the USB controller device tree. The flat form is derived by the caller (the HAL).
     *
     * @return a list of USB controllers, each with its connected-device tree.
     */
    public static List<UsbDevice> getUsbDevices() {
        return parseUsbDevices(ExecutingCommand.runNative("usbdevs -v"));
    }

    /**
     * Parses the output of {@code usbdevs -v} into a USB controller device tree. Each controller becomes a root device
     * whose children are the attached USB devices, building a hierarchy from the "Controller" and "addr" lines.
     *
     * @param usbdevs the lines emitted by {@code usbdevs -v}
     * @return a list of USB controller devices, each with its connected-device tree
     */
    static List<UsbDevice> parseUsbDevices(List<String> usbdevs) {
        Map<String, String> nameMap = new HashMap<>();
        Map<String, String> vendorMap = new HashMap<>();
        Map<String, String> vendorIdMap = new HashMap<>();
        Map<String, String> productIdMap = new HashMap<>();
        Map<String, String> serialMap = new HashMap<>();
        Map<String, List<String>> hubMap = new HashMap<>();

        List<String> rootHubs = new ArrayList<>();
        String key = "";
        String parent = "";
        for (String line : usbdevs) {
            if (line.startsWith("Controller ")) {
                parent = line.substring(11);
            } else if (line.startsWith("addr ")) {
                if (line.indexOf(':') == 7 && line.indexOf(',') >= 18) {
                    key = parent + line.substring(0, 7);
                    String[] split = line.substring(8).trim().split(",", -1);
                    if (split.length > 1) {
                        String vendorStr = split[0].trim();
                        int idx1 = vendorStr.indexOf(':');
                        int idx2 = vendorStr.indexOf(' ');
                        if (idx1 >= 0 && idx2 >= 0) {
                            vendorIdMap.put(key, vendorStr.substring(0, idx1));
                            productIdMap.put(key, vendorStr.substring(idx1 + 1, idx2));
                            vendorMap.put(key, vendorStr.substring(idx2 + 1));
                        }
                        nameMap.put(key, split[1].trim());
                        hubMap.computeIfAbsent(parent, x -> new ArrayList<>()).add(key);
                        if (!parent.contains("addr")) {
                            parent = key;
                            rootHubs.add(parent);
                        }
                    }
                }
            } else if (!key.isEmpty()) {
                int idx = line.indexOf("iSerial ");
                if (idx >= 0) {
                    serialMap.put(key, line.substring(idx + 8).trim());
                }
                key = "";
            }
        }

        List<UsbDevice> controllerDevices = new ArrayList<>();
        for (String devusb : rootHubs) {
            controllerDevices.add(buildDeviceTree(devusb, "0000", "0000", nameMap, vendorMap, vendorIdMap, productIdMap,
                    serialMap, hubMap, BsdUsbDevice::new));
        }
        return controllerDevices;
    }
}
