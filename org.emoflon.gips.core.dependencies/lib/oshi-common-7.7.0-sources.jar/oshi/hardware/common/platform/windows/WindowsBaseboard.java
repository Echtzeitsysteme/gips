/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.windows;

import static oshi.util.Memoizer.memoize;

import java.util.function.Supplier;

import oshi.annotation.concurrent.Immutable;
import oshi.driver.common.windows.wmi.Win32BaseBoard;
import oshi.driver.common.windows.wmi.Win32BaseBoard.BaseBoardProperty;
import oshi.driver.common.windows.wmi.WmiQueryExecutor;
import oshi.driver.common.windows.wmi.WmiResult;
import oshi.driver.common.windows.wmi.WmiUtil;
import oshi.hardware.common.AbstractBaseboard;
import oshi.util.ParseUtil;
import oshi.util.Util;
import oshi.util.tuples.Quartet;

/**
 * Baseboard data obtained from WMI. Subclasses provide the platform-specific {@link WmiQueryExecutor}.
 */
@Immutable
public abstract class WindowsBaseboard extends AbstractBaseboard {

    /** Default constructor. */
    protected WindowsBaseboard() {
    }

    private final Supplier<Quartet<String, String, String, String>> manufModelVersSerial = memoize(
            this::queryManufModelVersSerial);

    /**
     * Returns the WMI query executor for this platform.
     *
     * @return a non-null {@link WmiQueryExecutor}
     */
    protected abstract WmiQueryExecutor getWmiQueryExecutor();

    @Override
    public String getManufacturer() {
        return manufModelVersSerial.get().getA();
    }

    @Override
    public String getModel() {
        return manufModelVersSerial.get().getB();
    }

    @Override
    public String getVersion() {
        return manufModelVersSerial.get().getC();
    }

    @Override
    public String getSerialNumber() {
        return manufModelVersSerial.get().getD();
    }

    private Quartet<String, String, String, String> queryManufModelVersSerial() {
        String manufacturer = null;
        String model = null;
        String version = null;
        String serialNumber = null;
        WmiResult<BaseBoardProperty> win32BaseBoard = Win32BaseBoard.queryBaseboardInfo(getWmiQueryExecutor());
        if (win32BaseBoard.getResultCount() > 0) {
            manufacturer = WmiUtil.getString(win32BaseBoard, BaseBoardProperty.MANUFACTURER, 0);
            model = WmiUtil.getString(win32BaseBoard, BaseBoardProperty.MODEL, 0);
            String product = WmiUtil.getString(win32BaseBoard, BaseBoardProperty.PRODUCT, 0);
            if (!Util.isBlank(product)) {
                model = Util.isBlank(model) ? product : (model + " (" + product + ")");
            }
            version = WmiUtil.getString(win32BaseBoard, BaseBoardProperty.VERSION, 0);
            serialNumber = WmiUtil.getString(win32BaseBoard, BaseBoardProperty.SERIALNUMBER, 0);
        }
        return new Quartet<>(ParseUtil.getStringValueOrUnknown(manufacturer), ParseUtil.getStringValueOrUnknown(model),
                ParseUtil.getStringValueOrUnknown(version), ParseUtil.getStringValueOrUnknown(serialNumber));
    }
}
