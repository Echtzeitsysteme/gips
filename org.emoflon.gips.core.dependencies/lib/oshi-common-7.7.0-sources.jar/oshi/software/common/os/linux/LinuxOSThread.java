/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.linux;

import java.util.Locale;
import java.util.Map;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.software.common.AbstractOSThread;
import oshi.software.os.OSProcess.State;
import oshi.util.FileUtil;
import oshi.util.ParseUtil;
import oshi.util.driver.linux.proc.ProcessStat;
import oshi.util.linux.ProcPath;

/**
 * OSThread implementation
 */
@ThreadSafe
public class LinuxOSThread extends AbstractOSThread {

    private static final int[] PROC_TASK_STAT_ORDERS = buildProcTaskStatOrders();

    // ThreadPidStat.ordinal() only indexes this class's own lookup table, built from ThreadPidStat.values() itself
    @SuppressWarnings("EnumOrdinal")
    private static int[] buildProcTaskStatOrders() {
        int[] orders = new int[ThreadPidStat.values().length];
        for (ThreadPidStat stat : ThreadPidStat.values()) {
            // The PROC_PID_STAT enum indices are 1-indexed.
            // Subtract one to get a zero-based index
            orders[stat.ordinal()] = stat.getOrder() - 1;
        }
        return orders;
    }

    private final LinuxOperatingSystem os;

    /**
     * Creates a LinuxOSThread.
     *
     * @param processId the owning process ID
     * @param tid       the thread ID
     * @param os        the operating system
     */
    public LinuxOSThread(int processId, int tid, LinuxOperatingSystem os) {
        super(processId);
        this.threadId = tid;
        this.os = os;
        updateAttributes();
    }

    // ThreadPidStat.ordinal() only indexes statArray, built from ThreadPidStat.values() itself via
    // PROC_TASK_STAT_ORDERS
    @SuppressWarnings("EnumOrdinal")
    @Override
    public synchronized boolean updateAttributes() {
        this.name = FileUtil.getStringFromFile(
                String.format(Locale.ROOT, ProcPath.TASK_COMM, this.getOwningProcessId(), this.threadId));
        Map<String, String> status = FileUtil.getKeyValueMapFromFile(
                String.format(Locale.ROOT, ProcPath.TASK_STATUS, this.getOwningProcessId(), this.threadId), ":");
        String stat = FileUtil.getStringFromFile(
                String.format(Locale.ROOT, ProcPath.TASK_STAT, this.getOwningProcessId(), this.threadId));
        if (stat.isEmpty()) {
            this.state = State.INVALID;
            return false;
        }
        long now = System.currentTimeMillis();
        long[] statArray = ParseUtil.parseStringToLongArray(stat, PROC_TASK_STAT_ORDERS,
                ProcessStat.PROC_PID_STAT_LENGTH, ' ');

        // BOOTTIME is in seconds and start time from proc/pid/stat is in jiffies.
        // Combine units to jiffies and convert to millijiffies before hz division to
        // avoid precision loss without having to cast
        this.startTime = (LinuxOperatingSystem.getBootTime() * os.getHz()
                + statArray[LinuxOSThread.ThreadPidStat.START_TIME.ordinal()]) * 1000L / os.getHz();
        // BOOT_TIME could be up to 500ms off and start time up to 5ms off. A process
        // that has started within last 505ms could produce a future start time/negative
        // up time, so insert a sanity check.
        if (this.startTime >= now) {
            this.startTime = now - 1;
        }
        this.minorFaults = statArray[ThreadPidStat.MINOR_FAULTS.ordinal()];
        this.majorFaults = statArray[ThreadPidStat.MAJOR_FAULT.ordinal()];
        this.startMemoryAddress = statArray[ThreadPidStat.START_CODE.ordinal()];
        long voluntaryContextSwitches = ParseUtil.parseLongOrDefault(status.get("voluntary_ctxt_switches"), 0L);
        long nonVoluntaryContextSwitches = ParseUtil.parseLongOrDefault(status.get("nonvoluntary_ctxt_switches"), 0L);
        this.contextSwitches = voluntaryContextSwitches + nonVoluntaryContextSwitches;
        this.state = ProcessStat.getState(status.getOrDefault("State", "U").charAt(0));
        this.kernelTime = statArray[ThreadPidStat.KERNEL_TIME.ordinal()] * 1000L / os.getHz();
        this.userTime = statArray[ThreadPidStat.USER_TIME.ordinal()] * 1000L / os.getHz();
        this.upTime = now - startTime;
        this.priority = (int) statArray[ThreadPidStat.PRIORITY.ordinal()];
        return true;
    }

    /**
     * Enum used to update attributes. The order field represents the 1-indexed numeric order of the stat in
     * /proc/pid/task/tid/stat per the man file.
     */
    private enum ThreadPidStat {
        // The parsing implementation in ParseUtil requires these to be declared
        // in increasing order
        /** PPID property. */
        PPID(4),
        /** MINOR_FAULTS property. */
        MINOR_FAULTS(10),
        /** MAJOR_FAULT property. */
        MAJOR_FAULT(12),
        /** USER_TIME property. */
        USER_TIME(14),
        /** KERNEL_TIME property. */
        KERNEL_TIME(15),
        /** PRIORITY property. */
        PRIORITY(18),
        /** THREAD_COUNT property. */
        THREAD_COUNT(20),
        /** START_TIME property. */
        START_TIME(22),
        /** VSZ property. */
        VSZ(23),
        /** RSS property. */
        RSS(24),
        /** START_CODE property. */
        START_CODE(26);

        private final int order;

        ThreadPidStat(int order) {
            this.order = order;
        }

        int getOrder() {
            return this.order;
        }
    }
}
