/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.mac;

import java.nio.file.PathMatcher;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.software.common.AbstractFileSystem;
import oshi.util.FileSystemUtil;

/**
 * Common constants and configuration for macOS file system implementations.
 */
@ThreadSafe
public abstract class MacFileSystem extends AbstractFileSystem {

    /**
     * Default constructor.
     */
    protected MacFileSystem() {
    }

    /** Configuration key for path excludes. */
    public static final String OSHI_MAC_FS_PATH_EXCLUDES = "oshi.os.mac.filesystem.path.excludes";
    /** Configuration key for path includes. */
    public static final String OSHI_MAC_FS_PATH_INCLUDES = "oshi.os.mac.filesystem.path.includes";
    /** Configuration key for volume excludes. */
    public static final String OSHI_MAC_FS_VOLUME_EXCLUDES = "oshi.os.mac.filesystem.volume.excludes";
    /** Configuration key for volume includes. */
    public static final String OSHI_MAC_FS_VOLUME_INCLUDES = "oshi.os.mac.filesystem.volume.includes";

    /** File system path exclude matchers. */
    protected static final List<PathMatcher> FS_PATH_EXCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_MAC_FS_PATH_EXCLUDES);
    /** File system path include matchers. */
    protected static final List<PathMatcher> FS_PATH_INCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_MAC_FS_PATH_INCLUDES);
    /** File system volume exclude matchers. */
    protected static final List<PathMatcher> FS_VOLUME_EXCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_MAC_FS_VOLUME_EXCLUDES);
    /** File system volume include matchers. */
    protected static final List<PathMatcher> FS_VOLUME_INCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_MAC_FS_VOLUME_INCLUDES);

    /** Pattern matching local disk device paths. */
    protected static final Pattern LOCAL_DISK = Pattern.compile("/dev/disk\\d+(s\\d+)?");

    /** Mount flag: read-only. */
    protected static final int MNT_RDONLY = 0x00000001;
    /** Mount flag: synchronous. */
    protected static final int MNT_SYNCHRONOUS = 0x00000002;
    /** Mount flag: no exec. */
    protected static final int MNT_NOEXEC = 0x00000004;
    /** Mount flag: no setuid. */
    protected static final int MNT_NOSUID = 0x00000008;
    /** Mount flag: no device access. */
    protected static final int MNT_NODEV = 0x00000010;
    /** Mount flag: union. */
    protected static final int MNT_UNION = 0x00000020;
    /** Mount flag: asynchronous. */
    protected static final int MNT_ASYNC = 0x00000040;
    /** Mount flag: content protection. */
    protected static final int MNT_CPROTECT = 0x00000080;
    /** Mount flag: exported. */
    protected static final int MNT_EXPORTED = 0x00000100;
    /** Mount flag: quarantined. */
    protected static final int MNT_QUARANTINE = 0x00000400;
    /** Mount flag: local. */
    protected static final int MNT_LOCAL = 0x00001000;
    /** Mount flag: quotas. */
    protected static final int MNT_QUOTA = 0x00002000;
    /** Mount flag: root filesystem. */
    protected static final int MNT_ROOTFS = 0x00004000;
    /** Mount flag: volfs. */
    protected static final int MNT_DOVOLFS = 0x00008000;
    /** Mount flag: don't browse. */
    protected static final int MNT_DONTBROWSE = 0x00100000;
    /** Mount flag: ignore ownership. */
    protected static final int MNT_IGNORE_OWNERSHIP = 0x00200000;
    /** Mount flag: automounted. */
    protected static final int MNT_AUTOMOUNTED = 0x00400000;
    /** Mount flag: journaled. */
    protected static final int MNT_JOURNALED = 0x00800000;
    /** Mount flag: no user extended attributes. */
    protected static final int MNT_NOUSERXATTR = 0x01000000;
    /** Mount flag: deferred writes. */
    protected static final int MNT_DEFWRITE = 0x02000000;
    /** Mount flag: multilabel MAC. */
    protected static final int MNT_MULTILABEL = 0x04000000;
    /** Mount flag: no access time. */
    protected static final int MNT_NOATIME = 0x10000000;

    /** Map of mount flags to option strings. */
    protected static final Map<Integer, String> OPTIONS_MAP = new HashMap<>();
    static {
        OPTIONS_MAP.put(MNT_SYNCHRONOUS, "synchronous");
        OPTIONS_MAP.put(MNT_NOEXEC, "noexec");
        OPTIONS_MAP.put(MNT_NOSUID, "nosuid");
        OPTIONS_MAP.put(MNT_NODEV, "nodev");
        OPTIONS_MAP.put(MNT_UNION, "union");
        OPTIONS_MAP.put(MNT_ASYNC, "asynchronous");
        OPTIONS_MAP.put(MNT_CPROTECT, "content-protection");
        OPTIONS_MAP.put(MNT_EXPORTED, "exported");
        OPTIONS_MAP.put(MNT_QUARANTINE, "quarantined");
        OPTIONS_MAP.put(MNT_LOCAL, "local");
        OPTIONS_MAP.put(MNT_QUOTA, "quotas");
        OPTIONS_MAP.put(MNT_ROOTFS, "rootfs");
        OPTIONS_MAP.put(MNT_DOVOLFS, "volfs");
        OPTIONS_MAP.put(MNT_DONTBROWSE, "nobrowse");
        OPTIONS_MAP.put(MNT_IGNORE_OWNERSHIP, "noowners");
        OPTIONS_MAP.put(MNT_AUTOMOUNTED, "automounted");
        OPTIONS_MAP.put(MNT_JOURNALED, "journaled");
        OPTIONS_MAP.put(MNT_NOUSERXATTR, "nouserxattr");
        OPTIONS_MAP.put(MNT_DEFWRITE, "defwrite");
        OPTIONS_MAP.put(MNT_MULTILABEL, "multilabel");
        OPTIONS_MAP.put(MNT_NOATIME, "noatime");
    }

    @Override
    public long getOpenFileDescriptors() {
        return querySysctl("kern.num_files");
    }

    @Override
    public long getMaxFileDescriptors() {
        return querySysctl("kern.maxfiles");
    }

    @Override
    public long getMaxFileDescriptorsPerProcess() {
        return querySysctl("kern.maxfilesperproc");
    }

    /**
     * Reads a system-wide file-descriptor {@code sysctl} value via the subclass's native mechanism (JNA or FFM).
     *
     * @param name the sysctl name to query
     * @return the value, or 0 if unavailable
     */
    protected abstract long querySysctl(String name);
}
