/*
 * Copyright 2021-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.netbsd;

import static oshi.software.common.os.unix.bsd.BsdPsKeyword.ARGS;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.CPUTIME;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.ETIME;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.GID;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.GROUP;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.MAJFLT;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.MINFLT;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.NIVCSW;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.NVCSW;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.PID;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.PPID;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.PRI;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.RSS;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.STATE;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.UID;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.USER;
import static oshi.software.common.os.unix.bsd.BsdPsKeyword.VSZ;
import static oshi.software.os.OSThread.ThreadFiltering.VALID_THREAD;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.software.common.os.unix.bsd.BsdOSProcess;
import oshi.software.common.os.unix.bsd.BsdPsKeyword;
import oshi.software.common.os.unix.bsd.BsdPsThreadKeyword;
import oshi.software.os.OSThread;
import oshi.util.ExecutingCommand;
import oshi.util.FileUtil;
import oshi.util.ParseUtil;
import oshi.util.Util;
import oshi.util.common.platform.unix.bsd.BsdSysctlUtil;
import oshi.util.common.platform.unix.netbsd.FstatUtil;

/**
 * OSProcess implementation
 */
@ThreadSafe
public class NetBsdOSProcess extends BsdOSProcess {
    private static final Pattern AFFINITY = Pattern.compile("Affinity:");
    private static final Pattern COMMA_OR_WHITESPACE = Pattern.compile("[,\\s]+");
    private static final int ARGS_READ_ATTEMPTS_SELF = 15;
    private static final int ARGS_READ_ATTEMPTS_OTHER = 2;
    private static final long ARGS_READ_RETRY_MILLIS = 20L;

    /**
     * Ordered {@code ps} columns queried for each process. Shared by NetBsdOSProcess and the NetBSD OperatingSystem so
     * the column list and parsing stay in lockstep. {@code ARGS} must remain last.
     */
    public static final List<BsdPsKeyword> PS_KEYWORDS = Collections.unmodifiableList(Arrays.asList(STATE, PID, PPID,
            USER, UID, GROUP, GID, PRI, VSZ, RSS, ETIME, CPUTIME, MAJFLT, MINFLT, NVCSW, NIVCSW, ARGS));

    public static final String PS_COMMAND_ARGS = PS_KEYWORDS.stream().map(Enum::name)
            .map(name -> name.toLowerCase(Locale.ROOT)).collect(Collectors.joining(","));

    protected final NetBsdOperatingSystem os;

    /**
     * Constructs a new {@code NetBsdOSProcess}.
     *
     * @param pid   the process ID
     * @param psMap the parsed {@code ps} columns for this process
     * @param os    the owning operating system
     */
    public NetBsdOSProcess(int pid, Map<BsdPsKeyword, String> psMap, NetBsdOperatingSystem os) {
        super(pid);
        this.os = os;
        updateAttributes(psMap);
    }

    @Override
    protected List<BsdPsKeyword> psKeywords() {
        return PS_KEYWORDS;
    }

    @Override
    protected String psCommandArgs() {
        return PS_COMMAND_ARGS;
    }

    @Override
    protected String queryPath(Map<BsdPsKeyword, String> psMap) {
        // NetBSD's ps prints argv[0] in the comm column, the same value the args column begins with, but clips it to
        // the width of its "COMMAND" header - seven characters - because only the last column is left unbounded. So the
        // path is taken from the args column, which is queried last and is therefore printed in full.
        String argv = parseArgv0(psMap.get(BsdPsKeyword.ARGS));
        // The placeholder says the arguments were unavailable, so no path is known
        return isPlaceholder(argv) ? "" : argv;
    }

    @Override
    protected String queryCommandLineBackup(Map<BsdPsKeyword, String> psMap) {
        return parseCommandLine(psMap.get(BsdPsKeyword.ARGS));
    }

    /**
     * Extracts the command line from a {@code ps} args column.
     *
     * @param args the args column, the process's arguments separated by spaces
     * @return the arguments, or an empty string where {@code ps} substituted the parenthesized command because the
     *         kernel would not release them, which is a placeholder rather than a command line
     */
    static String parseCommandLine(@Nullable String args) {
        String argv = ParseUtil.getStringValueOrEmpty(args);
        return isPlaceholder(parseArgv0(argv)) ? "" : argv;
    }

    @Override
    protected String queryName(Map<BsdPsKeyword, String> psMap, String path) {
        String argv = parseArgv0(psMap.get(BsdPsKeyword.ARGS));
        // The placeholder wraps the kernel's own name for the process, which is the name whether or not the arguments
        // could be read; unwrap it rather than reporting ps's punctuation as the name
        return isPlaceholder(argv) ? argv.substring(1, argv.length() - 1) : path.substring(path.lastIndexOf('/') + 1);
    }

    /**
     * Extracts {@code argv[0]} from a {@code ps} args column.
     *
     * @param args the args column, the process's arguments separated by spaces
     * @return {@code argv[0]}, which is a path when the process was started by one, or the command in parentheses where
     *         the kernel would not release the arguments
     */
    static String parseArgv0(@Nullable String args) {
        String argv = ParseUtil.getStringValueOrEmpty(args).trim();
        int space = argv.indexOf(' ');
        return space < 0 ? argv : argv.substring(0, space);
    }

    /**
     * Whether a {@code ps} args column holds the parenthesized command that {@code ps} substitutes when the kernel
     * refuses a process's arguments, which it does while that process is inside {@code posix_spawn}.
     *
     * @param argv the value from {@link #parseArgv0(String)}
     * @return {@code true} if it is that placeholder rather than a real {@code argv[0]}
     */
    static boolean isPlaceholder(String argv) {
        return argv.length() > 2 && argv.charAt(0) == '(' && argv.charAt(argv.length() - 1) == ')';
    }

    @Override
    protected List<String> queryArguments() {
        // NetBSD provides command line via /proc filesystem
        String cmdline = "/proc/" + getProcessID() + "/cmdline";
        // The kernel refuses to read a process's arguments while that process is inside posix_spawn, which a JVM is
        // whenever it runs a command, so an empty read of a file that exists is retried. This process is the case OSHI
        // provokes itself, by running ps while another thread spawns, and so is given the longer budget; for any other
        // process an empty read is usually genuine. The result is memoized for the life of this object, so a single
        // refusal would otherwise stick.
        int attempts = getProcessID() == this.os.getProcessId() ? ARGS_READ_ATTEMPTS_SELF : ARGS_READ_ATTEMPTS_OTHER;
        for (int attempt = 1;; attempt++) {
            byte[] cmdBytes = FileUtil.readAllBytes(cmdline, false);
            if (cmdBytes.length > 0) {
                return Collections.unmodifiableList(ParseUtil.parseByteArrayToStrings(cmdBytes));
            }
            if (attempt >= attempts || !new File(cmdline).exists()) {
                return Collections.emptyList();
            }
            Util.sleep(ARGS_READ_RETRY_MILLIS);
        }
    }

    @Override
    protected Map<String, String> queryEnvironmentVariables() {
        // For the current process, use Java's System.getenv()
        if (getProcessID() == this.os.getProcessId()) {
            return System.getenv();
        }
        return parseEnvironment(queryEnvironmentBytes());
    }

    /**
     * Queries the environment of this process from the kernel, the {@code kern.proc_args} sysctl with
     * {@code KERN_PROC_ENV}.
     *
     * @return The NUL-delimited {@code KEY=VALUE} entries, or an empty array if this build cannot make the call; NetBSD
     *         offers no command that reads another process's environment
     */
    protected byte[] queryEnvironmentBytes() {
        return new byte[0];
    }

    /**
     * Parses the environment returned by the {@code kern.proc_args} sysctl.
     *
     * @param envBytes NUL-delimited {@code KEY=VALUE} entries
     * @return the environment, empty if there were no entries
     */
    static Map<String, String> parseEnvironment(byte[] envBytes) {
        // Parse by raw bytes rather than by String offsets, which would misalign on a multibyte charset
        Map<String, String> env = new LinkedHashMap<>();
        for (String envStr : ParseUtil.parseByteArrayToStrings(envBytes)) {
            int idx = envStr.indexOf('=');
            if (idx > 0) {
                env.put(envStr.substring(0, idx), envStr.substring(idx + 1));
            }
        }
        return env.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(env);
    }

    @Override
    public String getCurrentWorkingDirectory() {
        return FstatUtil.getCwd(getProcessID());
    }

    @Override
    public long getOpenFiles() {
        return FstatUtil.getOpenFiles(getProcessID());
    }

    @Override
    public long getSoftOpenFileLimit() {
        if (getProcessID() == this.os.getProcessId()) {
            // This process's own limit where a backend can call getrlimit, the system-wide maximum otherwise
            long limit = queryRlimitNofile(true);
            if (limit >= 0) {
                return limit;
            }
            limit = BsdSysctlUtil.sysctl("kern.maxfilesperproc", 0L);
            if (limit <= 0) {
                limit = BsdSysctlUtil.sysctl("kern.maxfiles", 0L);
            }
            return limit > 0 ? limit : -1L;
        }
        return -1L;
    }

    @Override
    public long getHardOpenFileLimit() {
        if (getProcessID() == this.os.getProcessId()) {
            long limit = queryRlimitNofile(false);
            if (limit >= 0) {
                return limit;
            }
            limit = BsdSysctlUtil.sysctl("kern.maxfiles", 0L);
            return limit > 0 ? limit : -1L;
        }
        return -1L;
    }

    @Override
    protected int queryBitness() {
        // NetBSD does not maintain a compatibility layer.
        // Process bitness is OS bitness
        return System.getProperty("os.arch", "").contains("64") ? 64 : 32;
    }

    @Override
    public long getAffinityMask() {
        long bitMask = 0L;
        // schedctl -p <pid> shows affinity; -A cpus would set it
        List<String> schedctl = ExecutingCommand.runNative("schedctl -p " + getProcessID());
        for (String line : schedctl) {
            // Output includes "Affinity: <list>" when bound
            if (line.contains("Affinity:")) {
                String[] parts = COMMA_OR_WHITESPACE.split(AFFINITY.split(line, -1)[1].trim(), -1);
                for (String part : parts) {
                    int bitToSet = ParseUtil.parseIntOrDefault(part.trim(), -1);
                    if (bitToSet >= 0) {
                        bitMask |= 1L << bitToSet;
                    }
                }
                return bitMask;
            }
        }
        // Not bound — return all CPUs
        int ncpu = BsdSysctlUtil.sysctl("hw.ncpuonline", 1);
        return ncpu < 64 ? (1L << ncpu) - 1 : -1L;
    }

    @Override
    public List<OSThread> getThreadDetails() {
        // NetBSD ps shows per-LWP rows when lid is in the format specifier
        String psCommand = "ps -awwxo " + NetBsdOSThread.PS_THREAD_COLUMNS;
        if (getProcessID() >= 0) {
            psCommand += " -p " + getProcessID();
        }
        Predicate<Map<BsdPsThreadKeyword, String>> hasColumnsArgs = threadMap -> threadMap
                .containsKey(BsdPsThreadKeyword.ARGS);
        return ExecutingCommand.runNative(psCommand).stream().skip(1).parallel()
                .map(thread -> ParseUtil.stringToEnumMap(BsdPsThreadKeyword.class, NetBsdOSThread.PS_THREAD_KEYWORDS,
                        thread.trim(), ' '))
                .filter(hasColumnsArgs).map(threadMap -> new NetBsdOSThread(getProcessID(), threadMap))
                .filter(VALID_THREAD).collect(Collectors.toList());
    }

    @Override
    protected void updateThreadCount() {
        // Use nlwp keyword to get LWP count for this process
        List<String> nlwpList = ExecutingCommand.runNative("ps -o nlwp -p " + getProcessID());
        if (nlwpList.size() > 1) {
            this.threadCount = ParseUtil.parseIntOrDefault(nlwpList.get(1).trim(), 1);
        } else {
            this.threadCount = 1;
        }
    }
}
