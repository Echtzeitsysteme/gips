/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.solaris;

import static oshi.software.os.OSProcess.State.INVALID;
import static oshi.software.os.OSProcess.State.OTHER;
import static oshi.software.os.OSProcess.State.RUNNING;
import static oshi.software.os.OSProcess.State.SLEEPING;
import static oshi.software.os.OSProcess.State.STOPPED;
import static oshi.software.os.OSProcess.State.WAITING;
import static oshi.software.os.OSProcess.State.ZOMBIE;
import static oshi.util.Memoizer.defaultExpiration;
import static oshi.util.Memoizer.memoize;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import oshi.driver.common.unix.solaris.PsInfo;
import oshi.driver.common.unix.solaris.SolarisPrUsage;
import oshi.driver.common.unix.solaris.SolarisPsInfo;
import oshi.software.common.os.unix.AbstractProcOSProcess;
import oshi.software.os.OSThread;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;
import oshi.util.UserGroupInfo;
import oshi.util.tuples.Pair;

/**
 * Abstract base for Solaris OSProcess. The {@code /proc} parsing, command-line/env memoization, thread enumeration, and
 * field assignment are shared (via {@link AbstractProcOSProcess}); concrete subclasses (JNA/FFM) provide the
 * {@code queryArgsEnv} read, the self-process {@code rlimit} read, and the {@link OSThread} factory.
 */
public abstract class SolarisOSProcess extends AbstractProcOSProcess {

    private final Supplier<@Nullable SolarisPsInfo> psinfo = memoize(this::queryPsInfo, defaultExpiration());
    private final Supplier<@Nullable SolarisPrUsage> prusage = memoize(this::queryPrUsage, defaultExpiration());

    private volatile long minorFaults;
    private volatile long majorFaults;
    private volatile long voluntaryContextSwitches;
    private volatile long involuntaryContextSwitches;

    /**
     * Constructs a new {@code SolarisOSProcess}.
     *
     * @param pid the process ID
     */
    protected SolarisOSProcess(int pid) {
        super(pid);
    }

    private @Nullable SolarisPsInfo queryPsInfo() {
        return PsInfo.queryPsInfo(this.getProcessID());
    }

    private @Nullable SolarisPrUsage queryPrUsage() {
        return PsInfo.queryPrUsage(this.getProcessID());
    }

    /**
     * Returns the memoized {@code psinfo} for this process, for subclasses that need its arg/env offset pointers.
     *
     * @return the parsed {@link SolarisPsInfo}, or {@code null} if it could not be read
     */
    protected @Nullable SolarisPsInfo getPsInfo() {
        return psinfo.get();
    }

    @Override
    protected Pair<List<String>, Map<String, String>> queryCommandlineEnvironment() {
        return queryArgsEnv();
    }

    @Override
    public long getMinorFaults() {
        return this.minorFaults;
    }

    @Override
    public long getMajorFaults() {
        return this.majorFaults;
    }

    @Override
    public long getVoluntaryContextSwitches() {
        return this.voluntaryContextSwitches;
    }

    @Override
    public long getInvoluntaryContextSwitches() {
        return this.involuntaryContextSwitches;
    }

    @Override
    public long getAffinityMask() {
        long mask = parsePbindOutput(ExecutingCommand.getFirstAnswer("pbind -q " + getProcessID()));
        return mask != 0L ? mask : parsePsrinfo(ExecutingCommand.runNative("psrinfo"));
    }

    /**
     * Parses the output of {@code pbind -q <pid>} to determine the processor affinity bitmask.
     *
     * @param cpuset the single-line output from {@code pbind -q}
     * @return the bitmask of bound processors, or 0 if not bound or empty
     */
    static long parsePbindOutput(String cpuset) {
        long bitMask = 0L;
        // Sample output:
        // <empty string if no binding>
        // pid 101048 strongly bound to processor(s) 0 1 2 3.
        if (cpuset.isEmpty()) {
            return 0L;
        } else if (cpuset.endsWith(".") && cpuset.contains("strongly bound to processor(s)")) {
            String parse = cpuset.substring(0, cpuset.length() - 1);
            String[] split = ParseUtil.whitespaces.split(parse.trim(), -1);
            for (int i = split.length - 1; i >= 0; i--) {
                int bitToSet = ParseUtil.parseIntOrDefault(split[i], -1);
                if (bitToSet >= 0) {
                    bitMask |= 1L << bitToSet;
                } else {
                    // Once we run into the word processor(s) we're done
                    break;
                }
            }
        }
        return bitMask;
    }

    /**
     * Parses the output of {@code psrinfo} to build a bitmask of all available processors.
     *
     * @param psrinfo the lines emitted by {@code psrinfo}
     * @return a bitmask with a bit set for each processor listed
     */
    static long parsePsrinfo(List<String> psrinfo) {
        long bitMask = 0L;
        for (String proc : psrinfo) {
            String[] split = ParseUtil.whitespaces.split(proc, -1);
            int bitToSet = ParseUtil.parseIntOrDefault(split[0], -1);
            if (bitToSet >= 0) {
                bitMask |= 1L << bitToSet;
            }
        }
        return bitMask;
    }

    @Override
    public synchronized boolean updateAttributes() {
        SolarisPsInfo info = psinfo.get();
        if (info == null) {
            this.state = INVALID;
            return false;
        }
        SolarisPrUsage usage = prusage.get();
        long now = System.currentTimeMillis();
        this.state = getStateFromOutput((char) info.pr_lwp.pr_sname);
        this.parentProcessID = info.pr_ppid;
        this.userID = Integer.toString(info.pr_euid);
        this.user = UserGroupInfo.getUser(this.userID);
        this.groupID = Integer.toString(info.pr_egid);
        this.group = UserGroupInfo.getGroupName(this.groupID);
        this.threadCount = info.pr_nlwp;
        this.priority = info.pr_lwp.pr_pri;
        // These are in KB, multiply
        this.virtualSize = info.pr_size * 1024;
        this.residentSetSize = info.pr_rssize * 1024;
        this.privateResidentMemory = info.pr_rssizepriv * 1024;
        this.startTime = info.pr_start.toMillis();
        // Avoid divide by zero for processes up less than a millisecond
        long elapsedTime = now - this.startTime;
        this.upTime = elapsedTime < 1L ? 1L : elapsedTime;
        this.kernelTime = 0L;
        this.userTime = info.pr_time.toMillis();
        // 80 character truncation but enough for path and name (usually)
        this.commandLineBackup = PsInfo.bytesToString(info.pr_psargs);
        String[] parts = ParseUtil.whitespaces.split(commandLineBackup, -1);
        this.path = parts.length > 0 ? parts[0] : "";
        this.name = this.path.substring(this.path.lastIndexOf('/') + 1);
        if (usage != null) {
            this.userTime = usage.pr_utime.toMillis();
            this.kernelTime = usage.pr_stime.toMillis();
            this.bytesRead = usage.pr_ioch;
            this.majorFaults = usage.pr_majf;
            this.minorFaults = usage.pr_minf;
            this.voluntaryContextSwitches = usage.pr_vctx;
            this.involuntaryContextSwitches = usage.pr_ictx;
        }
        return true;
    }

    /***
     * Returns Enum STATE for the state value obtained from status string of thread/process.
     *
     * @param stateValue state value from the status string
     * @return The state
     */
    public static State getStateFromOutput(char stateValue) {
        State state;
        switch (stateValue) {
            case 'O':
                state = RUNNING;
                break;
            case 'S':
                state = SLEEPING;
                break;
            case 'R':
            case 'W':
                state = WAITING;
                break;
            case 'Z':
                state = ZOMBIE;
                break;
            case 'T':
                state = STOPPED;
                break;
            default:
                state = OTHER;
                break;
        }
        return state;
    }

    /**
     * Parses the soft or hard open-file limit for another process from {@code plimit}.
     *
     * @param processId the process ID
     * @param index     {@code 1} for the soft limit, {@code 2} for the hard limit
     * @return the limit, or {@code -1} if unavailable
     */
    protected static long getProcessOpenFileLimit(long processId, int index) {
        return parseOpenFileLimit(ExecutingCommand.runNative("plimit " + processId), index);
    }

    /**
     * Parses the output of {@code plimit <pid>} to extract the open-file limit.
     *
     * @param plimitOutput the lines emitted by {@code plimit <pid>}
     * @param index        {@code 1} for the soft limit, {@code 2} for the hard limit
     * @return the limit value, or {@code -1} if unavailable
     */
    static long parseOpenFileLimit(List<String> plimitOutput, int index) {
        if (plimitOutput.isEmpty()) {
            return -1; // not supported
        }
        final Optional<String> nofilesLine = plimitOutput.stream().filter(line -> line.trim().startsWith("nofiles"))
                .findFirst();
        if (!nofilesLine.isPresent()) {
            return -1;
        }
        // Split all non-digits away -> ["", "{soft-limit}", "{hard-limit}"]. -1 preserves the trailing empty
        // token that a non-numeric limit produces (e.g. "nofiles(descriptors) 256 unlimited" -> ["", "256", ""],
        // since "unlimited" is itself consumed as trailing non-digit delimiter text); parseLongOrDefault below
        // then falls back to -1 for that position instead of throwing.
        final String[] split = ParseUtil.notDigits.split(nofilesLine.get(), -1);
        if (split.length <= index) {
            return -1;
        }
        return ParseUtil.parseLongOrDefault(split[index], -1);
    }

    /**
     * Reads this process's argument list and environment.
     *
     * @return a pair of (arg list, env map); either may be empty if it cannot be read
     */
    protected abstract Pair<List<String>, Map<String, String>> queryArgsEnv();
}
