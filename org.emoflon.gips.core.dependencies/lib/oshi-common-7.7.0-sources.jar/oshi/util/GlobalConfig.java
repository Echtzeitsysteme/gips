/*
 * Copyright 2019-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oshi.annotation.concurrent.NotThreadSafe;
import oshi.hardware.CentralProcessor;

/**
 * The global configuration utility. See {@code src/main/resources/oshi.properties} for default values.
 * <p>
 * Configuration is resolved in the following precedence order (highest wins):
 * <ol>
 * <li>{@link #set(String, Object)} — programmatic, at runtime</li>
 * <li>Java system properties ({@code -Doshi.*})</li>
 * <li>Environment variables ({@code OSHI_*}) — mapped by uppercasing and replacing dots with underscores</li>
 * <li>External properties file ({@code -Doshi.properties.file=/path/to/file})</li>
 * <li>{@code oshi.properties} on the classpath (defaults)</li>
 * </ol>
 * <p>
 * This class is not thread safe if methods manipulating the configuration are used. These methods are intended for use
 * by a single thread at startup, before instantiation of any other OSHI classes. OSHI does not guarantee re-reading of
 * any configuration changes.
 */
@NotThreadSafe
public final class GlobalConfig {

    private static final String OSHI_PROPERTIES = "oshi.properties";

    private static final Logger LOG = LoggerFactory.getLogger(GlobalConfig.class);

    private static final Properties CONFIG = FileUtil.readPropertiesFromFilename(OSHI_PROPERTIES);
    static {
        loadExternalConfig(CONFIG);
    }

    // package-private for testing
    static void loadExternalConfig(Properties config) {
        // External properties file: system property takes precedence, env var as fallback
        String externalFile = System.getProperty("oshi.properties.file");
        if (externalFile == null || externalFile.isEmpty()) {
            externalFile = System.getenv("OSHI_PROPERTIES_FILE");
        }
        if (externalFile != null && !externalFile.isEmpty()) {
            try (InputStream is = new FileInputStream(externalFile)) {
                config.load(is);
            } catch (FileNotFoundException e) {
                LOG.debug("External properties file '{}' not found, continuing", externalFile);
            } catch (IOException e) {
                LOG.debug("Failed to load external properties file '{}'", externalFile, e);
            }
        }
        // Environment variables (OSHI_*) override external file and classpath defaults
        System.getenv().forEach((k, v) -> {
            if (k.startsWith("OSHI_") && !"OSHI_PROPERTIES_FILE".equals(k)) {
                config.setProperty(envKeyToProperty(k), v);
            }
        });
        // System properties (-Doshi.*) override everything else
        System.getProperties().forEach((k, v) -> {
            String key = k.toString();
            if (key.startsWith("oshi.") && !"oshi.properties.file".equals(key)) {
                config.setProperty(key, v.toString());
            }
        });
    }

    /**
     * Converts an environment variable name to a property key. For example, {@code OSHI_OS_LINUX_PRIVILEGED_PREFIX}
     * becomes {@code oshi.os.linux.privileged.prefix}.
     *
     * @param envKey the environment variable name (e.g., {@code OSHI_UTIL_MEMOIZER_EXPIRATION})
     * @return the corresponding property key
     */
    // package-private for testing
    static String envKeyToProperty(String envKey) {
        return envKey.toLowerCase(Locale.ROOT).replace('_', '.');
    }

    /**
     * Memoizer default expiration in milliseconds. Cached return values will be refreshed after this interval. Must be
     * positive (a negative value will never refresh). Should be less than 1 second. Default is 300 milliseconds.
     */
    public static final String OSHI_UTIL_MEMOIZER_EXPIRATION = "oshi.util.memoizer.expiration";
    /**
     * The WMI query timeout in milliseconds. Default is -1 (no timeout).
     */
    public static final String OSHI_UTIL_WMI_TIMEOUT = "oshi.util.wmi.timeout";
    /**
     * The {@code /proc} filesystem location. Some containers enable alternate locations to provide container-level
     * output in preference to system-level output. Default is {@code /proc}.
     */
    public static final String OSHI_UTIL_PROC_PATH = "oshi.util.proc.path";
    /**
     * The {@code /sys} filesystem location. Some containers enable alternate locations to provide container-level
     * output in preference to system-level output. Default is {@code /sys}.
     */
    public static final String OSHI_UTIL_SYS_PATH = "oshi.util.sys.path";
    /**
     * The {@code /dev} filesystem location. Some containers enable alternate locations to provide container-level
     * output in preference to system-level output. Default is {@code /dev}.
     */
    public static final String OSHI_UTIL_DEV_PATH = "oshi.util.dev.path";

    /**
     * A comma-separated list of filesystem types to treat as pseudo-filesystems and exclude from file store listings.
     * See {@code oshi.properties} for the full default list.
     */
    public static final String OSHI_PSEUDO_FILESYSTEM_TYPES = "oshi.pseudo.filesystem.types";
    /**
     * A comma-separated list of filesystem types that are network-based and should be excluded from local-only file
     * store listings. Default includes {@code afs}, {@code cifs}, {@code smbfs}, {@code nfs}, {@code nfs4}, and others.
     */
    public static final String OSHI_NETWORK_FILESYSTEM_TYPES = "oshi.network.filesystem.types";

    /**
     * Whether to use udev on Linux for loading hardware information such as USB devices, power sources, and disk
     * information. Some details can be loaded via sysfs as a fallback, but others require udev. Default is
     * {@code true}.
     */
    public static final String OSHI_OS_LINUX_ALLOWUDEV = "oshi.os.linux.allowudev";
    /**
     * Whether to use systemd on Linux for loading session information when utmp is unavailable or deprecated. Set to
     * {@code false} to fall back to file-based session parsing or the {@code who} command. Default is {@code true}.
     */
    public static final String OSHI_OS_LINUX_ALLOWSYSTEMD = "oshi.os.linux.allowsystemd";
    /**
     * Whether to log warnings when failing to read process information from the {@code /proc} pseudo-filesystem on
     * Linux. When running without elevated permissions, frequent errors reading process environment files are expected.
     * Default is {@code false}.
     */
    public static final String OSHI_OS_LINUX_PROCFS_LOGWARNING = "oshi.os.linux.procfs.logwarning";
    /**
     * Whether to probe NFS servers for reachability before querying filesystem statistics on Linux. When enabled, a
     * short parallel TCP probe (port 2049, 2-second timeout) is performed for {@code nfs}/{@code nfs4} mounts whose
     * options expose an {@code addr=} or {@code mountaddr=} server address; if that server is unreachable the
     * {@code statvfs} call is skipped for that mount, preventing indefinite hangs on stale NFS mounts. Mounts without a
     * parseable address, and all non-NFS filesystems, always call {@code statvfs}. Default is {@code true}.
     */
    public static final String OSHI_OS_LINUX_FILESYSTEM_CHECKNFS = "oshi.os.linux.filesystem.checknfs";

    /**
     * Whether to log warnings when failing to read process information via sysctl on macOS. When running without
     * elevated permissions, frequent errors reading process environment are expected. Default is {@code false}.
     */
    public static final String OSHI_OS_MAC_SYSCTL_LOGWARNING = "oshi.os.mac.sysctl.logwarning";

    /**
     * Comma-separated list of macOS SMC keys to read for Apple Silicon GPU temperature; the highest plausible reading
     * among them is reported. Empty by default, meaning the keys are discovered from the SMC at runtime so that chips
     * with differently named sensors are handled without a code change. Set this only to override that discovery.
     */
    public static final String OSHI_OS_MAC_SENSORS_GPUTEMPERATURE_KEYS = "oshi.os.mac.sensors.gputemperature.keys";

    /**
     * Comma-separated list of macOS SMC keys to read for fan speeds, one per fan. Empty by default, meaning the keys
     * are discovered from the SMC at runtime and cross-checked against the fan count {@code FNum} reports. Set this
     * only to override that discovery.
     */
    public static final String OSHI_OS_MAC_SENSORS_FANSPEED_KEYS = "oshi.os.mac.sensors.fanspeed.keys";

    /**
     * Comma-separated list of macOS SMC keys to read for CPU voltage, tried in order until one returns a plausible
     * value. Empty by default, meaning the Apple Silicon key is tried and then the Intel one. Unlike GPU temperature
     * these keys are not discovered at runtime, because the {@code V} prefix covers supply rails as well as the CPU and
     * nothing in the naming distinguishes them, so this property is the way to name the key on hardware where neither
     * default works.
     */
    public static final String OSHI_OS_MAC_SENSORS_CPUVOLTAGE_KEYS = "oshi.os.mac.sensors.cpuvoltage.keys";

    /**
     * Whether to report a live per-core CPU frequency on Apple Silicon, derived from the performance state residency
     * IOReport publishes, rather than each cluster's nominal maximum. Enabling this holds an IOReport subscription for
     * the lifetime of the process. Default is {@code false}.
     */
    public static final String OSHI_OS_MAC_CPU_FREQUENCY_IOREPORT = "oshi.os.mac.cpu.frequency.ioreport";

    /**
     * The name of the Windows System event log containing bootup event IDs 12 and 6005, used for a one-time calculation
     * of system boot time that is consistent across process runs regardless of sleep/hibernate cycles. If set to the
     * empty string, boot time is calculated by subtracting uptime from the current time (faster but less accurate).
     * Default is {@code System}.
     */
    public static final String OSHI_OS_WINDOWS_EVENTLOG = "oshi.os.windows.eventlog";
    /**
     * Whether to update the process state on Windows to {@code SUSPENDED} if all its threads are suspended. This
     * requires querying thread states and can significantly impact performance when querying process lists. Default is
     * {@code false}.
     */
    public static final String OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED = "oshi.os.windows.procstate.suspended";
    /**
     * Whether to perform WMI queries for command lines in a batch for all running processes. Individual WMI queries
     * take about 50ms each while querying the entire process list takes about 200ms. Enable this if you regularly query
     * command lines for more than a few processes. Default is {@code false}.
     */
    public static final String OSHI_OS_WINDOWS_COMMANDLINE_BATCH = "oshi.os.windows.commandline.batch";
    /**
     * Whether to attempt to fetch Windows performance counter data for processes and threads from
     * {@code HKEY_PERFORMANCE_DATA} in the registry. This is faster than the PDH API but more subject to registry
     * corruption and counter deletion when changing language settings. Set to {@code false} to skip the registry check
     * and use the API-recommended (but slower) performance counter API. Default is {@code true}.
     */
    public static final String OSHI_OS_WINDOWS_HKEYPERFDATA = "oshi.os.windows.hkeyperfdata";
    /**
     * Whether to use the Legacy Processor performance counters for System CPU ticks instead of Processor Information
     * (since Windows 7). Legacy counters are not processor-group aware and may give incorrect results on systems with
     * more than 64 logical processors. Default is {@code false}.
     */
    public static final String OSHI_OS_WINDOWS_LEGACY_SYSTEM_COUNTERS = "oshi.os.windows.legacy.system.counters";
    /**
     * Whether to start a daemon thread to provide load averages on Windows. While Windows does not natively provide
     * this metric, the Processor Queue Length performance counter combined with recent processor usage provides a
     * similar metric. Default is {@code false}.
     *
     * @see CentralProcessor#getSystemLoadAverage(int)
     */
    public static final String OSHI_OS_WINDOWS_LOADAVERAGE = "oshi.os.windows.loadaverage";
    /**
     * Whether to use "Processor Utility" for System and per-processor CPU Load ticks (on Windows 8 and higher) to match
     * CPU usage with the Windows Task Manager.
     * <p>
     * By default, OSHI uses "Processor Time" which measures active and idle times, matching Unix-based systems and
     * Windows 7 Task Manager. Setting this to {@code true} switches to "Processor Utility" which measures work
     * completed relative to nominal frequency. Because of features like Intel Turbo Boost and AMD Precision Boost, this
     * value can exceed 100% (though Task Manager caps it). OSHI does not cap the value.
     * <p>
     * For this calculation to produce meaningful data, the ticks must come from the same CentralProcessor instance and
     * the first polling interval must be less than 7 minutes. Default is {@code false}.
     *
     * @see CentralProcessor#getSystemCpuLoadTicks()
     */
    public static final String OSHI_OS_WINDOWS_CPU_UTILITY = "oshi.os.windows.cpu.utility";

    /**
     * Whether PerfDisk performance counters are disabled. If counters are intentionally disabled (e.g., for gaming
     * performance) or the application does not need disk read/write/queue metrics, set to {@code true} to skip querying
     * and suppress log warnings. Default is unset (OSHI auto-detects from the registry).
     */
    public static final String OSHI_OS_WINDOWS_PERFDISK_DISABLED = "oshi.os.windows.perfdisk.disabled";
    /**
     * Whether PerfOS performance counters are disabled. These counters are used for CPU ticks, swap file usage, page
     * swaps, context switches, and interrupts. Set to {@code true} to skip querying and suppress log warnings. Default
     * is unset (OSHI auto-detects from the registry).
     */
    public static final String OSHI_OS_WINDOWS_PERFOS_DISABLED = "oshi.os.windows.perfos.disabled";
    /**
     * Whether PerfProc performance counters are disabled. These counters are used for process and thread priority,
     * time, I/O, and memory usage. Set to {@code true} to skip querying and suppress log warnings. Default is unset
     * (OSHI auto-detects from the registry).
     *
     * @see #OSHI_OS_WINDOWS_HKEYPERFDATA
     */
    public static final String OSHI_OS_WINDOWS_PERFPROC_DISABLED = "oshi.os.windows.perfproc.disabled";

    /**
     * Whether to assume any performance counter failure means all counters will fail and revert to WMI backup. Default
     * is {@code false}.
     */
    public static final String OSHI_OS_WINDOWS_PERF_DISABLE_ALL_ON_FAILURE = "oshi.os.windows.perf.disable.all.on.failure";

    /**
     * Whether queries to the Open Hardware Monitor WMI namespace ({@code ROOT\OpenHardwareMonitor}) are disabled. OSHI
     * queries that namespace on every sensor read, as the application may be started or stopped while OSHI is running.
     * Set this to {@code true} to skip those queries entirely on a system where Open Hardware Monitor is known not to
     * be used. Default is {@code false}.
     *
     * @see #OSHI_OS_WINDOWS_LHM_DISABLED
     */
    public static final String OSHI_OS_WINDOWS_OHM_DISABLED = "oshi.os.windows.ohm.disabled";
    /**
     * Whether queries to the Libre Hardware Monitor WMI namespace ({@code ROOT\LibreHardwareMonitor}) are disabled.
     * OSHI queries that namespace for GPU metrics, and on any sensor read which Open Hardware Monitor did not satisfy,
     * as the application may be started or stopped while OSHI is running. Set this to {@code true} to skip those
     * queries entirely on a system where Libre Hardware Monitor is known not to be used. Default is {@code false}.
     *
     * @see #OSHI_OS_WINDOWS_OHM_DISABLED
     */
    public static final String OSHI_OS_WINDOWS_LHM_DISABLED = "oshi.os.windows.lhm.disabled";

    /**
     * Whether to use the Posix-standard {@code who} command for session information instead of native code. The native
     * implementation ({@code getutxent}) is not thread safe; while OSHI synchronizes its own access, other OS code may
     * access the same data structures. The command-line variant may use reentrant code on some platforms. Default is
     * {@code false}.
     */
    public static final String OSHI_OS_UNIX_WHOCOMMAND = "oshi.os.unix.whocommand";
    /**
     * Whether to allow use of the kstat2 API on Solaris 11.4+. The new API offers additional features but may have a
     * file descriptor leak when parallel GC is in use. Set to {@code false} to always use the original kstat API.
     * Default is {@code true}.
     */
    public static final String OSHI_OS_SOLARIS_ALLOWKSTAT2 = "oshi.os.solaris.allowkstat2";

    /**
     * The command prefix to prepend for privileged command execution on Linux (e.g., {@code "sudo -n"} for
     * non-interactive sudo). This supports the Principle of Least Privilege by allowing fine-grained access to specific
     * commands without running the entire application as root. The prefix is not applied when already running as root.
     * Default is the empty string (no privilege escalation).
     *
     * @see #OSHI_OS_LINUX_PRIVILEGED_ALLOWLIST
     * @see #OSHI_OS_LINUX_PRIVILEGED_FILE_ALLOWLIST
     */
    public static final String OSHI_OS_LINUX_PRIVILEGED_PREFIX = "oshi.os.linux.privileged.prefix";
    /**
     * A comma-separated list of commands eligible for privilege escalation on Linux. Use full paths matching your
     * sudoers configuration (e.g., {@code /usr/sbin/dmidecode}) or bare names to match regardless of path. The
     * allowlist should mirror the {@code NOPASSWD} entries in your sudoers file. Default is the empty string (no
     * commands allowed).
     *
     * @see #OSHI_OS_LINUX_PRIVILEGED_PREFIX
     */
    public static final String OSHI_OS_LINUX_PRIVILEGED_ALLOWLIST = "oshi.os.linux.privileged.allowlist";
    /**
     * A comma-separated list of file paths eligible for privileged read via {@code sudo cat} fallback on Linux when
     * normal file read fails due to permissions. Supports Java glob patterns ({@code *}, {@code ?}, {@code [abc]}).
     * <p>
     * <b>Security warning:</b> Take care when adding paths. Allowing privileged reads of sensitive files such as
     * process environ files can expose credentials to unprivileged users. Default is the empty string (no files
     * allowed).
     *
     * @see #OSHI_OS_LINUX_PRIVILEGED_PREFIX
     */
    public static final String OSHI_OS_LINUX_PRIVILEGED_FILE_ALLOWLIST = "oshi.os.linux.privileged.file.allowlist";

    private GlobalConfig() {
    }

    /**
     * Get the property associated with the given key.
     *
     * @param key The property key
     * @return The property value if it exists, or {@code null} otherwise. Unlike the other overloads, this one
     *         distinguishes an absent property from one explicitly set to an empty value.
     */
    public static @Nullable String get(String key) {
        return CONFIG.getProperty(key);
    }

    /**
     * Get the {@code String} property associated with the given key.
     *
     * @param key The property key
     * @param def The default value
     * @return The property value or the given default if not found
     */
    public static String get(String key, String def) {
        return CONFIG.getProperty(key, def);
    }

    /**
     * Get the {@code int} property associated with the given key.
     *
     * @param key The property key
     * @param def The default value
     * @return The property value or the given default if not found
     */
    public static int get(String key, int def) {
        String value = CONFIG.getProperty(key);
        return value == null ? def : ParseUtil.parseIntOrDefault(value, def);
    }

    /**
     * Get the {@code double} property associated with the given key.
     *
     * @param key The property key
     * @param def The default value
     * @return The property value or the given default if not found
     */
    public static double get(String key, double def) {
        String value = CONFIG.getProperty(key);
        return value == null ? def : ParseUtil.parseDoubleOrDefault(value, def);
    }

    /**
     * Get the {@code boolean} property associated with the given key.
     *
     * @param key The property key
     * @param def The default value
     * @return The property value or the given default if not found
     */
    public static boolean get(String key, boolean def) {
        String value = CONFIG.getProperty(key);
        return value == null ? def : Boolean.parseBoolean(value);
    }

    /**
     * Set the given property, overwriting any existing value. If the given value is {@code null}, the property is
     * removed.
     *
     * @param key The property key
     * @param val The new value
     */
    public static void set(String key, @Nullable Object val) {
        if (val == null) {
            CONFIG.remove(key);
        } else {
            CONFIG.setProperty(key, val.toString());
        }
    }

    /**
     * Reset the given property to its default value.
     *
     * @param key The property key
     */
    public static void remove(String key) {
        CONFIG.remove(key);
    }

    /**
     * Clear the configuration.
     */
    public static void clear() {
        CONFIG.clear();
    }

    /**
     * Load the given {@link java.util.Properties} into the global configuration.
     *
     * @param properties The new properties
     */
    public static void load(Properties properties) {
        CONFIG.putAll(properties);
    }

    /**
     * Indicates that a configuration value is invalid.
     */
    public static class PropertyException extends RuntimeException {

        private static final long serialVersionUID = -7482581936621748005L;

        /**
         * Creates a PropertyException for an invalid property value.
         *
         * @param property The property name
         */
        public PropertyException(String property) {
            super("Invalid property: \"" + property + "\" = " + GlobalConfig.get(property));
        }

        /**
         * Creates a PropertyException with a custom message.
         *
         * @param property The property name
         * @param message  An exception message
         */
        public PropertyException(String property, String message) {
            super("Invalid property \"" + property + "\": " + message);
        }
    }
}
