/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util;

import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oshi.annotation.SuppressForbidden;
import oshi.annotation.concurrent.ThreadSafe;
import oshi.util.tuples.Pair;
import oshi.util.tuples.Triplet;

/**
 * String parsing utility.
 */
@ThreadSafe
@SuppressForbidden(reason = "Require parse methods to parse in utility class")
public final class ParseUtil {

    private static final Logger LOG = LoggerFactory.getLogger(ParseUtil.class);

    private static final Charset CP1252 = Charset.forName("Windows-1252");

    // The exception is passed as the trailing argument with no matching placeholder, so SLF4J attaches it as the
    // event's cause rather than substituting it. A second "{}" here would be left in the output literally.
    private static final String DEFAULT_LOG_MSG = "{} didn't parse. Returning default.";

    /*
     * Used for matching
     */
    // The '.' before the decimals is deliberately unescaped, and must stay that way. Matching any separator pulls a
    // malformed number into the value group whole ("2,40" from "2,40GHz"), where parseHertz rejects it and returns
    // the documented -1. Escaping it instead lets the match re-anchor on a fragment, so "2 40GHz" would be reported
    // as 40 GHz rather than as unparseable. See testParseHertzNonDecimalSeparator.
    private static final Pattern HERTZ_PATTERN = Pattern.compile("(\\d+(.\\d+)?) ?([kKMGT]?Hz).*");
    private static final Pattern BYTES_PATTERN = Pattern.compile("(\\d+) ?([kKMGT]?B?).*");
    private static final Pattern UNITS_PATTERN = Pattern.compile("(\\d+(.\\d+)?)[\\s]?([kKMGT])?");

    /*
     * Used to check validity of a hexadecimal string
     */
    private static final Pattern VALID_HEX = Pattern.compile("[0-9a-fA-F]+");

    /*
     * Pattern for [dd-[hh:[mm:[ss[.sss]]]]]
     */
    private static final Pattern DHMS = Pattern.compile("(?:(\\d+)-)?(?:(\\d+):)??(?:(\\d+):)?(\\d+)(?:\\.(\\d+))?");

    /*
     * Pattern for a UUID
     */
    private static final Pattern UUID_PATTERN = Pattern
            .compile(".*([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}).*");

    /*
     * Pattern for Windows DeviceID vendor and product ID and serial
     */
    private static final Pattern VENDOR_PRODUCT_ID_SERIAL = Pattern
            .compile(".*(?:VID|VEN)_(\\p{XDigit}{4})&(?:PID|DEV)_(\\p{XDigit}{4})(.*)\\\\(.*)");

    /*
     * Pattern for Windows DeviceID vendor and product ID without requiring a trailing instance component. Matches both
     * full PNPDeviceID strings (PCI\VEN_8086&DEV_56A0&...\instance) and bare MatchingDeviceId values
     * (pci\ven_8086&dev_56a0&...) that lack the trailing backslash. Case-insensitive to handle both the uppercase
     * PNPDeviceID format and the lowercase MatchingDeviceId registry values.
     */
    private static final Pattern VENDOR_PRODUCT_ID = Pattern
            .compile("(?i).*(?:VID|VEN)_(\\p{XDigit}{4})&(?:PID|DEV)_(\\p{XDigit}{4}).*");

    /*
     * Pattern for Linux lspci machine readable
     */
    private static final Pattern LSPCI_MACHINE_READABLE = Pattern.compile("(.+)\\s\\[(.*?)\\]");

    /*
     * Pattern for Linux lspci memory
     */
    private static final Pattern LSPCI_MEMORY_SIZE = Pattern.compile(".+\\s\\[size=(\\d+)([kKMGT])\\]");

    /*
     * Hertz related variables.
     */
    private static final String HZ = "Hz";
    private static final String KHZ = "kHz";
    private static final String MHZ = "MHz";
    private static final String GHZ = "GHz";
    private static final String THZ = "THz";
    private static final String PHZ = "PHz";

    // CHECKSTYLE:OFF ConstantName - lowercase names on these are public API and cannot be renamed
    private static final Map<String, Long> multipliers;

    // Shared "no address" return for the address parsers. A zero-length array has no state to mutate, so one
    // instance is safe to hand out repeatedly.
    private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];

    // PDH timestamps are 1601 epoch, local time
    // Constants to convert to UTC millis
    private static final long EPOCH_DIFF = 11_644_473_600_000L;
    private static final int TZ_OFFSET = TimeZone.getDefault().getOffset(System.currentTimeMillis());

    /** Constant <code>whitespacesColonWhitespace</code> */
    public static final Pattern whitespacesColonWhitespace = Pattern.compile("\\s+:\\s");

    /** Constant <code>whitespaces</code> */
    public static final Pattern whitespaces = Pattern.compile("\\s+");

    /** Constant <code>notDigits</code> */
    public static final Pattern notDigits = Pattern.compile("\\D+");

    /** Constant <code>startWithNotDigits</code> */
    public static final Pattern startWithNotDigits = Pattern.compile("^\\D*");
    // CHECKSTYLE:ON ConstantName

    static {
        multipliers = new HashMap<>();
        multipliers.put(HZ, 1L);
        multipliers.put(KHZ, 1_000L);
        multipliers.put(MHZ, 1_000_000L);
        multipliers.put(GHZ, 1_000_000_000L);
        multipliers.put(THZ, 1_000_000_000_000L);
        multipliers.put(PHZ, 1_000_000_000_000_000L);
    }

    // Fast decimal exponentiation: pow(10,y) --> POWERS_OF_10[y]
    private static final long[] POWERS_OF_TEN = { 1L, 10L, 100L, 1_000L, 10_000L, 100_000L, 1_000_000L, 10_000_000L,
            100_000_000L, 1_000_000_000L, 10_000_000_000L, 100_000_000_000L, 1_000_000_000_000L, 10_000_000_000_000L,
            100_000_000_000_000L, 1_000_000_000_000_000L, 10_000_000_000_000_000L, 100_000_000_000_000_000L,
            1_000_000_000_000_000_000L };

    // Format returned by WMI for DateTime
    private static final DateTimeFormatter CIM_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss.SSSSSSZZZZZ",
            Locale.US);

    private ParseUtil() {
    }

    /**
     * Decodes REG_BINARY to String. Supports UTF-16LE and Windows-1252 C-strings, otherwise returns a hex.
     *
     * @param bytes the byte array to decode
     * @return the decoded string, or {@code null} if the array is null or empty
     */
    public static @Nullable String decodeBinaryToString(byte @Nullable [] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        int len = bytes.length;

        // Check for UTF-16LE null terminator (00 00)
        if (len >= 2 && bytes[len - 1] == 0x00 && bytes[len - 2] == 0x00) {
            return new String(bytes, StandardCharsets.UTF_16LE).trim();
        }

        // Check for Windows-1252 (single null terminator)
        if (len >= 1 && bytes[len - 1] == 0x00) {
            return new String(bytes, CP1252).trim();
        }

        // fall back to Hex
        return IntStream.range(0, bytes.length).mapToObj(i -> String.format(Locale.ROOT, "%02X", bytes[i]))
                .collect(Collectors.joining(" "));
    }

    /**
     * Parse speed from a string, eg. "2.00 MT/s" is 2000000L.
     *
     * @param speed Transfer speed.
     * @return {@link java.lang.Long} MT/s value. If not parseable, delegates to {#link {@link #parseHertz(String)}.
     */
    public static long parseSpeed(String speed) {
        if (speed.contains("T/s")) {
            return parseHertz(speed.replace("T/s", "Hz"));
        }
        return parseHertz(speed);
    }

    /**
     * Parse hertz from a string, eg. "2.00MHz" is 2000000L.
     *
     * @param hertz Hertz size.
     * @return {@link java.lang.Long} Hertz value or -1 if not parseable.
     */
    public static long parseHertz(String hertz) {
        Matcher matcher = HERTZ_PATTERN.matcher(hertz.trim());
        if (matcher.find()) {
            double value = parseDoubleOrDefault(matcher.group(1), -1d);
            long multiplier = multipliers.getOrDefault(matcher.group(3), -1L);
            if (value >= 0d && multiplier > 0L) {
                return (long) (value * multiplier);
            }
        }
        return -1L;
    }

    /**
     * Parse the last element of a space-delimited string to a value
     *
     * @param s The string to parse
     * @param i Default integer if not parsable
     * @return value or the given default if not parsable
     */
    public static int parseLastInt(String s, int i) {
        try {
            String ls = parseLastString(s);
            if (ls.toLowerCase(Locale.ROOT).startsWith("0x")) {
                return Integer.decode(ls);
            } else {
                return Integer.parseInt(ls);
            }
        } catch (NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return i;
        }
    }

    /**
     * Parse the last element of a space-delimited string to a value
     *
     * @param s  The string to parse
     * @param li Default long integer if not parsable
     * @return value or the given default if not parsable
     */
    public static long parseLastLong(String s, long li) {
        try {
            String ls = parseLastString(s);
            if (ls.toLowerCase(Locale.ROOT).startsWith("0x")) {
                return Long.decode(ls);
            } else {
                return Long.parseLong(ls);
            }
        } catch (NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return li;
        }
    }

    /**
     * Parse the last element of a space-delimited string to a value
     *
     * @param s The string to parse
     * @param d Default double if not parsable
     * @return value or the given default if not parsable
     */
    public static double parseLastDouble(String s, double d) {
        try {
            return Double.parseDouble(parseLastString(s));
        } catch (NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return d;
        }
    }

    /**
     * Parse the last element of a space-delimited string to a string
     *
     * @param s The string to parse
     * @return last space-delimited element
     */
    public static String parseLastString(String s) {
        String[] ss = whitespaces.split(s.trim(), -1);
        // guaranteed at least one element
        return ss[ss.length - 1];
    }

    /**
     * Parse a byte array into a string of hexadecimal digits including all array bytes as digits
     *
     * @param bytes The byte array to represent
     * @return A string of hex characters corresponding to the bytes. The string is upper case.
     */
    public static String byteArrayToHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(Character.forDigit((b & 0xf0) >>> 4, 16));
            sb.append(Character.forDigit(b & 0x0f, 16));
        }
        return sb.toString().toUpperCase(Locale.ROOT);
    }

    /**
     * Parse a string of hexadecimal digits into a byte array
     *
     * @param digits The string to be parsed
     * @return a byte array with each pair of characters converted to a byte, or empty array if the string is not valid
     *         hex
     */
    public static byte[] hexStringToByteArray(String digits) {
        int len = digits.length();
        // Check if string is valid hex
        if (!VALID_HEX.matcher(digits).matches() || (len & 0x1) != 0) {
            LOG.warn("Invalid hexadecimal string: {}", digits);
            return new byte[0];
        }
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) (Character.digit(digits.charAt(i), 16) << 4
                    | Character.digit(digits.charAt(i + 1), 16));
        }
        return data;
    }

    /**
     * Parse a human readable ASCII string into a byte array, truncating or padding with zeros (if necessary) so the
     * array has the specified length.
     *
     * @param text   The string to be parsed
     * @param length Length of the returned array.
     * @return A byte array of specified length, with each of the first length characters converted to a byte. If length
     *         is longer than the provided string length, will be filled with zeroes.
     */
    public static byte[] asciiStringToByteArray(String text, int length) {
        return Arrays.copyOf(text.getBytes(StandardCharsets.US_ASCII), length);
    }

    /**
     * Convert a long value to a byte array using Big Endian, truncating or padding with zeros (if necessary) so the
     * array has the specified length.
     *
     * @param value     The value to be converted
     * @param valueSize Number of bytes representing the value
     * @param length    Number of bytes to return
     * @return A byte array of specified length representing the long in the first valueSize bytes
     */
    public static byte[] longToByteArray(long value, int valueSize, int length) {
        long val = value;
        // Convert the long to 8-byte BE representation
        byte[] b = new byte[8];
        for (int i = 7; i >= 0 && val != 0L; i--) {
            b[i] = (byte) val;
            val >>>= 8;
        }
        // Then copy the rightmost valueSize bytes
        // e.g., for an integer we want rightmost 4 bytes
        return Arrays.copyOfRange(b, 8 - valueSize, 8 + length - valueSize);
    }

    /**
     * Convert a string to an integer representation.
     *
     * @param str  A human readable ASCII string
     * @param size Number of characters to convert to the long. May not exceed 8.
     * @return An integer representing the string where each character is treated as a byte
     */
    public static long strToLong(String str, int size) {
        return byteArrayToLong(str.getBytes(StandardCharsets.US_ASCII), size);
    }

    /**
     * Convert a byte array to its (long) integer representation assuming big endian ordering.
     *
     * @param bytes An array of bytes no smaller than the size to be converted
     * @param size  Number of bytes to convert to the long. May not exceed 8.
     * @return A long integer representing the byte array
     */
    public static long byteArrayToLong(byte[] bytes, int size) {
        return byteArrayToLong(bytes, size, true);
    }

    /**
     * Convert a byte array to its (long) integer representation in the specified endianness.
     *
     * @param bytes     An array of bytes no smaller than the size to be converted
     * @param size      Number of bytes to convert to the long. May not exceed 8.
     * @param bigEndian True to parse big-endian, false to parse little-endian
     * @return An long integer representing the byte array
     */
    public static long byteArrayToLong(byte[] bytes, int size, boolean bigEndian) {
        if (size > 8) {
            throw new IllegalArgumentException("Can't convert more than 8 bytes.");
        }
        if (size > bytes.length) {
            throw new IllegalArgumentException("Size can't be larger than array length.");
        }
        long total = 0L;
        for (int i = 0; i < size; i++) {
            if (bigEndian) {
                total = (total << 8) | (bytes[i] & 0xff);
            } else {
                total = (total << 8) | (bytes[size - i - 1] & 0xff);
            }
        }
        return total;
    }

    /**
     * Convert a byte array to its floating point representation.
     *
     * @param bytes  An array of bytes no smaller than the size to be converted
     * @param size   Number of bytes to convert to the float. May not exceed 8.
     * @param fpBits Number of bits representing the decimal
     * @return A float; the integer portion representing the byte array as an integer shifted by the bits specified in
     *         fpBits; with the remaining bits used as a decimal
     */
    public static float byteArrayToFloat(byte[] bytes, int size, int fpBits) {
        return byteArrayToLong(bytes, size) / (float) (1 << fpBits);
    }

    /**
     * Convert an unsigned integer to a long value. The method assumes that all bits in the specified integer value are
     * 'data' bits, including the most-significant bit which Java normally considers a sign bit. The method must be used
     * only when it is certain that the integer value represents an unsigned integer, for example when the integer is
     * returned by JNA library in a structure which holds unsigned integers.
     *
     * @param unsignedValue The unsigned integer value to convert.
     * @return The unsigned integer value widened to a long.
     */
    public static long unsignedIntToLong(int unsignedValue) {
        // use standard Java widening conversion to long which does
        // sign-extension,
        // then drop any copies of the sign bit, to prevent the value being
        // considered a negative one by Java if it is set
        long longValue = unsignedValue;
        return longValue & 0xffff_ffffL;
    }

    /**
     * Convert an unsigned long to a signed long value by stripping the sign bit. This method "rolls over" long values
     * greater than the max value but ensures the result is never negative.
     *
     * @param unsignedValue The unsigned long value to convert.
     * @return The signed long value.
     */
    public static long unsignedLongToSignedLong(long unsignedValue) {
        return unsignedValue & 0x7fff_ffff_ffff_ffffL;
    }

    /**
     * Parses a string of hex digits to a string where each pair of hex digits represents an ASCII character
     *
     * @param hexString A sequence of hex digits
     * @return The corresponding string if valid hex; otherwise the original hexString
     */
    public static String hexStringToString(String hexString) {
        // Odd length strings won't parse, return
        if (hexString.length() % 2 > 0) {
            return hexString;
        }
        int charAsInt;
        StringBuilder sb = new StringBuilder();
        try {
            for (int pos = 0; pos < hexString.length(); pos += 2) {
                charAsInt = Integer.parseInt(hexString.substring(pos, pos + 2), 16);
                if (charAsInt < 32 || charAsInt > 127) {
                    return hexString;
                }
                sb.append((char) charAsInt);
            }
        } catch (NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, hexString, e);
            // Hex failed to parse, just return the existing string
            return hexString;
        }
        return sb.toString();
    }

    /**
     * Attempts to parse a string to an int. If it fails, returns the default
     *
     * @param s          The string to parse
     * @param defaultInt The value to return if parsing fails
     * @return The parsed int, or the default if parsing failed
     */
    public static int parseIntOrDefault(@Nullable String s, int defaultInt) {
        try {
            return Integer.parseInt(s);
        } catch (NullPointerException | NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return defaultInt;
        }
    }

    /**
     * Attempts to parse a string to a long. If it fails, returns the default
     *
     * @param s           The string to parse
     * @param defaultLong The value to return if parsing fails
     * @return The parsed long, or the default if parsing failed
     */
    public static long parseLongOrDefault(@Nullable String s, long defaultLong) {
        try {
            return Long.parseLong(s);
        } catch (NullPointerException | NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return defaultLong;
        }
    }

    /**
     * Attempts to parse a string to an "unsigned" long. If it fails, returns the default
     *
     * @param s           The string to parse
     * @param defaultLong The value to return if parsing fails
     * @return The parsed long containing the same 64 bits that an unsigned long would contain (which may produce a
     *         negative value)
     */
    public static long parseUnsignedLongOrDefault(@Nullable String s, long defaultLong) {
        try {
            return new BigInteger(s).longValue();
        } catch (NullPointerException | NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return defaultLong;
        }
    }

    /**
     * Attempts to decode a string to an int using {@link Integer#decode(String)}. Handles decimal, hex (0x/0X/#), and
     * octal (0) prefixes. If it fails, returns the default.
     *
     * @param s          The string to decode
     * @param defaultInt The value to return if decoding fails
     * @return The decoded int, or the default if decoding failed
     */
    public static int decodeIntOrDefault(@Nullable String s, int defaultInt) {
        try {
            return Integer.decode(s);
        } catch (NullPointerException | NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return defaultInt;
        }
    }

    /**
     * Attempts to decode a string to a long using {@link Long#decode(String)}. Handles decimal, hex (0x/0X/#), and
     * octal (0) prefixes. If it fails, returns the default.
     *
     * @param s           The string to decode
     * @param defaultLong The value to return if decoding fails
     * @return The decoded long, or the default if decoding failed
     */
    public static long decodeLongOrDefault(@Nullable String s, long defaultLong) {
        try {
            return Long.decode(s);
        } catch (NullPointerException | NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return defaultLong;
        }
    }

    /**
     * Attempts to parse a string to a double. If it fails, returns the default
     *
     * @param s             The string to parse
     * @param defaultDouble The value to return if parsing fails
     * @return The parsed double, or the default if parsing failed
     */
    public static double parseDoubleOrDefault(@Nullable String s, double defaultDouble) {
        try {
            return Double.parseDouble(s);
        } catch (NullPointerException | NumberFormatException e) {
            LOG.trace(DEFAULT_LOG_MSG, s, e);
            return defaultDouble;
        }
    }

    /**
     * Attempts to parse a string of the form [DD-[hh:]]mm:ss[.ddd] to a number of milliseconds. If it fails, returns
     * the default.
     *
     * @param s           The string to parse
     * @param defaultLong The value to return if parsing fails
     * @return The parsed number of seconds, or the default if parsing fails
     */
    public static long parseDHMSOrDefault(@Nullable String s, long defaultLong) {
        if (s == null) {
            return defaultLong;
        }
        Matcher m = DHMS.matcher(s);
        if (m.matches()) {
            long milliseconds = 0L;
            if (m.group(1) != null) {
                milliseconds += parseLongOrDefault(m.group(1), 0L) * 86_400_000L;
            }
            if (m.group(2) != null) {
                milliseconds += parseLongOrDefault(m.group(2), 0L) * 3_600_000L;
            }
            if (m.group(3) != null) {
                milliseconds += parseLongOrDefault(m.group(3), 0L) * 60_000L;
            }
            milliseconds += parseLongOrDefault(m.group(4), 0L) * 1000L;
            if (m.group(5) != null) {
                milliseconds += (long) (1000 * parseDoubleOrDefault("0." + m.group(5), 0d));
            }
            return milliseconds;
        }
        return defaultLong;
    }

    /**
     * Attempts to parse a UUID. If it fails, returns the default.
     *
     * @param s          The string to parse
     * @param defaultStr The value to return if parsing fails
     * @return The parsed UUID, or the default if parsing fails
     */
    public static String parseUuidOrDefault(@Nullable String s, String defaultStr) {
        if (s == null) {
            return defaultStr;
        }
        Matcher m = UUID_PATTERN.matcher(s.toLowerCase(Locale.ROOT));
        if (m.matches()) {
            return m.group(1);
        }
        return defaultStr;
    }

    /**
     * Parses a string key = 'value' (string)
     *
     * @param line The entire string
     * @return the value contained between single tick marks
     */
    public static String getSingleQuoteStringValue(String line) {
        return getStringBetween(line, '\'');
    }

    /**
     * Parse a string key = "value" (string)
     *
     * @param line the entire string
     * @return the value contained between double tick marks
     */
    public static String getDoubleQuoteStringValue(String line) {
        return getStringBetween(line, '"');
    }

    /**
     * Gets a value between two characters having multiple same characters between them. <b>Examples : </b>
     * <ul>
     * <li>"name = 'James Gosling's Java'" returns "James Gosling's Java"</li>
     * <li>"pci.name = 'Realtek AC'97 Audio Device'" returns "Realtek AC'97 Audio Device"</li>
     * </ul>
     *
     * @param line The "key-value" pair line.
     * @param c    The Trailing And Leading characters of the string line
     * @return : The value having the characters between them.
     */
    public static String getStringBetween(String line, char c) {
        int firstOcc = line.indexOf(c);
        int lastOcc = line.lastIndexOf(c);
        // Absent, or a single unmatched delimiter (firstOcc == lastOcc): nothing is enclosed. Returning "" avoids a
        // StringIndexOutOfBoundsException from substring(firstOcc + 1, lastOcc) when the two indexes cross.
        if (firstOcc < 0 || firstOcc == lastOcc) {
            return "";
        }
        return line.substring(firstOcc + 1, lastOcc).trim();
    }

    /**
     * Gets the portion of a string preceding the first occurrence of a delimiter, for values that pack a wanted prefix
     * ahead of a qualifier, such as macOS IOKit's {@code Port-HDMI@1/DisplayPort} or {@code disp0,t6030}.
     * <p>
     * A string that does not contain the delimiter is returned unchanged, since all of it precedes the (absent)
     * delimiter. A string that leads with the delimiter has nothing before it and yields an empty string; pair this
     * with {@link #getStringValueOrUnknown} where the caller wants that normalized to a sentinel.
     *
     * @param text      The string to split, which may be {@code null}
     * @param delimiter The delimiter to stop before
     * @return The text preceding the first {@code delimiter}; the whole string if it contains no {@code delimiter}; or
     *         an empty string if {@code text} is {@code null}, empty, or begins with {@code delimiter}
     */
    public static String getStringBefore(@Nullable String text, char delimiter) {
        if (text == null) {
            return "";
        }
        int idx = text.indexOf(delimiter);
        return idx < 0 ? text : text.substring(0, idx);
    }

    /**
     * Parses a string such as "10.12.2" or "key = 1 (0x1) (int)" to find the integer value of the first set of one or
     * more consecutive digits
     *
     * @param line The entire string
     * @return the value of first integer if any; 0 otherwise
     */
    public static int getFirstIntValue(String line) {
        return getNthIntValue(line, 1);
    }

    /**
     * Parses a string such as "10.12.2" or "key = 1 (0x1) (int)" to find the integer value of the nth set of one or
     * more consecutive digits
     *
     * @param line The entire string
     * @param n    Which set of integers to return
     * @return the value of nth integer if any; 0 otherwise
     */
    public static int getNthIntValue(String line, int n) {
        // Split the string by non-digits,
        String[] split = notDigits.split(startWithNotDigits.matcher(line).replaceFirst(""), -1);
        if (split.length >= n) {
            return parseIntOrDefault(split[n - 1], 0);
        }
        return 0;
    }

    /**
     * Removes all matching sub strings from the string. More efficient than regexp.
     *
     * @param original source String to remove from
     * @param toRemove the sub string to be removed
     * @return The string with all matching substrings removed
     */
    public static @Nullable String removeMatchingString(@Nullable final String original,
            @Nullable final String toRemove) {
        if (original == null || original.isEmpty() || toRemove == null || toRemove.isEmpty()) {
            return original;
        }

        int matchIndex = original.indexOf(toRemove, 0);
        if (matchIndex == -1) {
            return original;
        }

        StringBuilder buffer = new StringBuilder(original.length() - toRemove.length());
        int currIndex = 0;
        do {
            buffer.append(original.substring(currIndex, matchIndex));
            currIndex = matchIndex + toRemove.length();
            matchIndex = original.indexOf(toRemove, currIndex);
        } while (matchIndex != -1);

        buffer.append(original.substring(currIndex));
        return buffer.toString();
    }

    /**
     * Parses a delimited string to an array of longs. Optimized for processing predictable-length arrays such as
     * outputs of reliably formatted Linux proc or sys filesystem, minimizing new object creation. Users should perform
     * other sanity checks of data.
     *
     * As a special case, non-numeric fields (such as UUIDs in OpenVZ) at the end of the list are ignored. Values
     * greater than the max long value return the max long value.
     *
     * The indices parameters are referenced assuming the length as specified, and leading characters are ignored. For
     * example, if the string is "foo 12 34 5" and the length is 3, then index 0 is 12, index 1 is 34, and index 2 is 5.
     *
     * @param s         The string to parse
     * @param indices   An array indicating which indexes should be populated in the final array; other values will be
     *                  skipped. This index is zero-referenced assuming the rightmost delimited fields of the string
     *                  contain the array.
     * @param length    The total number of elements in the string array. It is permissible for the string to have more
     *                  elements than this; leading elements will be ignored. This should be calculated once per text
     *                  format by {@link #countStringToLongArray}.
     * @param delimiter The character to delimit by.
     * @return If successful, an array of parsed longs. If parsing errors occurred, will be an array of zeros.
     */
    public static long[] parseStringToLongArray(String s, int[] indices, int length, char delimiter) {
        // Ensure that the last character is a number
        s = s.trim();

        long[] parsed = new long[indices.length];
        // Iterate from right-to-left of String
        // Fill right to left of result array using index array
        int charIndex = s.length();
        int parsedIndex = indices.length - 1;
        int stringIndex = length - 1;

        int power = 0;
        int c;
        boolean delimCurrent = false;
        boolean numeric = true;
        boolean numberFound = false; // ignore nonnumeric at end
        boolean dashSeen = false; // to flag uuids as nonnumeric
        while (--charIndex >= 0 && parsedIndex >= 0) {
            c = s.charAt(charIndex);
            if (c == delimiter) {
                // first parseable number?
                if (!numberFound && numeric) {
                    numberFound = true;
                }
                if (!delimCurrent) {
                    if (numberFound && indices[parsedIndex] == stringIndex--) {
                        parsedIndex--;
                    }
                    delimCurrent = true;
                    power = 0;
                    dashSeen = false;
                    numeric = true;
                }
            } else if (indices[parsedIndex] != stringIndex || c == '+' || !numeric) {
                // Doesn't impact parsing, ignore
                delimCurrent = false;
            } else if (c >= '0' && c <= '9' && !dashSeen) {
                if (power > 18 || (power == 17 && c == '9' && parsed[parsedIndex] > 223_372_036_854_775_807L)) {
                    parsed[parsedIndex] = Long.MAX_VALUE;
                } else {
                    parsed[parsedIndex] += (c - '0') * ParseUtil.POWERS_OF_TEN[power++];
                }
                delimCurrent = false;
            } else if (c == '-') {
                parsed[parsedIndex] *= -1L;
                delimCurrent = false;
                dashSeen = true;
            } else {
                // Flag as nonnumeric and continue unless we've seen a numeric
                // error on everything else
                if (numberFound) {
                    if (!noLog(s)) {
                        LOG.error("Illegal character parsing string '{}' to long array: {}", s, s.charAt(charIndex));
                    }
                    return new long[indices.length];
                }
                parsed[parsedIndex] = 0;
                numeric = false;
            }
        }
        if (parsedIndex > 0) {
            if (!noLog(s)) {
                LOG.error("Not enough fields in string '{}' parsing to long array: {}", s,
                        indices.length - parsedIndex);
            }
            return new long[indices.length];
        }
        return parsed;
    }

    /**
     * Test whether to log this message
     *
     * @param s The string to log
     * @return True if the string begins with {@code NOLOG}
     */
    private static boolean noLog(String s) {
        return s.startsWith("NOLOG: ");
    }

    /**
     * Parses a delimited string to count elements of an array of longs. Intended to be called once to calculate the
     * {@code length} field for {@link #parseStringToLongArray}.
     *
     * As a special case, non-numeric fields (such as UUIDs in OpenVZ) at the end of the list are ignored.
     *
     * @param s         The string to parse
     * @param delimiter The character to delimit by
     * @return The number of parsable long values which follow the last unparsable value.
     */
    public static int countStringToLongArray(String s, char delimiter) {
        // Ensure that the last character is a number
        s = s.trim();

        // Iterate from right-to-left of String
        // Fill right to left of result array using index array
        int charIndex = s.length();
        int numbers = 0;

        int c;
        boolean delimCurrent = false;
        boolean numeric = true;
        boolean dashSeen = false; // to flag uuids as nonnumeric
        while (--charIndex >= 0) {
            c = s.charAt(charIndex);
            if (c == delimiter) {
                if (!delimCurrent) {
                    if (numeric) {
                        numbers++;
                    }
                    delimCurrent = true;
                    dashSeen = false;
                    numeric = true;
                }
            } else if (c == '+' || !numeric) {
                // Doesn't impact parsing, ignore
                delimCurrent = false;
            } else if (c >= '0' && c <= '9' && !dashSeen) {
                delimCurrent = false;
            } else if (c == '-') {
                delimCurrent = false;
                dashSeen = true;
            } else {
                // we found non-digit or delimiter. If not last field, exit
                if (numbers > 0) {
                    return numbers;
                }
                // Else flag as nonnumeric and continue
                numeric = false;
            }
        }
        // We got to beginning of string with only numbers, count start as a delimiter
        // and exit
        return numbers + 1;
    }

    /**
     * Get a String in a line of text between two marker strings
     *
     * @param text   Text to search for match
     * @param before Start matching after this text
     * @param after  End matching before this text
     * @return Text between the strings before and after, or empty string if either marker does not exist
     */
    public static String getTextBetweenStrings(String text, String before, String after) {

        String result = "";

        if (text.contains(before) && text.contains(after)) {
            result = text.substring(text.indexOf(before) + before.length());
            result = result.substring(0, result.indexOf(after));
        }
        return result;
    }

    /**
     * Remove the leading whitespace from a string.
     * <p>
     * Equivalent to {@code s.replaceFirst("^\\s+", "")} without compiling a {@link Pattern}, and to Java 11's
     * {@code String.stripLeading()}, which this module cannot use.
     *
     * @param s The string to trim
     * @return The string with any leading whitespace removed
     */
    public static String trimLeadingWhitespace(String s) {
        int start = 0;
        while (start < s.length() && Character.isWhitespace(s.charAt(start))) {
            start++;
        }
        return start == 0 ? s : s.substring(start);
    }

    /**
     * Get the text of a line following a marker string.
     * <p>
     * Intended for the {@code key: value} lines that command output is full of, where the caller has already
     * established that the marker is present. Unlike {@code line.split(marker, -1)[1]}, the marker is matched literally
     * rather than as a regular expression, and no {@link Pattern} is compiled.
     *
     * @param text   Text to search for match
     * @param marker Start matching after this text
     * @return Text following the first occurrence of the marker, or empty string if the marker does not exist
     */
    public static String getTextAfterString(String text, String marker) {
        int index = text.indexOf(marker);
        return index < 0 ? "" : text.substring(index + marker.length());
    }

    /**
     * Convert a long representing filetime (100-ns since 1601 epoch) to ms since 1970 epoch
     *
     * @param filetime A 64-bit value equivalent to FILETIME
     * @param local    True if converting from a local filetime (PDH counter); false if already UTC (WMI PerfRawData
     *                 classes)
     * @return Equivalent milliseconds since the epoch
     */
    public static long filetimeToUtcMs(long filetime, boolean local) {
        return filetime / 10_000L - EPOCH_DIFF - (local ? TZ_OFFSET : 0L);
    }

    /**
     * Parse a date in MM-DD-YYYY or MM/DD/YYYY to YYYY-MM-DD
     *
     * @param dateString The date in MM DD YYYY format
     * @return The date in ISO YYYY-MM-DD format if parseable, or the original string
     */
    public static String parseMmDdYyyyToYyyyMmDD(String dateString) {
        try {
            // Date is MM-DD-YYYY, convert to YYYY-MM-DD
            return String.format(Locale.ROOT, "%s-%s-%s", dateString.substring(6, 10), dateString.substring(0, 2),
                    dateString.substring(3, 5));
        } catch (StringIndexOutOfBoundsException e) {
            return dateString;
        }
    }

    /**
     * Converts a string in CIM Date Format, as returned by WMI for DateTime types, into a
     * {@link java.time.OffsetDateTime}.
     *
     * @param cimDateTime A non-null DateTime String in CIM date format, e.g., <code>20160513072950.782000-420</code>
     * @return The parsed {@link java.time.OffsetDateTime} if the string is parsable, otherwise
     *         {@link oshi.util.Constants#UNIX_EPOCH}.
     */
    public static OffsetDateTime parseCimDateTimeToOffset(String cimDateTime) {
        // Keep first 22 characters: digits, decimal, and + or - sign
        // But alter last 3 characters from a minute offset to hh:mm
        try {
            // From WMI as 20160513072950.782000-420,
            int tzInMinutes = Integer.parseInt(cimDateTime.substring(22));
            // modified to 20160513072950.782000-07:00 which can be parsed
            LocalTime offsetAsLocalTime = LocalTime.MIDNIGHT.plusMinutes(tzInMinutes);
            return OffsetDateTime.parse(
                    cimDateTime.substring(0, 22) + offsetAsLocalTime.format(DateTimeFormatter.ISO_LOCAL_TIME),
                    ParseUtil.CIM_FORMAT);
        } catch (IndexOutOfBoundsException // if cimDate not 22+ chars
                | NumberFormatException // if TZ minutes doesn't parse
                | DateTimeParseException e) {
            LOG.trace("Unable to parse {} to CIM DateTime.", cimDateTime);
            return Constants.UNIX_EPOCH;
        }
    }

    /**
     * Checks if a file path equals or starts with an prefix in the given list
     *
     * @param prefixList A list of path prefixes
     * @param path       a string path to check
     * @return true if the path exactly equals, or starts with one of the strings in prefixList
     */
    public static boolean filePathStartsWith(List<String> prefixList, String path) {
        for (String match : prefixList) {
            if (path.equals(match) || path.startsWith(match + "/")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Parses a string like "53G" or "54.904 M" to its long value.
     *
     * @param count A count with a multiplier like "4096 M"
     * @return the count parsed to a long
     */
    public static long parseMultipliedToLongs(String count) {
        Matcher matcher = UNITS_PATTERN.matcher(count.trim());
        String[] mem;
        if (matcher.find() && matcher.groupCount() == 3) {
            mem = new String[2];
            mem[0] = matcher.group(1);
            mem[1] = matcher.group(3);
        } else {
            mem = new String[] { count };
        }

        double number = ParseUtil.parseDoubleOrDefault(mem[0], 0L);
        if (mem.length == 2 && mem[1] != null && !mem[1].isEmpty()) {
            switch (mem[1].charAt(0)) {
                case 'T':
                    number *= 1_000_000_000_000L;
                    break;
                case 'G':
                    number *= 1_000_000_000L;
                    break;
                case 'M':
                    number *= 1_000_000L;
                    break;
                case 'K':
                case 'k':
                    number *= 1_000L;
                    break;
                default:
            }
        }
        return (long) number;
    }

    /**
     * Parses a string such as "4096 MB" to its long. Used to parse macOS and *nix memory chip sizes. Although the units
     * given are decimal they must parse to binary units.
     *
     * @param size A string of memory sizes like "4096 MB"
     * @return the size parsed to a long
     */
    public static long parseDecimalMemorySizeToBinary(String size) {
        String[] mem = ParseUtil.whitespaces.split(size);
        if (mem.length < 2) {
            // If no spaces, use regexp
            Matcher matcher = BYTES_PATTERN.matcher(size.trim());
            if (matcher.find() && matcher.groupCount() == 2) {
                mem = new String[2];
                mem[0] = matcher.group(1);
                mem[1] = matcher.group(2);
            }
        }
        long capacity = ParseUtil.parseLongOrDefault(mem[0], 0L);
        if (mem.length == 2 && !mem[1].isEmpty()) {
            switch (mem[1].charAt(0)) {
                case 'T':
                    capacity <<= 40;
                    break;
                case 'G':
                    capacity <<= 30;
                    break;
                case 'M':
                    capacity <<= 20;
                    break;
                case 'K':
                case 'k':
                    capacity <<= 10;
                    break;
                default:
                    break;
            }
        }
        return capacity;
    }

    /**
     * Parse a Windows DeviceID to get the vendor ID, product ID, and Serial Number
     *
     * @param deviceId The DeviceID
     * @return A {@link Triplet} where the first element is the vendor ID, the second element is the product ID, and the
     *         third element is either a serial number or empty string if parsing was successful, or {@code null}
     *         otherwise
     */
    public static @Nullable Triplet<String, String, String> parseDeviceIdToVendorProductSerial(String deviceId) {
        Matcher m = VENDOR_PRODUCT_ID_SERIAL.matcher(deviceId);
        if (m.matches()) {
            String vendorId = "0x" + m.group(1).toLowerCase(Locale.ROOT);
            String productId = "0x" + m.group(2).toLowerCase(Locale.ROOT);
            String serial = m.group(4);
            return new Triplet<>(vendorId, productId, !m.group(3).isEmpty() || serial.contains("&") ? "" : serial);
        }
        return null;
    }

    /**
     * Parse a Windows DeviceID string to extract the vendor and product/device IDs as integers.
     *
     * <p>
     * Handles both full PNPDeviceID strings such as {@code PCI\VEN_8086&DEV_56A0&SUBSYS_...&REV_08\instance} and bare
     * {@code MatchingDeviceId} registry values such as {@code pci\ven_8086&dev_56a0&subsys_...} that lack a trailing
     * backslash instance component. Also handles USB {@code VID_xxxx&PID_xxxx} format. Matching is case-insensitive.
     *
     * @param deviceId The DeviceID or MatchingDeviceId string
     * @return A {@link Pair} of (vendorId, productId) as integers, or {@code null} if the string does not contain a
     *         recognisable {@code VEN_xxxx&DEV_xxxx} or {@code VID_xxxx&PID_xxxx} pattern
     */
    public static @Nullable Pair<Integer, Integer> parseDeviceIdToVendorProductIds(@Nullable String deviceId) {
        if (deviceId == null) {
            return null;
        }
        Matcher m = VENDOR_PRODUCT_ID.matcher(deviceId);
        if (m.matches()) {
            return new Pair<>(hexStringToInt(m.group(1), 0), hexStringToInt(m.group(2), 0));
        }
        return null;
    }

    /**
     * Parse a Linux lshw resources string to calculate the memory size
     *
     * @param resources A string containing one or more elements of the form {@code memory:b00000000-bffffffff}
     * @return The number of bytes consumed by the memory in the {@code resources} string
     */
    public static long parseLshwResourceString(String resources) {
        long bytes = 0L;
        // First split by whitespace
        String[] resourceArray = whitespaces.split(resources, -1);
        for (String r : resourceArray) {
            // Remove prefix
            if (r.startsWith("memory:")) {
                // Split to low and high
                String[] mem = r.substring(7).split("-", -1);
                if (mem.length == 2) {
                    try {
                        // Parse the hex strings
                        bytes += Long.parseLong(mem[1], 16) - Long.parseLong(mem[0], 16) + 1;
                    } catch (NumberFormatException e) {
                        LOG.trace(DEFAULT_LOG_MSG, r, e);
                    }
                }
            }
        }
        return bytes;
    }

    /**
     * Parse a Linux lspci machine readble line to its name and id
     *
     * @param line A string in the form Foo [bar]
     * @return A pair separating the String before the square brackets and within them if found, null otherwise
     */
    public static @Nullable Pair<String, String> parseLspciMachineReadable(String line) {
        Matcher matcher = LSPCI_MACHINE_READABLE.matcher(line);
        if (matcher.matches()) {
            return new Pair<>(matcher.group(1), matcher.group(2));
        }
        return null;
    }

    /**
     * Parse a Linux lspci line containing memory size
     *
     * @param line A string in the form Foo [size=256M]
     * @return A the memory size in bytes
     */
    public static long parseLspciMemorySize(String line) {
        Matcher matcher = LSPCI_MEMORY_SIZE.matcher(line);
        if (matcher.matches()) {
            return parseDecimalMemorySizeToBinary(matcher.group(1) + " " + matcher.group(2) + "B");
        }
        return 0;
    }

    /**
     * Parse a space-delimited list of integers which include hyphenated ranges to a list of just the integers. For
     * example, 0 1 4-7 parses to a list containing 0, 1, 4, 5, 6, and 7. Also support comma separated entries like 0,
     * 2-5, 7-8, 9 to a list containing 0, 2, 3, 4, 5, 7, 8, 9.
     *
     * @param str A string containing space-delimited integers or ranges of integers with a hyphen
     * @return A list of integers representing the provided range(s).
     */
    public static List<Integer> parseHyphenatedIntList(String str) {
        List<Integer> result = new ArrayList<>();
        String[] csvTokens = str.split(",", -1);
        for (String csvToken : csvTokens) {
            csvToken = csvToken.trim();
            for (String s : whitespaces.split(csvToken, -1)) {
                if (s.contains("-")) {
                    int first = getFirstIntValue(s);
                    int last = getNthIntValue(s, 2);
                    for (int i = first; i <= last; i++) {
                        result.add(i);
                    }
                } else {
                    int only = ParseUtil.parseIntOrDefault(s, -1);
                    if (only >= 0) {
                        result.add(only);
                    }
                }
            }
        }
        return result;
    }

    /**
     * Parse an integer in big endian IP format to its component bytes representing an IPv4 address
     *
     * @param ip The address as an integer
     * @return The address as an array of four bytes
     */
    public static byte[] parseIntToIP(int ip) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(ip).array();
    }

    /**
     * Parse an integer array in big endian IP format to its component bytes representing an IPv6 address
     *
     * @param ip6 The address as an integer array
     * @return The address as an array of sizteen bytes
     */
    public static byte[] parseIntArrayToIP(int[] ip6) {
        ByteBuffer bb = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN);
        for (int i : ip6) {
            bb.putInt(i);
        }
        return bb.array();
    }

    /**
     * TCP network addresses and ports are in big endian format by definition. The order of the two bytes in the 16-bit
     * unsigned short port value must be reversed
     *
     * @param port The port number in big endian order
     * @return The port number
     * @see <a href= "https://docs.microsoft.com/en-us/windows/win32/api/winsock/nf-winsock-ntohs">ntohs</a>
     */
    public static int bigEndian16ToLittleEndian(int port) {
        // 20480 = 0x5000 should be 0x0050 = 80
        // 47873 = 0xBB01 should be 0x01BB = 443
        return ((port >> 8) & 0xff) | ((port << 8) & 0xff00);
    }

    /**
     * Converts the 16 bytes of an IPv6 address, offset two bytes into the given array, to the 4-element int array
     * expected by {@link #parseUtAddrV6toIP}.
     * <p>
     * Per the {@code WTS_INFO_CLASS} docs, the IP address is offset by two bytes from the start of the {@code Address}
     * member of the {@code WTS_CLIENT_ADDRESS} structure.
     *
     * @param address a byte array holding a big-endian IPv6 address in bytes 2 through 17, such as the 20-byte
     *                {@code WTS_CLIENT_ADDRESS} {@code Address} member
     * @return a 4-element int array for {@link #parseUtAddrV6toIP}
     * @throws IllegalArgumentException if the array holds fewer than 18 bytes
     */
    public static int[] parseIPv6BytesToIntArray(byte @Nullable [] address) {
        if (address == null || address.length < 18) {
            throw new IllegalArgumentException("address must have at least 18 elements");
        }
        IntBuffer intBuf = ByteBuffer.wrap(Arrays.copyOfRange(address, 2, 18)).order(ByteOrder.BIG_ENDIAN)
                .asIntBuffer();
        int[] array = new int[intBuf.remaining()];
        intBuf.get(array);
        return array;
    }

    /**
     * Parse an integer array to an IPv4 or IPv6 as appropriate.
     * <p>
     * Intended for use on Utmp structures's {@code ut_addr_v6} element.
     *
     * @param utAddrV6 An array of 4 integers representing an IPv6 address. IPv4 address uses just utAddrV6[0]
     * @return A string representation of the IP address.
     */
    public static String parseUtAddrV6toIP(int[] utAddrV6) {
        if (utAddrV6.length != 4) {
            throw new IllegalArgumentException("ut_addr_v6 must have exactly 4 elements");
        }
        // IPv4 has only first element
        if (utAddrV6[1] == 0 && utAddrV6[2] == 0 && utAddrV6[3] == 0) {
            // Special case for all 0's
            if (utAddrV6[0] == 0) {
                return "::";
            }
            // Parse using InetAddress
            byte[] ipv4 = ByteBuffer.allocate(4).putInt(utAddrV6[0]).array();
            try {
                return InetAddress.getByAddress(ipv4).getHostAddress();
            } catch (UnknownHostException e) {
                // Shouldn't happen with length 4 or 16
                return Constants.UNKNOWN;
            }
        }
        // Parse all 16 bytes
        byte[] ipv6 = ByteBuffer.allocate(16).putInt(utAddrV6[0]).putInt(utAddrV6[1]).putInt(utAddrV6[2])
                .putInt(utAddrV6[3]).array();
        try {
            return InetAddress.getByAddress(ipv6).getHostAddress()
                    .replaceAll("((?:(?:^|:)0+\\b){2,8}):?(?!\\S*\\b\\1:0+\\b)(\\S*)", "::$2");
        } catch (UnknownHostException e) {
            // Shouldn't happen with length 4 or 16
            return Constants.UNKNOWN;
        }
    }

    /**
     * Parses an IPv4 address in dotted-quad notation, accepting the abbreviated form UNIX routing tables use, in which
     * trailing zero octets are omitted, so that {@code 127} means {@code 127.0.0.0}, {@code 10.1} means
     * {@code 10.1.0.0} and {@code 140.211.9} means {@code 140.211.9.0}.
     *
     * @param address the address text, with any {@code /prefix} suffix already removed
     * @return the four address bytes, or an empty array if the text is not one to four dot-separated decimal octets in
     *         the range 0 to 255
     */
    public static byte[] parseIpv4AddressToBytes(String address) {
        if (address.isEmpty()) {
            return EMPTY_BYTE_ARRAY;
        }
        String[] parts = address.split("\\.", -1);
        if (parts.length > 4) {
            return EMPTY_BYTE_ARRAY;
        }
        byte[] bytes = new byte[4];
        for (int i = 0; i < parts.length; i++) {
            int octet = parseDecimalOctet(parts[i]);
            if (octet < 0) {
                return EMPTY_BYTE_ARRAY;
            }
            bytes[i] = (byte) octet;
        }
        return bytes;
    }

    private static int parseDecimalOctet(String part) {
        // Reject an empty part, which is a leading, trailing or doubled dot, and reject any non-ASCII digit before
        // parsing: parseIntOrDefault maps a malformed value to the default, which a valid "0" is indistinguishable
        // from if the default is in range.
        if (part.isEmpty() || part.length() > 3) {
            return -1;
        }
        for (int i = 0; i < part.length(); i++) {
            char c = part.charAt(i);
            if (c < '0' || c > '9') {
                return -1;
            }
        }
        int octet = parseIntOrDefault(part, -1);
        return octet > 255 ? -1 : octet;
    }

    /**
     * Parses an IPv6 address in the text form of RFC 4291, including {@code ::} compression and a trailing IPv4-mapped
     * dotted quad. Any {@code %zone} scope suffix is ignored, matching the default gateway getters, which also strip
     * it, and which a byte array cannot represent in any case.
     *
     * @param address the address text, with any {@code /prefix} suffix already removed
     * @return the sixteen address bytes, or an empty array if the text is not an IPv6 address
     */
    public static byte[] parseIpv6AddressToBytes(String address) {
        int zoneIndex = address.indexOf('%');
        String addr = zoneIndex < 0 ? address : address.substring(0, zoneIndex);
        if (addr.isEmpty() || addr.indexOf(':') < 0) {
            return EMPTY_BYTE_ARRAY;
        }
        int doubleColon = addr.indexOf("::");
        if (doubleColon >= 0 && doubleColon != addr.lastIndexOf("::")) {
            // More than one "::" cannot be resolved to a unique address
            return EMPTY_BYTE_ARRAY;
        }
        byte[] bytes = new byte[16];
        String head = doubleColon < 0 ? addr : addr.substring(0, doubleColon);
        int headBytes = parseIpv6Groups(head, bytes, 0);
        if (headBytes < 0) {
            return EMPTY_BYTE_ARRAY;
        }
        if (doubleColon < 0) {
            // Without compression every one of the eight groups must be present
            return headBytes == 16 ? bytes : EMPTY_BYTE_ARRAY;
        }
        byte[] tail = new byte[16];
        int tailBytes = parseIpv6Groups(addr.substring(doubleColon + 2), tail, 0);
        // The "::" must stand for at least one all-zero group, so the two halves cannot fill all sixteen bytes
        if (tailBytes < 0 || headBytes + tailBytes > 14) {
            return EMPTY_BYTE_ARRAY;
        }
        System.arraycopy(tail, 0, bytes, 16 - tailBytes, tailBytes);
        return bytes;
    }

    private static int parseIpv6Groups(String groups, byte[] dest, int offset) {
        if (groups.isEmpty()) {
            return 0;
        }
        String[] parts = groups.split(":", -1);
        int pos = offset;
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            if (part.isEmpty()) {
                return -1;
            }
            if (i == parts.length - 1 && part.indexOf('.') >= 0) {
                // A trailing dotted quad, as in "::ffff:1.2.3.4". Only the full four octets are valid here, so the
                // abbreviation parseIpv4AddressToBytes allows must be rejected by counting separators.
                byte[] v4 = parseIpv4AddressToBytes(part);
                if (v4.length != 4 || countChar(part, '.') != 3 || pos + 4 > dest.length) {
                    return -1;
                }
                System.arraycopy(v4, 0, dest, pos, 4);
                return pos - offset + 4;
            }
            int group = parseHexGroup(part);
            if (group < 0 || pos + 2 > dest.length) {
                return -1;
            }
            dest[pos++] = (byte) (group >> 8);
            dest[pos++] = (byte) group;
        }
        return pos - offset;
    }

    private static int parseHexGroup(String part) {
        if (part.length() > 4) {
            return -1;
        }
        for (int i = 0; i < part.length(); i++) {
            char c = part.charAt(i);
            if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F')) {
                return -1;
            }
        }
        return hexStringToInt(part, -1);
    }

    private static int countChar(String s, char c) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == c) {
                count++;
            }
        }
        return count;
    }

    /**
     * Parses a routing table destination token into its address bytes and the prefix length it states.
     * <p>
     * Recognizes the literal {@code default}, an address with an explicit prefix ({@code 2601:601:d47c:3090::/64}), an
     * abbreviated network with an explicit prefix ({@code 10.1/23}), and a bare address ({@code 10.0.0.1},
     * {@code ::1%1}).
     * <p>
     * An IPv4 network abbreviated to fewer than four octets and carrying no explicit prefix, as DragonFly BSD prints
     * {@code 192.168.122} for a {@code /24}, states its prefix through the octet count. A bare four-octet address
     * states no prefix length; the caller supplies one from the route's flags or from a separate netmask column.
     *
     * @param destination the destination token
     * @param ipv6        whether the token belongs to an IPv6 routing table, which decides how {@code default} is
     *                    interpreted
     * @return a pair of the address bytes and the stated prefix length, which is 0 for {@code default} and -1 when the
     *         token states none. The bytes are empty and the prefix length -1 when the token is not an address, which
     *         is how header, banner and separator lines are recognized and skipped.
     */
    public static Pair<byte[], Integer> parseRouteDestination(String destination, boolean ipv6) {
        String token = destination;
        int prefix = -1;
        int slash = token.indexOf('/');
        if (slash >= 0) {
            prefix = parseIntOrDefault(token.substring(slash + 1), -1);
            token = token.substring(0, slash);
        }
        byte[] bytes;
        if ("default".equals(token)) {
            bytes = new byte[ipv6 ? 16 : 4];
            prefix = 0;
        } else if (token.indexOf(':') >= 0) {
            bytes = parseIpv6AddressToBytes(token);
        } else {
            bytes = parseIpv4AddressToBytes(token);
            // Infer only when the token stated no prefix at all. Testing the separator rather than the parsed value
            // matters because an unparseable suffix such as "10/foo" also yields -1, and that is malformed input which
            // must stay unknown rather than silently acquiring an inferred prefix.
            if (slash < 0 && bytes.length == 4) {
                // An abbreviated IPv4 network states its prefix by how many octets it prints. netstat drops the
                // trailing zero octets and the explicit length together, but only when the mask falls on an octet
                // boundary, so "192.168.122" can only mean /24. A mask that does not is printed in full, as "10.1/23".
                // Four octets state nothing: a host route takes its width from the H flag, and Solaris prints whole
                // network addresses whose mask arrives in a separate column, so inferring /32 there would be wrong.
                int octets = countChar(token, '.') + 1;
                if (octets < 4) {
                    prefix = octets * 8;
                }
            }
        }
        if (bytes.length == 0) {
            return new Pair<>(EMPTY_BYTE_ARRAY, -1);
        }
        int maxPrefix = bytes.length * 8;
        return new Pair<>(bytes, prefix > maxPrefix ? maxPrefix : prefix);
    }

    /**
     * Counts the leading one bits of a subnet mask, giving the equivalent CIDR prefix length.
     *
     * @param netmask the mask bytes, four for IPv4 or sixteen for IPv6
     * @return the prefix length, or -1 if the array is empty or the mask's one bits are not contiguous
     */
    public static int netmaskToPrefixLength(byte[] netmask) {
        if (netmask.length == 0) {
            return -1;
        }
        int prefix = 0;
        for (byte b : netmask) {
            int value = b & 0xff;
            int bits = 0;
            while ((value & 0x80) != 0) {
                bits++;
                value = (value << 1) & 0xff;
            }
            prefix += bits;
            if (bits < 8) {
                break;
            }
        }
        // A mask is only meaningful if its one bits are contiguous. Reconstruct it from the count and compare, which
        // rejects a discontiguous mask such as 255.0.255.0 that the count alone would report as /8.
        for (int i = 0; i < netmask.length; i++) {
            int expected = 0;
            for (int bit = 0; bit < 8; bit++) {
                if (i * 8 + bit < prefix) {
                    expected |= 0x80 >> bit;
                }
            }
            if ((netmask[i] & 0xff) != expected) {
                return -1;
            }
        }
        return prefix;
    }

    /**
     * Counts the leading one bits of a subnet mask in text form, such as the {@code 255.255.255.248} that Solaris
     * {@code netstat -rnv} reports.
     *
     * @param netmask the mask in dotted-quad or IPv6 text form
     * @return the prefix length, or -1 if the text is not a contiguous mask
     */
    public static int netmaskToPrefixLength(String netmask) {
        return netmaskToPrefixLength(
                netmask.indexOf(':') >= 0 ? parseIpv6AddressToBytes(netmask) : parseIpv4AddressToBytes(netmask));
    }

    /**
     * Tests whether a token is a UNIX routing table flags field, that is, a short run of ASCII letters such as
     * {@code UG}, {@code UHSb} or {@code UHLWIir}.
     * <p>
     * Used both to recognize a data row among header, banner and separator lines and, on Solaris, to locate the flags
     * column when an empty column has collapsed under whitespace splitting. Note that an all-letter word such as
     * {@code default} also satisfies this test, so callers must only apply it to columns where such a word cannot
     * appear.
     *
     * @param token the token to test
     * @return {@code true} if the token is one to twelve ASCII letters
     */
    public static boolean isRouteFlags(String token) {
        if (token.isEmpty() || token.length() > 12) {
            return false;
        }
        for (int i = 0; i < token.length(); i++) {
            char c = token.charAt(i);
            if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')) {
                return false;
            }
        }
        return true;
    }

    /**
     * Parses a string of hex digits to an int value.
     *
     * @param hexString    A sequence of hex digits
     * @param defaultValue default value to return if parse fails
     * @return The corresponding int value
     */
    public static int hexStringToInt(@Nullable String hexString, int defaultValue) {
        if (hexString != null) {
            try {
                if (hexString.startsWith("0x")) {
                    return new BigInteger(hexString.substring(2), 16).intValue();
                } else {
                    return new BigInteger(hexString, 16).intValue();
                }
            } catch (NumberFormatException e) {
                LOG.trace(DEFAULT_LOG_MSG, hexString, e);
            }
        }
        // Hex failed to parse, just return the default long
        return defaultValue;
    }

    /**
     * Parses a string of hex digits to a long value.
     *
     * @param hexString    A sequence of hex digits
     * @param defaultValue default value to return if parse fails
     * @return The corresponding long value
     */
    public static long hexStringToLong(@Nullable String hexString, long defaultValue) {
        if (hexString != null) {
            try {
                if (hexString.startsWith("0x")) {
                    return new BigInteger(hexString.substring(2), 16).longValue();
                } else {
                    return new BigInteger(hexString, 16).longValue();
                }
            } catch (NumberFormatException e) {
                LOG.trace(DEFAULT_LOG_MSG, hexString, e);
            }
        }
        // Hex failed to parse, just return the default long
        return defaultValue;
    }

    /**
     * Parses a String "....foo" to "foo"
     *
     * @param dotPrefixedStr A string with possibly leading dots
     * @return The string without the dots
     */
    public static String removeLeadingDots(String dotPrefixedStr) {
        int pos = 0;
        while (pos < dotPrefixedStr.length() && dotPrefixedStr.charAt(pos) == '.') {
            pos++;
        }
        return pos < dotPrefixedStr.length() ? dotPrefixedStr.substring(pos) : "";
    }

    /**
     * Parse a null-delimited byte array to a list of strings.
     *
     * @param bytes A byte array containing Strings delimited by null characters. Two consecutive null characters mark
     *              the end of the list.
     * @return A list of Strings between the nulls.
     */
    public static List<String> parseByteArrayToStrings(byte[] bytes) {
        List<String> strList = new ArrayList<>();
        int start = 0;
        int end = 0;
        // Iterate characters
        do {
            // If we've reached a delimiter or the end of the array or new line (linux), add to list
            if (end == bytes.length || bytes[end] == 0 || bytes[end] == '\n') {
                // Zero length string means two nulls, we're done
                if (start == end) {
                    break;
                }
                // Otherwise add string and reset start
                // Intentionally using platform default charset
                strList.add(new String(bytes, start, end - start, StandardCharsets.UTF_8));
                start = end + 1;
            }
        } while (end++ < bytes.length);
        return strList;
    }

    /**
     * Parse a null-delimited byte array to a map of string keys and values.
     *
     * @param bytes A byte array containing String key-value pairs with keys and values delimited by {@code =} and pairs
     *              delimited by null characters. Two consecutive null characters mark the end of the map.
     * @return A map of String key-value pairs between the nulls.
     */
    public static Map<String, String> parseByteArrayToStringMap(byte[] bytes) {
        // API does not specify any particular order of entries, but it is reasonable to
        // maintain whatever order the OS provided to the end user
        Map<String, String> strMap = new LinkedHashMap<>();
        int start = 0;
        int end = 0;
        String key = null;
        // Iterate characters
        do {
            // If we've reached a delimiter or the end of the array, add to list
            if (end == bytes.length || bytes[end] == 0) {
                // Zero length string with no key, we're done
                if (start == end && key == null) {
                    break;
                }
                // Otherwise add string (possibly empty) and reset start
                // Intentionally using platform default charset
                strMap.put(key, new String(bytes, start, end - start, StandardCharsets.UTF_8));
                key = null;
                start = end + 1;
            } else if (bytes[end] == '=' && key == null) {
                key = new String(bytes, start, end - start, StandardCharsets.UTF_8);
                start = end + 1;
            }
        } while (end++ < bytes.length);
        return strMap;
    }

    /**
     * Parse a null-delimited char array to a map of string keys and values.
     *
     * @param chars A char array containing String key-value pairs with keys and values delimited by {@code =} and pairs
     *              delimited by null characters. Two consecutive null characters mark the end of the map.
     * @return A map of String key-value pairs between the nulls.
     */
    public static Map<String, String> parseCharArrayToStringMap(char[] chars) {
        // API does not specify any particular order of entries, but it is reasonable to
        // maintain whatever order the OS provided to the end user
        Map<String, String> strMap = new LinkedHashMap<>();
        int start = 0;
        int end = 0;
        String key = null;
        // Iterate characters
        do {
            // If we've reached a delimiter or the end of the array, add to list
            if (end == chars.length || chars[end] == 0) {
                // Zero length string with no key, we're done
                if (start == end && key == null) {
                    break;
                }
                // Otherwise add string (possibly empty) and reset start
                // Intentionally using platform default charset
                strMap.put(key, new String(chars, start, end - start));
                key = null;
                start = end + 1;
            } else if (chars[end] == '=' && key == null) {
                key = new String(chars, start, end - start);
                start = end + 1;
            }
        } while (end++ < chars.length);
        return strMap;
    }

    /**
     * Parses a delimited String into an enum map. Multiple consecutive delimiters are treated as one.
     *
     * @param <K>    a type extending Enum
     * @param clazz  The enum class
     * @param values A delimited String to be parsed into the map
     * @param delim  the delimiter to use
     * @return An EnumMap populated in order using the delimited String values. If there are fewer String values than
     *         enum values, the later enum values are not mapped. The final enum value will contain the remainder of the
     *         String, including excess delimiters.
     */
    public static <K extends Enum<K>> Map<K, String> stringToEnumMap(Class<K> clazz, String values, char delim) {
        return stringToEnumMap(clazz, new ArrayList<>(EnumSet.allOf(clazz)), values, delim);
    }

    /**
     * Parses a delimited String into an enum map using an explicit, ordered subset of enum keys. Multiple consecutive
     * delimiters are treated as one. Unlike {@link #stringToEnumMap(Class, String, char)}, which maps every enum
     * constant in ordinal order, this overload maps only the supplied {@code keys} in the order given, so callers can
     * share a single enum across columns that vary by platform.
     *
     * @param <K>    a type extending Enum
     * @param clazz  The enum class (used to construct the backing {@link EnumMap})
     * @param keys   The ordered enum keys to map, one per delimited field
     * @param values A delimited String to be parsed into the map
     * @param delim  the delimiter to use
     * @return An EnumMap populated in order using the delimited String values. If there are fewer String values than
     *         keys, the later keys are not mapped. The final key will contain the remainder of the String, including
     *         excess delimiters.
     */
    public static <K extends Enum<K>> Map<K, String> stringToEnumMap(Class<K> clazz, List<K> keys, String values,
            char delim) {
        EnumMap<K, String> map = new EnumMap<>(clazz);
        int start = 0;
        int len = values.length();
        int keySize = keys.size();
        for (K key : keys) {
            // If this is the last enum, put the index at the end of the string, otherwise
            // put at delimiter
            int idx = --keySize == 0 ? len : values.indexOf(delim, start);
            if (idx >= 0) {
                map.put(key, values.substring(start, idx));
                start = idx;
                do {
                    start++;
                } while (start < len && values.charAt(start) == delim);
            } else {
                map.put(key, values.substring(start));
                break;
            }
        }
        return map;
    }

    /**
     * Checks if a value exists in the map for the given key and returns the value or unknown based on it
     *
     * @param map A map where the keys can be of any type and the values are Strings.
     * @param key The key for which to fetch the value from the map. The key can be of any type that is compatible with
     *            the map's key type.
     * @return The value associated with the key if the key exists in the map and the value is not empty; otherwise,
     *         returns a predefined "unknown" string
     */
    public static String getValueOrUnknown(Map<?, String> map, Object key) {
        return getStringValueOrUnknown(map.get(key));
    }

    /**
     * Returns the given string value if it is not empty; otherwise, returns {@code Constants.UNKNOWN}.
     *
     * @param value The input string value.
     * @return The input value if it is non-empty; otherwise, {@code Constants.UNKNOWN}.
     */
    public static String getStringValueOrUnknown(@Nullable String value) {
        return (value == null || value.isEmpty()) ? Constants.UNKNOWN : value;
    }

    /**
     * Returns the given string value if it is non-null; otherwise, returns an empty string.
     * <p>
     * Unlike {@link #getStringValueOrUnknown}, an empty input is returned unchanged rather than replaced, so this is
     * the normalizer for values whose absent form is an empty string rather than {@code Constants.UNKNOWN}.
     *
     * @param value The input string value.
     * @return The input value if it is non-null; otherwise, an empty string.
     */
    public static String getStringValueOrEmpty(@Nullable String value) {
        return value == null ? "" : value;
    }

    /**
     * Parses a list of strings into a map of string key-value pairs.
     *
     * @param lines     A list of strings, each containing a key-value pair separated by the separator
     * @param separator The character(s) that separate the key and value in each line
     * @return A map of String key-value pairs with the value whitespace trimmed
     */
    public static Map<String, String> parseStringListToMap(List<String> lines, String separator) {
        Map<String, String> map = new HashMap<>();
        for (String line : lines) {
            int idx = line.indexOf(separator);
            if (idx >= 0) {
                map.put(line.substring(0, idx), line.substring(idx + separator.length()).trim());
            }
        }
        return map;
    }

    /**
     * Parses a date string from a given format and converts it to epoch time (milliseconds since epoch). This method is
     * useful for handling date formats across different operating systems, such as:
     * <ul>
     * <li>{@code yyyyMMdd}</li>
     * <li>{@code dd/MM/yy, HH:mm}</li>
     * </ul>
     *
     * @param dateString  The date string to parse.
     * @param datePattern The expected date format pattern (e.g., {@code "yyyyMMdd"}).
     * @return The epoch time in milliseconds since January 1, 1970, UTC. Returns {@code 0} if parsing fails.
     */
    public static long parseDateToEpoch(@Nullable String dateString, String datePattern) {
        if (dateString == null || dateString.equals(Constants.UNKNOWN) || dateString.isEmpty()
                || datePattern.isEmpty()) {
            return 0; // Default value if date is unknown or empty or null
        }
        try {
            DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendPattern(datePattern)
                    .parseDefaulting(ChronoField.HOUR_OF_DAY, 0).parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0)
                    .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0).parseDefaulting(ChronoField.MILLI_OF_SECOND, 0)
                    .toFormatter(Locale.ROOT);
            LocalDateTime localDateTime = LocalDateTime.parse(dateString, formatter);
            return localDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        } catch (DateTimeParseException e) {
            LOG.trace("Unable to parse date string: {}", dateString);
            return 0;
        }
    }

    /**
     * Parses a timestamp that carries no year into an epoch time, resolving it to the most recent occurrence at or
     * before {@code now}.
     * <p>
     * Several UNIX commands report timestamps without a year, such as the {@code MMM d HH:mm} form of {@code who} and
     * {@code who -b}. Defaulting to the current year alone is not enough: read in January, a December timestamp would
     * resolve to a date eleven months in the future, so anything later than {@code now} is taken to be last year's.
     * This cannot resolve a timestamp more than a year old, which is indistinguishable from a recent one.
     * <p>
     * February 29 is handled by parsing strictly and reparsing against the previous year, rather than by subtracting
     * one from the result: the default resolver would quietly clamp a leap day to the 28th in a non-leap current year,
     * and subtracting a year from a valid one would do the same. A leap day valid in neither candidate year yields
     * {@code 0}.
     * <p>
     * Month names are parsed as English, which is what the C locale these commands are read under emits.
     *
     * @param dateString  the timestamp to parse, carrying no year
     * @param datePattern the expected format pattern, for example {@code "MMM d HH:mm"}
     * @param now         the moment to resolve the missing year against
     * @return the epoch time in milliseconds since January 1, 1970, UTC. Returns {@code 0} if parsing fails.
     */
    public static long parseYearlessDateToEpoch(@Nullable String dateString, String datePattern, LocalDateTime now) {
        if (dateString == null || dateString.isEmpty() || datePattern.isEmpty()) {
            return 0;
        }
        LocalDateTime thisYear = parseWithDefaultYear(dateString, datePattern, now.getYear());
        if (thisYear != null && !thisYear.isAfter(now)) {
            return thisYear.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        }
        // Either the timestamp falls later in the year than now, so it can only be last year's, or it is not a valid
        // date in the current year at all: February 29 outside a leap year, which the strict parse above rejects.
        // Reparsing handles both, and keeps a real leap day intact where subtracting a year would shift it to the
        // 28th.
        LocalDateTime lastYear = parseWithDefaultYear(dateString, datePattern, now.getYear() - 1);
        if (lastYear != null) {
            return lastYear.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        }
        LOG.trace("Unable to parse yearless date string: {}", dateString);
        return 0;
    }

    /**
     * Decodes a NUL-terminated byte array to a String, stopping at the first NUL byte. This matches the behavior of
     * JNA's {@code Native.toString(byte[], Charset)} and provides an equivalent for use in non-JNA code (FFM, pure
     * Java). If the array contains no NUL, the entire array is decoded.
     *
     * @param bytes   the byte array to decode
     * @param charset the charset to use for decoding
     * @return the decoded string up to (but not including) the first NUL byte, or an empty string if the array is null
     *         or empty
     */
    public static String decodeNulTerminated(byte @Nullable [] bytes, Charset charset) {
        if (bytes == null || bytes.length == 0) {
            return "";
        }
        int len = 0;
        while (len < bytes.length && bytes[len] != 0) {
            len++;
        }
        return new String(bytes, 0, len, charset);
    }

    private static @Nullable LocalDateTime parseWithDefaultYear(String dateString, String datePattern, int year) {
        try {
            // STRICT, because the default SMART style silently clamps February 29 to the 28th in a non-leap year
            // instead of rejecting it, which would resolve a genuine leap day to the wrong date rather than letting
            // the caller retry against the previous year
            DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendPattern(datePattern)
                    .parseDefaulting(ChronoField.YEAR, year).parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
                    .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0).parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0)
                    .parseDefaulting(ChronoField.MILLI_OF_SECOND, 0).toFormatter(Locale.US)
                    .withResolverStyle(ResolverStyle.STRICT);
            return LocalDateTime.parse(dateString, formatter);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}
