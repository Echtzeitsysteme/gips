/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oshi.annotation.concurrent.ThreadSafe;

/**
 * General utility methods
 */
@ThreadSafe
public final class Util {
    private static final Logger LOG = LoggerFactory.getLogger(Util.class);

    private Util() {
    }

    /**
     * Returns whether the current JVM is running in 64-bit mode.
     *
     * @return True if the JVM is 64-bit.
     */
    public static boolean is64Bit() {
        return IS_64BIT;
    }

    private static final boolean IS_64BIT;
    static {
        String model = System.getProperty("sun.cpu.bits");
        if (model != null) {
            IS_64BIT = "64".equals(model);
        } else {
            String arch = System.getProperty("os.arch", "");
            IS_64BIT = "x86-64".equals(arch) || "x86_64".equals(arch) || "amd64".equals(arch) || "ia64".equals(arch)
                    || "aarch64".equals(arch) || "ppc64".equals(arch) || "ppc64le".equals(arch) || "mips64".equals(arch)
                    || "mips64el".equals(arch) || "loongarch64".equals(arch);
        }
    }

    /**
     * Sleeps for the specified number of milliseconds.
     *
     * @param ms How long to sleep
     */
    public static void sleep(long ms) {
        try {
            LOG.trace("Sleeping for {} ms", ms);
            Thread.sleep(ms);
        } catch (InterruptedException e) { // NOSONAR java:S2142
            LOG.warn("Interrupted while sleeping for {} ms", ms, e);
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Tests if a String matches another String with a wildcard pattern.
     *
     * @param text    The String to test
     * @param pattern The String containing a wildcard pattern where ? represents a single character and * represents
     *                any number of characters. If the first character of the pattern is a carat (^) the test is
     *                performed against the remaining characters and the result of the test is the opposite.
     * @return True if the String matches or if the first character is ^ and the remainder of the String does not match.
     */
    public static boolean wildcardMatch(String text, String pattern) {
        if (!pattern.isEmpty() && pattern.charAt(0) == '^') {
            return !wildcardMatch(text, pattern.substring(1));
        }
        return text.matches(pattern.replace("?", ".?").replace("*", ".*?"));
    }

    /**
     * Tests if a String is either null or empty.
     * <p>
     * This is a predicate, so a nullability analyzer cannot infer from it that the tested String is non-null on the
     * following line. When the result feeds a value rather than a branch, prefer
     * {@link ParseUtil#getStringValueOrUnknown} or {@link ParseUtil#getStringValueOrEmpty}, whose non-null returns
     * carry that guarantee.
     *
     * @param s The string to test
     * @return True if the String is either null or empty.
     */
    public static boolean isBlank(@Nullable String s) {
        return s == null || s.isEmpty();
    }

    /**
     * Tests if session of a user logged in a device is valid or not.
     *
     * @param user      The user logged in
     * @param device    The device used by user
     * @param loginTime The login time of the user
     * @return True if Session is valid or False if the user of device is empty or the login time is lesser than zero or
     *         greater than current time.
     */
    public static boolean isSessionValid(String user, String device, Long loginTime) {
        return !(user.isEmpty() || device.isEmpty() || loginTime < 0 || loginTime > System.currentTimeMillis());
    }
}
