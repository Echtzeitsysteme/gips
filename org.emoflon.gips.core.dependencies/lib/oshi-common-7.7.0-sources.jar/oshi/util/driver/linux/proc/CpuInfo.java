/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util.driver.linux.proc;

import static oshi.util.linux.ProcPath.CPUINFO;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.util.Constants;
import oshi.util.FileUtil;
import oshi.util.ParseUtil;
import oshi.util.tuples.Quartet;

/**
 * Utility to read CPU info from {@code /proc/cpuinfo}
 */
@ThreadSafe
public final class CpuInfo {

    private CpuInfo() {
    }

    /**
     * Gets the CPU manufacturer from {@code /proc/cpuinfo}
     *
     * @return The manufacturer if known, null otherwise
     */
    public static @Nullable String queryCpuManufacturer() {
        return queryCpuManufacturer(FileUtil.readFile(CPUINFO));
    }

    /**
     * Parse the CPU manufacturer from /proc/cpuinfo lines.
     *
     * @param cpuInfo lines from /proc/cpuinfo
     * @return The manufacturer if known, null otherwise
     */
    static @Nullable String queryCpuManufacturer(List<String> cpuInfo) {
        for (String line : cpuInfo) {
            if (line.startsWith("CPU implementer")) {
                int part = ParseUtil.parseLastInt(line, 0);
                switch (part) {
                    case 0x41:
                        return "ARM";
                    case 0x42:
                        return "Broadcom";
                    case 0x43:
                        return "Cavium";
                    case 0x44:
                        return "DEC";
                    case 0x4e:
                        return "Nvidia";
                    case 0x50:
                        return "APM";
                    case 0x51:
                        return "Qualcomm";
                    case 0x53:
                        return "Samsung";
                    case 0x56:
                        return "Marvell";
                    case 0x66:
                        return "Faraday";
                    case 0x69:
                        return "Intel";
                    default:
                        return null;
                }
            }
        }
        return null;
    }

    /**
     * Gets the board manufacturer, model, version, and serial number from {@code /proc/cpuinfo}
     *
     * @return A quartet of strings for manufacturer, model, version, and serial number. Each one may be null if
     *         unknown.
     */
    public static Quartet<@Nullable String, @Nullable String, @Nullable String, @Nullable String> queryBoardInfo() {
        return queryBoardInfo(FileUtil.readFile(CPUINFO));
    }

    /**
     * Parse board info from /proc/cpuinfo lines.
     *
     * @param cpuInfo lines from /proc/cpuinfo
     * @return A quartet of strings for manufacturer, model, version, and serial number
     */
    static Quartet<@Nullable String, @Nullable String, @Nullable String, @Nullable String> queryBoardInfo(
            List<String> cpuInfo) {
        String pcManufacturer = null;
        String pcModel = null;
        String pcVersion = null;
        String pcSerialNumber = null;

        for (String line : cpuInfo) {
            String[] splitLine = ParseUtil.whitespacesColonWhitespace.split(line, -1);
            if (splitLine.length < 2) {
                continue;
            }
            switch (splitLine[0]) {
                case "Hardware":
                    pcModel = splitLine[1];
                    break;
                case "Revision":
                    pcVersion = splitLine[1];
                    if (pcVersion.length() > 1) {
                        pcManufacturer = queryBoardManufacturer(pcVersion.charAt(1));
                    }
                    break;
                case "Serial":
                    pcSerialNumber = splitLine[1];
                    break;
                default:
                    // Do nothing
            }
        }
        return new Quartet<>(pcManufacturer, pcModel, pcVersion, pcSerialNumber);
    }

    private static String queryBoardManufacturer(char digit) {
        switch (digit) {
            case '0':
                return "Sony UK";
            case '1':
                return "Egoman";
            case '2':
                return "Embest";
            case '3':
                return "Sony Japan";
            case '4':
                return "Embest";
            case '5':
                return "Stadium";
            default:
                return Constants.UNKNOWN;
        }
    }

    /**
     * Queries CPU feature flags from /proc/cpuinfo.
     *
     * @return a list of feature flag strings
     */
    public static List<String> queryFeatureFlags() {
        return queryFeatureFlags(FileUtil.readFile(CPUINFO));
    }

    /**
     * Parse feature flag lines from /proc/cpuinfo.
     *
     * @param cpuInfo lines from /proc/cpuinfo
     * @return deduplicated lines starting with "flags" or "features"
     */
    static List<String> queryFeatureFlags(List<String> cpuInfo) {
        return cpuInfo.stream().filter(f -> {
            String s = f.toLowerCase(Locale.ROOT);
            return s.startsWith("flags") || s.startsWith("features");
        }).distinct().collect(Collectors.toList());
    }
}
