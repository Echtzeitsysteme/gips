/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.linux;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.Immutable;
import oshi.hardware.UsbDevice;
import oshi.hardware.common.AbstractUsbDevice;

/**
 * A Linux USB device. Backends (udev via JNA or FFM, or the native-free sysfs reader) enumerate raw
 * {@link UdevUsbDevice} attributes; this class builds the controller device tree from them, so all the
 * parsing/parent-child/sorting logic lives in one place.
 */
@Immutable
public final class LinuxUsbDevice extends AbstractUsbDevice {

    private LinuxUsbDevice(String name, String vendor, String vendorId, String productId, String serialNumber,
            @Nullable String uniqueDeviceId, List<UsbDevice> connectedDevices) {
        super(name, vendor, vendorId, productId, serialNumber, uniqueDeviceId, connectedDevices);
    }

    /**
     * Builds the USB controller device tree from raw per-device attributes gathered by a backend.
     *
     * @param rawDevices the enumerated {@code usb_device} entries, in any order
     * @return a list of USB controllers, each with its connected-device tree
     */
    public static List<UsbDevice> getUsbDevices(List<UdevUsbDevice> rawDevices) {
        // Build lookup maps keyed by syspath, plus the parent -> children (hub) map and the list of root controllers
        Map<String, String> nameMap = new HashMap<>();
        Map<String, String> vendorMap = new HashMap<>();
        Map<String, String> vendorIdMap = new HashMap<>();
        Map<String, String> productIdMap = new HashMap<>();
        Map<String, String> serialMap = new HashMap<>();
        Map<String, List<String>> hubMap = new HashMap<>();
        List<String> usbControllers = new ArrayList<>();
        for (UdevUsbDevice device : rawDevices) {
            String syspath = device.getSyspath();
            String product = device.getProduct();
            if (product != null) {
                nameMap.put(syspath, product);
            }
            String manufacturer = device.getManufacturer();
            if (manufacturer != null) {
                vendorMap.put(syspath, manufacturer);
            }
            String vendorId = device.getVendorId();
            if (vendorId != null) {
                vendorIdMap.put(syspath, vendorId);
            }
            String productId = device.getProductId();
            if (productId != null) {
                productIdMap.put(syspath, productId);
            }
            String serial = device.getSerial();
            if (serial != null) {
                serialMap.put(syspath, serial);
            }
            String parent = device.getParentSyspath();
            if (parent == null) {
                usbControllers.add(syspath);
            } else {
                hubMap.computeIfAbsent(parent, x -> new ArrayList<>()).add(syspath);
            }
        }

        return usbControllers.stream().map(controller -> buildDeviceTree(controller, "0000", "0000", nameMap, vendorMap,
                vendorIdMap, productIdMap, serialMap, hubMap, LinuxUsbDevice::new)).collect(Collectors.toList());
    }

}
