/*
 * Copyright 2021-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.netbsd;

import java.io.File;
import java.nio.file.PathMatcher;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.unix.bsd.disk.MountTable;
import oshi.software.common.AbstractFileSystem;
import oshi.software.os.OSFileStore;
import oshi.util.ExecutingCommand;
import oshi.util.FileSystemUtil;
import oshi.util.ParseUtil;
import oshi.util.common.platform.unix.bsd.BsdSysctlUtil;
import oshi.util.tuples.Pair;

/**
 * The NetBSD File System contains {@link oshi.software.os.OSFileStore}s which are a storage pool, device, partition,
 * volume, concrete file system or other implementation specific means of file storage.
 */
@ThreadSafe
public class NetBsdFileSystem extends AbstractFileSystem {

    public static final String OSHI_NETBSD_FS_PATH_EXCLUDES = "oshi.os.netbsd.filesystem.path.excludes";
    public static final String OSHI_NETBSD_FS_PATH_INCLUDES = "oshi.os.netbsd.filesystem.path.includes";
    public static final String OSHI_NETBSD_FS_VOLUME_EXCLUDES = "oshi.os.netbsd.filesystem.volume.excludes";
    public static final String OSHI_NETBSD_FS_VOLUME_INCLUDES = "oshi.os.netbsd.filesystem.volume.includes";

    // pstat -T prints both counts with %3d, so either may be padded: "1100/10000 files", " 42/100 files"
    private static final Pattern PSTAT_FILES = Pattern.compile("\\s*(\\d+)/\\s*\\d+ files");

    private static final List<PathMatcher> FS_PATH_EXCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_NETBSD_FS_PATH_EXCLUDES);
    private static final List<PathMatcher> FS_PATH_INCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_NETBSD_FS_PATH_INCLUDES);
    private static final List<PathMatcher> FS_VOLUME_EXCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_NETBSD_FS_VOLUME_EXCLUDES);
    private static final List<PathMatcher> FS_VOLUME_INCLUDES = FileSystemUtil
            .loadAndParseFileSystemConfig(OSHI_NETBSD_FS_VOLUME_INCLUDES);

    @Override
    public List<OSFileStore> getFileStores(boolean localOnly) {
        return getFileStoreMatching(null, localOnly);
    }

    // Called by NetBsdOSFileStore
    static List<OSFileStore> getFileStoreMatching(@Nullable String nameToMatch, boolean localOnly) {
        List<OSFileStore> fsList = new ArrayList<>();

        // Get inode usage data
        String command = "df -i" + (localOnly ? " -l" : "");
        Pair<Map<String, Long>, Map<String, Long>> inodes = MountTable
                .parseDfInodes(ExecutingCommand.runNative(command));
        Map<String, Long> inodeFreeMap = inodes.getA();
        Map<String, Long> inodeTotalMap = inodes.getB();

        // Get mount table
        List<MountTable.Entry> mounts = MountTable.parseNetBsd(ExecutingCommand.runNative("mount"));
        for (MountTable.Entry mount : mounts) { // NOSONAR java:S135
            String volume = mount.getVolume();
            String path = mount.getPath();
            String type = mount.getType();
            String options = mount.getOptions();
            String uuid = "";

            // Skip non-local drives if requested, and exclude pseudo file systems
            boolean isLocal = !NETWORK_FS_TYPES.contains(type);
            if ((localOnly && !isLocal)
                    || (!path.equals("/") && (PSEUDO_FS_TYPES.contains(type) || FileSystemUtil.isFileStoreExcluded(path,
                            volume, FS_PATH_INCLUDES, FS_PATH_EXCLUDES, FS_VOLUME_INCLUDES, FS_VOLUME_EXCLUDES)))) {
                continue;
            }

            String name = path.substring(path.lastIndexOf('/') + 1);
            // Special case for /, pull last element of volume instead
            if (name.isEmpty()) {
                name = volume.substring(volume.lastIndexOf('/') + 1);
            }

            if (nameToMatch != null && !nameToMatch.equals(name)) {
                continue;
            }
            File f = new File(path);
            long totalSpace = f.getTotalSpace();
            long usableSpace = f.getUsableSpace();
            long freeSpace = f.getFreeSpace();

            String description;
            if (volume.startsWith("/dev") || path.equals("/")) {
                description = "Local Disk";
            } else if (volume.equals("tmpfs")) {
                // dynamic size in memory FS
                description = "Ram Disk (dynamic)";
            } else if (volume.equals("mfs")) {
                // fixed size in memory FS
                description = "Ram Disk (fixed)";
            } else if (NETWORK_FS_TYPES.contains(type)) {
                description = "Network Disk";
            } else {
                description = "Mount Point";
            }

            fsList.add(new NetBsdOSFileStore(name, volume, name, path, options, uuid, isLocal, "", description, type,
                    freeSpace, usableSpace, totalSpace, inodeFreeMap.getOrDefault(path, 0L),
                    inodeTotalMap.getOrDefault(path, 0L)));
        }
        return fsList;
    }

    @Override
    public long getOpenFileDescriptors() {
        // NetBSD has no sysctl for the count. pstat reads the kernel's nfiles counter, and is setgid kmem to do it
        return parsePstatTotalFiles(ExecutingCommand.runNative("/usr/sbin/pstat -T"));
    }

    /**
     * Parses the open file count from {@code pstat -T} output, whose first line reads {@code 1100/10000 files}.
     * Package-private for testing.
     *
     * @param lines the output of {@code pstat -T}
     * @return the number of open files, or 0 if no count was found
     */
    static long parsePstatTotalFiles(List<String> lines) {
        for (String line : lines) {
            Matcher m = PSTAT_FILES.matcher(line);
            if (m.matches()) {
                return ParseUtil.parseLongOrDefault(m.group(1), 0L);
            }
        }
        return 0L;
    }

    @Override
    public long getMaxFileDescriptors() {
        return BsdSysctlUtil.sysctl("kern.maxfiles", 0);
    }

    @Override
    public long getMaxFileDescriptorsPerProcess() {
        // NetBSD has no per-process sysctl; the hard RLIMIT_NOFILE is the ceiling a process may raise its limit to
        return capAtSystemLimit(BsdSysctlUtil.sysctl("proc.curproc.rlimit.descriptors.hard", 0L),
                getMaxFileDescriptors());
    }
}
