/*
 * Copyright 2021-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.netbsd;

import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.ARGS;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.CPUTIME;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.ETIME;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.LID;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.MAJFLT;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.MINFLT;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.NIVCSW;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.NVCSW;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.PRI;
import static oshi.software.common.os.unix.bsd.BsdPsThreadKeyword.STATE;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.software.common.os.unix.bsd.BsdOSThread;
import oshi.software.common.os.unix.bsd.BsdPsThreadKeyword;

/**
 * OSThread implementation
 */
@ThreadSafe
public class NetBsdOSThread extends BsdOSThread {

    /**
     * Ordered {@code ps} thread columns. Shared with NetBsdOSProcess's thread enumeration so the column list and
     * parsing stay in lockstep. {@code ARGS} must remain last (the row-complete sentinel).
     */
    public static final List<BsdPsThreadKeyword> PS_THREAD_KEYWORDS = Collections
            .unmodifiableList(Arrays.asList(LID, STATE, ETIME, CPUTIME, NIVCSW, NVCSW, MAJFLT, MINFLT, PRI, ARGS));

    public static final String PS_THREAD_COLUMNS = PS_THREAD_KEYWORDS.stream().map(Enum::name)
            .map(name -> name.toLowerCase(Locale.ROOT)).collect(Collectors.joining(","));

    /**
     * The {@code ps} command listing every LWP. Without {@code -s}, NetBSD prints one row per process, which carries
     * only its first LWP.
     */
    public static final String PS_THREAD_COMMAND = "ps -s -awwxo " + PS_THREAD_COLUMNS;

    /**
     * Constructs a new {@code NetBsdOSThread}.
     *
     * @param processId the owning process ID
     * @param threadMap the parsed {@code ps} columns for this thread
     */
    public NetBsdOSThread(int processId, Map<BsdPsThreadKeyword, String> threadMap) {
        super(processId);
        updateAttributes(threadMap);
    }

    /**
     * Constructs a new {@code NetBsdOSThread}.
     *
     * @param processId the owning process ID
     * @param threadId  the thread ID
     */
    public NetBsdOSThread(int processId, int threadId) {
        super(processId);
        this.threadId = threadId;
        updateAttributes();
    }

    @Override
    protected String nameFromArgs(String args) {
        // A thread is named for its process. The args column is not used as it is, because ps prints the full command
        // line when the kernel releases the arguments and a parenthesized placeholder when it does not, which it
        // refuses while the process is inside posix_spawn, so two readings of one thread would disagree
        return NetBsdOSProcess.parseName(args);
    }

    @Override
    protected List<BsdPsThreadKeyword> psThreadKeywords() {
        return PS_THREAD_KEYWORDS;
    }

    @Override
    protected String psThreadCommand() {
        return PS_THREAD_COMMAND;
    }
}
