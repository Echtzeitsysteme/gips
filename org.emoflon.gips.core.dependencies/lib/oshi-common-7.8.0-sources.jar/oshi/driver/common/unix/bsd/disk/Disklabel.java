/*
 * Copyright 2021-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.common.unix.bsd.disk;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.HWPartition;
import oshi.util.Constants;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;
import oshi.util.tuples.Pair;
import oshi.util.tuples.Quartet;

/**
 * Utility class parsing partition information from the BSD {@code disklabel} command. Shared by OpenBSD and NetBSD,
 * which produce the same disklabel output format.
 */
@ThreadSafe
public final class Disklabel {

    private static final String TOTAL_MARKER = "total sectors:";
    private static final String BPS_MARKER = "bytes/sector:";
    private static final String LABEL_MARKER = "label:";
    private static final String DUID_MARKER = "duid:";

    private Disklabel() {
    }

    /**
     * Gets disk and partition information by running {@code disklabel} and parsing its output. Falls back to {@code df}
     * if no partitions are returned (e.g., when not running as root).
     *
     * @param diskName The disk to fetch partition information from
     * @return A quartet containing the disk's name/label, DUID, size, and a list of partitions
     */
    public static Quartet<String, String, Long, List<HWPartition>> getDiskParams(String diskName) {
        Quartet<String, String, Long, List<HWPartition>> result = parseDiskParams(diskName,
                ExecutingCommand.runNative("disklabel -n " + diskName), Disklabel::getMajorMinor);
        if (!result.getD().isEmpty()) {
            return result;
        }
        // No partitions came back from disklabel. Fall back to df for the partition list, but keep whatever
        // header metadata (label / DUID / size) disklabel already produced — replacing only the empty partition
        // list rather than the entire Quartet.
        Quartet<String, String, Long, List<HWPartition>> fallback = parseDfFallback(diskName,
                ExecutingCommand.runNative("df -k"), Disklabel::getMajorMinor);
        return new Quartet<>(result.getA(), result.getB(), result.getC(), fallback.getD());
    }

    /**
     * Parses {@code disklabel -n} output to extract disk metadata and partitions.
     *
     * @param diskName         the disk being labeled
     * @param disklabelLines   raw output from {@code disklabel -n <diskName>}
     * @param majorMinorLookup function that resolves a (disk, partition-letter) pair to a (major, minor) device number
     *                         pair; tests may pass a stub that returns (0,0) without invoking {@code stat}.
     * @return A quartet of label, DUID, size in bytes, and partitions. An empty partition list signals the caller
     *         should fall back to {@link #parseDfFallback}.
     */
    public static Quartet<String, String, Long, List<HWPartition>> parseDiskParams(String diskName,
            List<String> disklabelLines, BiFunction<String, String, Pair<Integer, Integer>> majorMinorLookup) {
        // disklabel (requires root) supports 15 configurable partitions, `a' through `p', excluding `c'.
        // The `c' partition describes the entire physical disk. By convention `a' of the boot disk is root,
        // `b' is swap, and `i' is usually the boot record.
        List<HWPartition> partitions = new ArrayList<>();
        // Zero, not one: a drive with no media in it, and a disklabel read that fails for want of root, both produce
        // no output at all, and a size of 1 byte reads as a fact where 0 is the project's sentinel for "unknown".
        // Both markers appear together in real disklabel output, so a successful parse never sees these defaults.
        long totalSectors = 0L;
        int bytesPerSector = 0;
        String label = "";
        String duid = "";
        for (String line : disklabelLines) {
            if (line.contains(TOTAL_MARKER)) {
                // Parse as long to avoid int overflow for disks larger than ~2 TiB at 512-byte sectors.
                totalSectors = ParseUtil.parseLongOrDefault(ParseUtil.getTextAfterString(line, TOTAL_MARKER).trim(),
                        0L);
            } else if (line.contains(BPS_MARKER)) {
                bytesPerSector = ParseUtil.getFirstIntValue(line);
            } else if (line.contains(LABEL_MARKER)) {
                label = ParseUtil.getTextAfterString(line, LABEL_MARKER).trim();
            } else if (line.contains(DUID_MARKER)) {
                duid = ParseUtil.getTextAfterString(line, DUID_MARKER).trim();
            }
            if (line.trim().indexOf(':') == 1) {
                // Partition rows have a single letter followed by a colon:
                // a: 2097152 1024 4.2BSD 2048 16384 12958 # /
                String[] split = ParseUtil.whitespaces.split(line.trim(), 9);
                if (split.length > 4) {
                    String name = split[0].substring(0, 1);
                    Pair<Integer, Integer> majorMinor = majorMinorLookup.apply(diskName, name);
                    partitions.add(
                            new HWPartition(diskName + name, name, split[3], duid.isEmpty() ? "" : duid + "." + name,
                                    ParseUtil.parseLongOrDefault(split[1], 0L) * bytesPerSector, majorMinor.getA(),
                                    majorMinor.getB(), parseMountPoint(line)));
                }
            }
        }
        return new Quartet<>(label, duid, totalSectors * bytesPerSector, partitions);
    }

    /**
     * Gets the mount point from the comment that ends a partition row. OpenBSD writes the partition's mount point from
     * {@code fstab} there, and nothing for a partition {@code fstab} does not list. NetBSD never writes a mount point:
     * its comment is the partition's cylinder range, as in {@code # (Cyl. 0 - 63)}.
     *
     * @param line a partition row of {@code disklabel} output
     * @return the mount point, or an empty string if the row does not name one
     */
    static String parseMountPoint(String line) {
        int hash = line.indexOf('#');
        if (hash < 0) {
            return "";
        }
        String comment = line.substring(hash + 1).trim();
        return comment.startsWith("(") ? "" : comment;
    }

    /**
     * Parses {@code df -k} output as a fallback when {@code disklabel} returns no partitions (typically because the
     * caller lacks root privileges).
     * <p>
     * A row belongs to the disk when its device is the disk's name followed by a single partition letter, so that
     * {@code sd1} does not also claim {@code sd10}'s partitions. {@code -k} fixes the block size at 1024 bytes, which
     * plain {@code df} takes from the {@code BLOCKSIZE} environment variable. The mount point is the rest of the row,
     * which may hold spaces.
     *
     * @param diskName         the disk whose partitions are being enumerated
     * @param dfLines          raw output from {@code df -k}
     * @param majorMinorLookup function that resolves a (disk, partition-letter) pair to a (major, minor) device number
     *                         pair
     * @return A quartet of UNKNOWN label/DUID, 0 size, and partitions discovered from {@code df}. Callers that already
     *         have disklabel header metadata should combine it with the partition list from this result.
     */
    public static Quartet<String, String, Long, List<HWPartition>> parseDfFallback(String diskName,
            List<String> dfLines, BiFunction<String, String, Pair<Integer, Integer>> majorMinorLookup) {
        Pattern device = Pattern.compile("/dev/" + Pattern.quote(diskName) + "([a-p])");
        List<HWPartition> partitions = new ArrayList<>();
        for (String line : dfLines) {
            // Device, 1K-blocks, used, available, capacity, mount point
            String[] split = ParseUtil.whitespaces.split(line.trim(), 6);
            Matcher m = device.matcher(split[0]);
            if (split.length == 6 && m.matches()) {
                Pair<Integer, Integer> majorMinor = majorMinorLookup.apply(diskName, m.group(1));
                // 0 where the column will not parse: the size is unknown
                long partSize = ParseUtil.parseLongOrDefault(split[1], 0L) * 1024L;
                partitions.add(new HWPartition(split[0], split[0].substring(5), Constants.UNKNOWN, Constants.UNKNOWN,
                        partSize, majorMinor.getA(), majorMinor.getB(), split[5]));
            }
        }
        return new Quartet<>(Constants.UNKNOWN, Constants.UNKNOWN, 0L, partitions);
    }

    /**
     * Gets the major and minor device numbers of a disk or partition by running {@code stat} on its device node.
     *
     * @param diskName the disk name
     * @param name     the partition suffix appended to the disk name, or an empty string for the disk itself
     * @return a pair of major and minor device numbers, each 0 if they could not be read
     */
    public static Pair<Integer, Integer> getMajorMinor(String diskName, String name) {
        int major = 0;
        int minor = 0;
        String majorMinor = ExecutingCommand.getFirstAnswer("stat -f %Hr,%Lr /dev/" + diskName + name);
        int comma = majorMinor.indexOf(',');
        if (comma > 0 && comma < majorMinor.length()) {
            major = ParseUtil.parseIntOrDefault(majorMinor.substring(0, comma), 0);
            minor = ParseUtil.parseIntOrDefault(majorMinor.substring(comma + 1), 0);
        }
        return new Pair<>(major, minor);
    }
}
