/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.common.platform.unix.freebsd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.BinaryOperator;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.unix.freebsd.disk.GeomDiskList;
import oshi.driver.common.unix.freebsd.disk.GeomPartList;
import oshi.hardware.HWDiskStore;
import oshi.hardware.HWPartition;
import oshi.hardware.common.AbstractHWDiskStore;
import oshi.util.Constants;
import oshi.util.ExecutingCommand;
import oshi.util.ParseUtil;
import oshi.util.tuples.Quartet;

/**
 * Shared FreeBSD HWDiskStore logic. Subclasses provide the sysctl backend (JNA or FFM).
 */
@ThreadSafe
public abstract class FreeBsdHWDiskStore extends AbstractHWDiskStore {

    /**
     * Constructs a new {@code FreeBsdHWDiskStore}.
     *
     * @param name     the disk name
     * @param model    the model
     * @param serial   the serial number
     * @param size     the size in bytes
     * @param diskType the disk type
     */
    protected FreeBsdHWDiskStore(String name, String model, String serial, long size, String diskType) {
        super(name, model, serial, size, diskType);
    }

    @Override
    public synchronized boolean updateAttributes() {
        List<String> output = ExecutingCommand.runNative("iostat -Ix " + getName());
        long now = System.currentTimeMillis();
        boolean diskFound = false;
        for (String line : output) {
            String[] split = ParseUtil.whitespaces.split(line, -1);
            if (split.length < 7 || !split[0].equals(getName())) {
                continue;
            }
            diskFound = true;
            this.reads = (long) ParseUtil.parseDoubleOrDefault(split[1], 0d);
            this.writes = (long) ParseUtil.parseDoubleOrDefault(split[2], 0d);
            this.readBytes = (long) (ParseUtil.parseDoubleOrDefault(split[3], 0d) * 1024);
            this.writeBytes = (long) (ParseUtil.parseDoubleOrDefault(split[4], 0d) * 1024);
            this.currentQueueLength = ParseUtil.parseLongOrDefault(split[5], 0L);
            this.transferTime = (long) (ParseUtil.parseDoubleOrDefault(split[6], 0d) * 1000);
            this.timeStamp = now;
        }
        return diskFound;
    }

    /**
     * Gets the disks on this machine using the provided sysctl accessor.
     *
     * @param <T>       the concrete disk store type
     * @param sysctlStr reads a string sysctl given (name, default)
     * @param factory   constructs the platform-specific instance
     * @return a list of {@link HWDiskStore} objects representing the disks
     */
    protected static <T extends FreeBsdHWDiskStore> List<HWDiskStore> getDisks(BinaryOperator<String> sysctlStr,
            DiskStoreFactory<T> factory) {
        List<HWDiskStore> diskList = new ArrayList<>();

        Map<String, List<HWPartition>> partitionMap = GeomPartList.queryPartitions();
        Map<String, Quartet<String, String, Long, String>> diskInfoMap = GeomDiskList.queryDisks();

        String kernDisks = sysctlStr.apply("kern.disks", "");
        if (kernDisks.isEmpty()) {
            return diskList;
        }
        List<String> devices = Arrays.asList(ParseUtil.whitespaces.split(kernDisks, -1));

        List<String> iostat = ExecutingCommand.runNative("iostat -Ix");
        long now = System.currentTimeMillis();
        for (String line : iostat) {
            String[] split = ParseUtil.whitespaces.split(line, -1);
            if (split.length > 6 && devices.contains(split[0])) {
                Quartet<String, String, Long, String> storeInfo = diskInfoMap.get(split[0]);
                T store = (storeInfo == null)
                        ? factory.create(split[0], Constants.UNKNOWN, Constants.UNKNOWN, 0L, "Unknown")
                        : factory.create(split[0], storeInfo.getA(), storeInfo.getB(), storeInfo.getC(),
                                storeInfo.getD());
                store.reads = (long) ParseUtil.parseDoubleOrDefault(split[1], 0d);
                store.writes = (long) ParseUtil.parseDoubleOrDefault(split[2], 0d);
                store.readBytes = (long) (ParseUtil.parseDoubleOrDefault(split[3], 0d) * 1024);
                store.writeBytes = (long) (ParseUtil.parseDoubleOrDefault(split[4], 0d) * 1024);
                store.currentQueueLength = ParseUtil.parseLongOrDefault(split[5], 0L);
                store.transferTime = (long) (ParseUtil.parseDoubleOrDefault(split[6], 0d) * 1000);
                store.setPartitionList(
                        Collections.unmodifiableList(partitionMap.getOrDefault(split[0], Collections.emptyList())
                                .stream().sorted(Comparator.comparing(HWPartition::getName))
                                .collect(java.util.stream.Collectors.toList())));
                store.timeStamp = now;
                diskList.add(store);
            }
        }
        return diskList;
    }

    /**
     * Factory for creating platform-specific FreeBsdHWDiskStore instances.
     *
     * @param <T> the concrete disk store type
     */
    @FunctionalInterface
    protected interface DiskStoreFactory<T extends FreeBsdHWDiskStore> {
        /**
         * Creates a platform-specific instance.
         *
         * @param name     the disk name
         * @param model    the model
         * @param serial   the serial number
         * @param size     the size in bytes
         * @param diskType the disk type
         * @return the new instance
         */
        T create(String name, String model, String serial, long size, String diskType);
    }
}
