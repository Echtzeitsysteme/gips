/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.common.os.unix.solaris;

import static oshi.software.os.OSProcess.State.INVALID;
import static oshi.util.Memoizer.defaultExpiration;
import static oshi.util.Memoizer.memoize;

import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import oshi.driver.common.unix.solaris.PsInfo;
import oshi.driver.common.unix.solaris.SolarisLwpsInfo;
import oshi.driver.common.unix.solaris.SolarisPrUsage;
import oshi.software.common.AbstractOSThread;
import oshi.util.Util;

/**
 * Abstract base for Solaris OSThread. All attribute parsing is shared via the common {@code lwpsinfo}/{@code usage}
 * carriers; there is no platform-specific behavior, so the JNA and FFM subclasses add only their constructors.
 */
public abstract class SolarisOSThread extends AbstractOSThread {

    private final Supplier<@Nullable SolarisLwpsInfo> lwpsinfo = memoize(this::queryLwpsInfo, defaultExpiration());
    private final Supplier<@Nullable SolarisPrUsage> prusage = memoize(this::queryPrUsage, defaultExpiration());

    /**
     * Constructs a new {@code SolarisOSThread}.
     *
     * @param pid   the process ID
     * @param lwpid the lightweight process ID
     */
    protected SolarisOSThread(int pid, int lwpid) {
        super(pid);
        this.threadId = lwpid;
        updateAttributes();
    }

    private @Nullable SolarisLwpsInfo queryLwpsInfo() {
        return PsInfo.queryLwpsInfo(this.getOwningProcessId(), this.getThreadId());
    }

    private @Nullable SolarisPrUsage queryPrUsage() {
        return PsInfo.queryPrUsage(this.getOwningProcessId(), this.getThreadId());
    }

    @Override
    public synchronized boolean updateAttributes() {
        SolarisLwpsInfo info = lwpsinfo.get();
        if (info == null) {
            this.state = INVALID;
            return false;
        }
        SolarisPrUsage usage = prusage.get();
        long now = System.currentTimeMillis();
        this.state = SolarisOSProcess.getStateFromOutput((char) info.pr_sname);
        this.startTime = info.pr_start.toMillis();
        // Avoid divide by zero for processes up less than a millisecond
        long elapsedTime = now - this.startTime;
        this.upTime = elapsedTime < 1L ? 1L : elapsedTime;
        this.startMemoryAddress = info.pr_addr;
        this.priority = info.pr_pri;
        // Each field is written once, so a reader never sees a transient zero; without the usage file, lwpsinfo gives
        // only the total CPU time
        this.kernelTime = usage == null ? 0L : usage.pr_stime.toMillis();
        this.userTime = usage == null ? info.pr_time.toMillis() : usage.pr_utime.toMillis();
        this.contextSwitches = usage == null ? 0L : usage.pr_ictx + usage.pr_vctx;
        this.minorFaults = usage == null ? 0L : usage.pr_minf;
        this.majorFaults = usage == null ? 0L : usage.pr_majf;
        this.name = PsInfo.bytesToString(info.pr_name);
        if (Util.isBlank(name)) {
            this.name = PsInfo.bytesToString(info.pr_oldname);
        }
        return true;
    }
}
