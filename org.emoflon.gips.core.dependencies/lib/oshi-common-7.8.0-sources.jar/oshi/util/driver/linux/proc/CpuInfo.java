/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util.driver.linux.proc;

import static oshi.util.linux.ProcPath.CPUINFO;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.util.FileUtil;
import oshi.util.ParseUtil;
import oshi.util.tuples.Quartet;

/**
 * Utility to read CPU info from {@code /proc/cpuinfo}
 */
@ThreadSafe
public final class CpuInfo {

    private static final String ARCHITECTURE_PROPERTIES = "oshi.architecture.properties";

    private CpuInfo() {
    }

    /**
     * Gets the CPU manufacturer from {@code /proc/cpuinfo}
     *
     * @return The manufacturer if known, null otherwise
     */
    public static @Nullable String queryCpuManufacturer() {
        return queryCpuManufacturer(FileUtil.readFile(CPUINFO));
    }

    /**
     * Parse the CPU manufacturer from /proc/cpuinfo lines.
     *
     * @param cpuInfo lines from /proc/cpuinfo
     * @return The manufacturer if known, null otherwise
     */
    static @Nullable String queryCpuManufacturer(List<String> cpuInfo) {
        for (String line : cpuInfo) {
            if (line.startsWith("CPU implementer")) {
                // The implementer codes are those ProcessorIdentifier translates, from the same table
                String key = String.format(Locale.ROOT, "hw_impl.0x%02x", ParseUtil.parseLastInt(line, 0));
                return FileUtil.readPropertiesFromFilename(ARCHITECTURE_PROPERTIES).getProperty(key);
            }
        }
        return null;
    }

    /**
     * Gets the board manufacturer, model, version, and serial number from {@code /proc/cpuinfo}
     *
     * @return A quartet of strings for manufacturer, model, version, and serial number. Each one may be null if
     *         unknown.
     */
    public static Quartet<@Nullable String, @Nullable String, @Nullable String, @Nullable String> queryBoardInfo() {
        return queryBoardInfo(FileUtil.readFile(CPUINFO));
    }

    /**
     * Parse board info from /proc/cpuinfo lines.
     *
     * @param cpuInfo lines from /proc/cpuinfo
     * @return A quartet of strings for manufacturer, model, version, and serial number
     */
    static Quartet<@Nullable String, @Nullable String, @Nullable String, @Nullable String> queryBoardInfo(
            List<String> cpuInfo) {
        String pcManufacturer = null;
        String pcModel = null;
        String pcVersion = null;
        String pcSerialNumber = null;

        for (String line : cpuInfo) {
            String[] splitLine = ParseUtil.whitespacesColonWhitespace.split(line, -1);
            if (splitLine.length < 2) {
                continue;
            }
            switch (splitLine[0]) {
                case "Hardware":
                    pcModel = splitLine[1];
                    break;
                case "Revision":
                    pcVersion = splitLine[1];
                    pcManufacturer = queryBoardManufacturer(pcVersion);
                    break;
                case "Serial":
                    pcSerialNumber = splitLine[1];
                    break;
                default:
                    // Do nothing
            }
        }
        return new Quartet<>(pcManufacturer, pcModel, pcVersion, pcSerialNumber);
    }

    /**
     * Decodes the manufacturer of a Raspberry Pi from its revision code. Only the new-style codes, which set bit 23,
     * carry one, in bits 16 to 19. Other ARM kernels print a revision too, usually {@code 0000}, that means nothing of
     * the kind.
     *
     * @param revision the {@code Revision} value, in hex
     * @return the manufacturer, or null if the code does not name one
     */
    private static @Nullable String queryBoardManufacturer(String revision) {
        long code = ParseUtil.hexStringToLong(revision, 0L);
        if ((code & 0x80_0000L) == 0) {
            return null;
        }
        switch ((int) (code >> 16) & 0xF) {
            case 0:
                return "Sony UK";
            case 1:
                return "Egoman";
            case 2:
            case 4:
                return "Embest";
            case 3:
                return "Sony Japan";
            case 5:
                return "Stadium";
            default:
                return null;
        }
    }

    /**
     * Queries CPU feature flags from /proc/cpuinfo.
     *
     * @return a list of feature flag strings
     */
    public static List<String> queryFeatureFlags() {
        return queryFeatureFlags(FileUtil.readFile(CPUINFO));
    }

    /**
     * Parse feature flag lines from /proc/cpuinfo.
     *
     * @param cpuInfo lines from /proc/cpuinfo
     * @return deduplicated lines starting with "flags" or "features"
     */
    static List<String> queryFeatureFlags(List<String> cpuInfo) {
        return cpuInfo.stream().filter(f -> {
            String s = f.toLowerCase(Locale.ROOT);
            return s.startsWith("flags") || s.startsWith("features");
        }).distinct().collect(Collectors.toList());
    }
}
