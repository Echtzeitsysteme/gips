/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.driver.mac.net;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.platform.mac.SystemB;
import com.sun.jna.platform.mac.SystemB.IFmsgHdr;
import com.sun.jna.platform.mac.SystemB.IFmsgHdr2;
import com.sun.jna.platform.unix.LibCAPI.size_t;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.mac.IFdata;
import oshi.jna.ByRef.CloseableSizeTByReference;

/**
 * Utility to query NetStat.
 */
@ThreadSafe
public final class NetStat {

    private static final Logger LOG = LoggerFactory.getLogger(NetStat.class);

    private static final int CTL_NET = 4;
    private static final int PF_ROUTE = 17;
    private static final int NET_RT_IFLIST2 = 6;
    private static final int RTM_IFINFO2 = 0x12;

    private NetStat() {
    }

    /**
     * Map data for network interfaces.
     *
     * @param index If positive, limit the map to only return data for this interface index. If negative, returns data
     *              for all indices.
     *
     * @return a map of {@link IFdata} object indexed by the interface index, encapsulating the stats
     */
    public static Map<Integer, IFdata> queryIFdata(int index) {
        // Ported from source code of "netstat -ir". See
        // https://opensource.apple.com/source/network_cmds/network_cmds-457/netstat.tproj/if.c
        Map<Integer, IFdata> data = new HashMap<>();
        // Get buffer of all interface information
        int[] mib = { CTL_NET, PF_ROUTE, 0, 0, NET_RT_IFLIST2, 0 };
        try (CloseableSizeTByReference len = new CloseableSizeTByReference()) {
            if (0 != SystemB.INSTANCE.sysctl(mib, 6, null, len, null, size_t.ZERO)) {
                LOG.error("Didn't get buffer length for IFLIST2");
                return data;
            }
            try (Memory buf = new Memory(len.longValue())) {
                if (0 != SystemB.INSTANCE.sysctl(mib, 6, buf, len, null, size_t.ZERO)) {
                    LOG.error("Didn't get buffer for IFLIST2");
                    return data;
                }
                final long now = System.currentTimeMillis();

                // Iterate offset from buf's pointer up to limit of buf
                int lim = (int) (buf.size() - new IFmsgHdr().size());
                int offset = 0;
                while (offset < lim) {
                    // Get pointer to current native part of buf
                    Pointer p = buf.share(offset);
                    // Cast pointer to if_msghdr
                    IFmsgHdr ifm = new IFmsgHdr(p);
                    ifm.read();
                    // Advance next
                    offset += ifm.ifm_msglen;
                    // Skip messages which are not the right format
                    if (ifm.ifm_type == RTM_IFINFO2) {
                        // Cast pointer to if_msghdr2
                        IFmsgHdr2 if2m = new IFmsgHdr2(p);
                        if2m.read();
                        if (index < 0 || index == if2m.ifm_index) {
                            data.put((int) if2m.ifm_index,
                                    new IFdata(0xff & if2m.ifm_data.ifi_type, if2m.ifm_data.ifi_opackets,
                                            if2m.ifm_data.ifi_ipackets, if2m.ifm_data.ifi_obytes,
                                            if2m.ifm_data.ifi_ibytes, if2m.ifm_data.ifi_oerrors,
                                            if2m.ifm_data.ifi_ierrors, if2m.ifm_data.ifi_collisions,
                                            if2m.ifm_data.ifi_iqdrops, if2m.ifm_data.ifi_baudrate, now));
                            if (index >= 0) {
                                return data;
                            }
                        }
                    }
                }
            }
        }
        return data;
    }
}
