/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.mac;

import java.net.NetworkInterface;
import java.util.List;
import java.util.Map;

import com.sun.jna.Pointer;
import com.sun.jna.platform.mac.CoreFoundation.CFArrayRef;
import com.sun.jna.platform.mac.CoreFoundation.CFStringRef;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.mac.IFdata;
import oshi.driver.mac.net.NetStat;
import oshi.hardware.NetworkIF;
import oshi.hardware.common.platform.mac.MacNetworkIF;
import oshi.jna.platform.mac.SystemConfiguration;
import oshi.jna.platform.mac.SystemConfiguration.SCNetworkInterfaceRef;

/**
 * MacNetworks JNA implementation.
 */
@ThreadSafe
public final class MacNetworkIfJNA extends MacNetworkIF {

    public MacNetworkIfJNA(NetworkInterface netint, Map<Integer, IFdata> data) throws InstantiationException {
        super(netint, queryIfDisplayName(netint));
        updateNetworkStats(data);
    }

    private static String queryIfDisplayName(NetworkInterface netint) {
        String name = netint.getName();
        CFArrayRef ifArray = SystemConfiguration.INSTANCE.SCNetworkInterfaceCopyAll();
        if (ifArray != null) {
            try {
                int count = ifArray.getCount();
                for (int i = 0; i < count; i++) {
                    Pointer pNetIf = ifArray.getValueAtIndex(i);
                    SCNetworkInterfaceRef scNetIf = new SCNetworkInterfaceRef(pNetIf);
                    CFStringRef cfName = SystemConfiguration.INSTANCE.SCNetworkInterfaceGetBSDName(scNetIf);
                    if (cfName != null && name.equals(cfName.stringValue())) {
                        CFStringRef cfDisplayName = SystemConfiguration.INSTANCE
                                .SCNetworkInterfaceGetLocalizedDisplayName(scNetIf);
                        if (cfDisplayName != null) {
                            return cfDisplayName.stringValue();
                        }
                    }
                }
            } finally {
                ifArray.release();
            }
        }
        return name;
    }

    /**
     * Gets all network interfaces on this machine
     *
     * @param includeLocalInterfaces include local interfaces in the result
     * @return A list of {@link NetworkIF} objects representing the interfaces
     */
    public static List<NetworkIF> getNetworks(boolean includeLocalInterfaces) {
        Map<Integer, IFdata> data = NetStat.queryIFdata(-1);
        return getNetworks(includeLocalInterfaces, ni -> new MacNetworkIfJNA(ni, data));
    }

    @Override
    protected Map<Integer, IFdata> queryIFdata(int index) {
        return NetStat.queryIFdata(index);
    }
}
