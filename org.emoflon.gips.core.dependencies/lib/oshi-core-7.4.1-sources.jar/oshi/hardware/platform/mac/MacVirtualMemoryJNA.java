/*
 * Copyright 2025-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.mac;

import static com.sun.jna.platform.mac.SystemB.HOST_VM_INFO;
import static com.sun.jna.platform.mac.SystemB.INT_SIZE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.common.platform.mac.MacVirtualMemory;
import oshi.jna.ByRef.CloseableIntByReference;
import oshi.jna.Struct.CloseableVMStatistics;
import oshi.jna.Struct.CloseableXswUsage;
import oshi.jna.platform.mac.SystemB;
import oshi.util.ParseUtil;
import oshi.util.platform.mac.SysctlUtil;
import oshi.util.tuples.Pair;

@ThreadSafe
final class MacVirtualMemoryJNA extends MacVirtualMemory {
    private static final Logger LOG = LoggerFactory.getLogger(MacVirtualMemoryJNA.class);

    MacVirtualMemoryJNA(MacGlobalMemoryJNA macGlobalMemory) {
        super(macGlobalMemory);
    }

    @Override
    protected Pair<Long, Long> querySwapUsage() {
        long swapUsed = 0L;
        long swapTotal = 0L;
        try (CloseableXswUsage xswUsage = new CloseableXswUsage()) {
            if (SysctlUtil.sysctl("vm.swapusage", xswUsage)) {
                swapUsed = xswUsage.xsu_used;
                swapTotal = xswUsage.xsu_total;
            }
        }
        return new Pair<>(swapUsed, swapTotal);
    }

    @Override
    protected Pair<Long, Long> queryVmStat() {
        long swapPagesIn = 0L;
        long swapPagesOut = 0L;
        try (CloseableVMStatistics vmStats = new CloseableVMStatistics();
                CloseableIntByReference size = new CloseableIntByReference(vmStats.size() / INT_SIZE)) {
            int ret = SystemB.INSTANCE.host_statistics(SystemB.INSTANCE.mach_host_self(), HOST_VM_INFO, vmStats, size);
            if (0 == ret) {
                swapPagesIn = ParseUtil.unsignedIntToLong(vmStats.pageins);
                swapPagesOut = ParseUtil.unsignedIntToLong(vmStats.pageouts);
            } else {
                LOG.error("Failed to get host VM info. Error code: {}", ret);
            }
        }
        return new Pair<>(swapPagesIn, swapPagesOut);
    }

}
