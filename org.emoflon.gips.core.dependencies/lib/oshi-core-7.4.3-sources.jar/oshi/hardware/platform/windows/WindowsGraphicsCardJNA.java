/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.windows;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.VersionHelpers;
import com.sun.jna.platform.win32.Win32Exception;
import com.sun.jna.platform.win32.WinError;
import com.sun.jna.platform.win32.WinReg;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.windows.gpu.DxgiAdapterInfo;
import oshi.driver.common.windows.gpu.DxgiUtil;
import oshi.driver.common.windows.perfmon.GpuInformation.GpuAdapterMemoryProperty;
import oshi.driver.common.windows.wmi.LhmSensor.LhmHardwareProperty;
import oshi.driver.common.windows.wmi.WmiResult;
import oshi.driver.common.windows.wmi.WmiUtil;
import oshi.driver.windows.perfmon.GpuInformationJNA;
import oshi.driver.windows.wmi.LhmSensorJNA;
import oshi.driver.windows.wmi.Win32VideoControllerJNA;
import oshi.hardware.GpuStats;
import oshi.hardware.GraphicsCard;
import oshi.hardware.common.platform.windows.WindowsGraphicsCard;
import oshi.util.Constants;
import oshi.util.ParseUtil;
import oshi.util.Util;
import oshi.util.gpu.DxgiUtilJNA;
import oshi.util.platform.windows.RegistryUtil;
import oshi.util.tuples.Pair;

/**
 * Graphics Card obtained from the Windows registry, with VRAM sourced from DXGI.
 *
 * <p>
 * VRAM detection priority:
 * <ol>
 * <li>{@code DXGI_ADAPTER_DESC.DedicatedVideoMemory}: the authoritative Windows API value, not subject to the 2 GiB cap
 * that affects the 32-bit registry field.</li>
 * <li>{@code HardwareInformation.qwMemorySize} (64-bit registry value): used when DXGI enumeration is unavailable or no
 * adapter match is found.</li>
 * </ol>
 *
 * <p>
 * {@code HardwareInformation.MemorySize} (32-bit) is intentionally not used: Windows writes the sentinel value
 * {@code 0x7FFFF000} (~2 GiB) into this field for GPUs with more than 2 GiB of dedicated VRAM, making it unreliable for
 * modern discrete GPUs.
 *
 * <p>
 * When DXGI is available, ghost adapters (stale registry entries from hardware no longer present) are excluded because
 * {@code IDXGIFactory::EnumAdapters} only enumerates physically present adapters. The returned list is ordered to match
 * DXGI enumeration order, which places the primary desktop adapter first.
 *
 * <p>
 * Dynamic metrics (utilization, VRAM used, shared memory, ticks) are sourced from PDH GPU Engine / GPU Adapter Memory
 * counters (Windows 10 1709+) and optionally from LibreHardwareMonitor WMI sensors when LHM is running.
 */
@ThreadSafe
final class WindowsGraphicsCardJNA extends WindowsGraphicsCard {

    private static final Logger LOG = LoggerFactory.getLogger(WindowsGraphicsCardJNA.class);

    private static final boolean IS_VISTA_OR_GREATER = VersionHelpers.IsWindowsVistaOrGreater();

    public static final String ADAPTER_STRING = "HardwareInformation.AdapterString";
    public static final String DRIVER_DESC = "DriverDesc";
    public static final String DRIVER_VERSION = "DriverVersion";
    public static final String VENDOR = "ProviderName";
    public static final String QW_MEMORY_SIZE = "HardwareInformation.qwMemorySize";
    public static final String MATCHING_DEVICE_ID = "MatchingDeviceId";
    public static final String LOCATION_INFORMATION = "LocationInformation";
    public static final String DISPLAY_DEVICES_REGISTRY_PATH = "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\";

    /**
     * Constructor for WindowsGraphicsCard
     *
     * @param name         The name
     * @param deviceId     The device ID
     * @param vendor       The vendor
     * @param versionInfo  The version info
     * @param vram         The VRAM
     * @param luidPrefix   PDH LUID instance prefix for this adapter, or empty string if unknown
     * @param lhmParent    LHM hardware identifier for this GPU, or empty string if unavailable
     * @param pciBusNumber PCI bus number for ADL correlation, or -1 if unknown
     * @param pciBusId     PCI bus ID string for NVML correlation, or empty string if unknown
     */
    WindowsGraphicsCardJNA(String name, String deviceId, String vendor, String versionInfo, long vram,
            String luidPrefix, String lhmParent, int pciBusNumber, String pciBusId) {
        super(name, deviceId, vendor, versionInfo, vram, luidPrefix, lhmParent, pciBusNumber, pciBusId);
    }

    @Override
    public GpuStats createStatsSession() {
        return new WindowsGpuStatsJNA(getLuidPrefix(), getLhmParent(), getPciBusNumber(), getPciBusId(), getName());
    }

    /**
     * public method used by {@code AbstractHardwareAbstractionLayer} to access the graphics cards.
     *
     * <p>
     * When DXGI is available, ghost adapters are excluded and the list is ordered with the primary desktop adapter
     * first. On systems without DXGI, all registry entries are returned in registry key order.
     *
     * @return List of {@link WindowsGraphicsCardJNA} objects.
     */
    public static List<GraphicsCard> getGraphicsCards() {
        // Query DXGI once. Fails gracefully to empty list if unavailable.
        List<DxgiAdapterInfo> dxgiAdapters = DxgiUtilJNA.queryAdapters();
        boolean dxgiAvailable = !dxgiAdapters.isEmpty();
        // Mutable copy for match-and-consume (prevents same adapter matching two registry entries).
        List<DxgiAdapterInfo> remainingDxgi = new ArrayList<>(dxgiAdapters);

        // Build LHM parent map: GPU name (normalized) -> LHM identifier
        Map<String, String> lhmParentMap = buildLhmParentMap();

        // When DXGI is available, collect cards keyed by their DXGI enumeration index so the
        // final list is ordered primary-adapter-first (DXGI guarantees adapter 0 is the primary
        // desktop adapter). Registry entries with no DXGI match are ghost adapters and excluded.
        // When DXGI is unavailable, fall back to simple insertion order.
        TreeMap<Integer, GraphicsCard> dxgiOrdered = new TreeMap<>();
        List<GraphicsCard> cardList = new ArrayList<>();

        int index = 1;
        String[] keys = Advapi32Util.registryGetKeys(WinReg.HKEY_LOCAL_MACHINE, DISPLAY_DEVICES_REGISTRY_PATH);
        for (String key : keys) {
            if (!key.startsWith("0")) {
                continue;
            }

            try {
                String fullKey = DISPLAY_DEVICES_REGISTRY_PATH + key;
                if (!Advapi32Util.registryValueExists(WinReg.HKEY_LOCAL_MACHINE, fullKey, ADAPTER_STRING)) {
                    continue;
                }

                String name = RegistryUtil.getStringValue(WinReg.HKEY_LOCAL_MACHINE, fullKey, DRIVER_DESC, 0);
                String deviceId = "VideoController" + index++;
                String vendor = RegistryUtil.getStringValue(WinReg.HKEY_LOCAL_MACHINE, fullKey, VENDOR, 0);
                String versionInfo = RegistryUtil.getStringValue(WinReg.HKEY_LOCAL_MACHINE, fullKey, DRIVER_VERSION, 0);

                // Parse PCI vendor/device IDs from MatchingDeviceId (e.g. "pci\ven_8086&dev_56a0&...")
                String matchingDeviceId = RegistryUtil.getStringValue(WinReg.HKEY_LOCAL_MACHINE, fullKey,
                        MATCHING_DEVICE_ID, 0);
                Pair<Integer, Integer> pciIds = ParseUtil.parseDeviceIdToVendorProductIds(matchingDeviceId);
                int pciVendorId = pciIds == null ? 0 : pciIds.getA();
                int pciDeviceId = pciIds == null ? 0 : pciIds.getB();

                // Primary: DXGI DedicatedVideoMemory.
                // Track whether a DXGI match was found separately from the vram value, so that a
                // legitimate DedicatedVideoMemory == 0 (e.g. a software/render-only adapter) is
                // preserved and does not trigger the registry fallback.
                long vram = -1L;
                int dxgiIndex = -1;
                String luidPrefix = "";
                int pciBusNumber = -1;
                String pciBusId = "";
                String locationInfo = RegistryUtil.getStringValue(WinReg.HKEY_LOCAL_MACHINE, fullKey,
                        LOCATION_INFORMATION, 0);
                DxgiAdapterInfo dxgiMatch = DxgiUtilJNA.findMatch(remainingDxgi, pciVendorId, pciDeviceId, name);
                if (dxgiMatch != null) {
                    vram = dxgiMatch.getDedicatedVideoMemory();
                    dxgiIndex = dxgiAdapters.indexOf(dxgiMatch);
                    luidPrefix = buildLuidPrefix(dxgiMatch);
                    pciBusNumber = parsePciBusNumber(locationInfo);
                    pciBusId = buildPciBusId(locationInfo);
                } else if (dxgiAvailable) {
                    // DXGI is available but this registry entry has no matching adapter:
                    // it is a ghost device (stale driver from hardware no longer present). Skip it.
                    continue;
                }

                // Fallback: 64-bit registry value qwMemorySize, only when DXGI had no match.
                if (vram < 0 && Advapi32Util.registryValueExists(WinReg.HKEY_LOCAL_MACHINE, fullKey, QW_MEMORY_SIZE)) {
                    Object regValue = Advapi32Util.registryGetValue(WinReg.HKEY_LOCAL_MACHINE, fullKey, QW_MEMORY_SIZE);
                    vram = registryValueToVram(regValue);
                }

                // Normalise sentinel: if still unresolved report 0.
                if (vram < 0) {
                    vram = 0L;
                }

                // HardwareInformation.MemorySize (32-bit) is intentionally omitted: Windows caps
                // it at 0x7FFFF000 (~2 GiB) for GPUs with more VRAM, making it unreliable.

                String lhmParent = lhmParentMap.getOrDefault(DxgiUtilJNA.normalizeName(Util.isBlank(name) ? "" : name),
                        "");

                GraphicsCard card = new WindowsGraphicsCardJNA(Util.isBlank(name) ? Constants.UNKNOWN : name,
                        Util.isBlank(deviceId) ? Constants.UNKNOWN : deviceId,
                        Util.isBlank(vendor) ? Constants.UNKNOWN : vendor,
                        Util.isBlank(versionInfo) ? Constants.UNKNOWN : versionInfo, vram, luidPrefix, lhmParent,
                        pciBusNumber, pciBusId);
                // Remove dxgiMatch from remainingDxgi only after the card is successfully
                // constructed. This ensures that if earlier registry reads in this try block
                // throw a Win32Exception, dxgiMatch remains in remainingDxgi and is still
                // available for subsequent iterations or WMI fallback processing.
                if (dxgiMatch != null) {
                    remainingDxgi.remove(dxgiMatch);
                }
                if (dxgiIndex >= 0) {
                    dxgiOrdered.put(dxgiIndex, card);
                } else {
                    cardList.add(card);
                }
            } catch (Win32Exception e) {
                if (e.getErrorCode() != WinError.ERROR_ACCESS_DENIED) {
                    // Ignore access denied errors, re-throw others
                    throw e;
                }
            }
        }

        // Merge: DXGI-ordered cards first (primary adapter at index 0), then any non-DXGI cards.
        List<GraphicsCard> result = new ArrayList<>(dxgiOrdered.values());
        result.addAll(cardList);

        if (result.isEmpty()) {
            return getGraphicsCardsFromWmi(remainingDxgi, lhmParentMap);
        }
        return result;
    }

    /**
     * Converts a registry value (REG_QWORD as Long, REG_DWORD as Integer, or REG_BINARY as byte[]) to a VRAM size in
     * bytes. REG_BINARY is interpreted as little-endian.
     *
     * @param value the registry value object
     * @return the VRAM size in bytes, or 0 if the value type is unrecognised
     */
    static long registryValueToVram(Object value) {
        return DxgiUtil.registryValueToVram(value);
    }

    // fall back if something went wrong
    private static List<GraphicsCard> getGraphicsCardsFromWmi(List<DxgiAdapterInfo> dxgiAdapters,
            Map<String, String> lhmParentMap) {
        if (!IS_VISTA_OR_GREATER) {
            return Collections.emptyList();
        }
        return buildFromWmi(dxgiAdapters, lhmParentMap, Win32VideoControllerJNA.queryVideoController(),
                WindowsGraphicsCardJNA::buildLuidPrefix, WindowsGraphicsCardJNA::new);
    }

    /**
     * Queries LHM WMI for GPU hardware entries and returns a map from normalized GPU name to LHM parent identifier.
     * Returns an empty map if LHM is not running. If two GPU entries normalize to the same name the key is mapped to an
     * empty string so callers skip LHM for that ambiguous name rather than returning the wrong adapter's metrics.
     *
     * @return map of normalized GPU name to LHM hardware identifier
     */
    private static Map<String, String> buildLhmParentMap() {
        Map<String, String> map = new HashMap<>();
        try {
            WmiResult<LhmHardwareProperty> hw = LhmSensorJNA.queryGpuHardware();
            for (int i = 0; i < hw.getResultCount(); i++) {
                String identifier = WmiUtil.getString(hw, LhmHardwareProperty.IDENTIFIER, i);
                String hwName = WmiUtil.getString(hw, LhmHardwareProperty.NAME, i);
                if (!identifier.isEmpty() && !hwName.isEmpty()) {
                    String norm = DxgiUtilJNA.normalizeName(hwName);
                    if (map.containsKey(norm)) {
                        // Two adapters with the same normalized name: mark ambiguous so neither
                        // is used (empty string is the "skip LHM" sentinel for callers).
                        map.put(norm, "");
                    } else {
                        map.put(norm, identifier);
                    }
                }
            }
        } catch (Exception e) {
            LOG.debug("LHM GPU hardware query failed (LHM may not be running): {}", e.getMessage());
        }
        return map;
    }

    /**
     * Parses the PCI bus number from a Windows registry {@code LocationInformation} string of the form
     * {@code "PCI bus N, device N, function N"}.
     *
     * @param locationInfo the LocationInformation registry value
     * @return PCI bus number, or -1 if not parseable
     */
    static int parsePciBusNumber(String locationInfo) {
        return DxgiUtil.parsePciBusNumber(locationInfo);
    }

    /**
     * Parses the PCI device number from a Windows registry {@code LocationInformation} string.
     *
     * @param locationInfo the LocationInformation registry value
     * @return PCI device number, or -1 if not parseable
     */
    static int parsePciDevice(String locationInfo) {
        return DxgiUtil.parsePciDevice(locationInfo);
    }

    /**
     * Parses the PCI function number from a Windows registry {@code LocationInformation} string.
     *
     * @param locationInfo the LocationInformation registry value
     * @return PCI function number, or -1 if not parseable
     */
    static int parsePciFunction(String locationInfo) {
        return DxgiUtil.parsePciFunction(locationInfo);
    }

    /**
     * Builds a PCI bus ID string in {@code "0000:BB:DD.F"} format from a Windows registry {@code LocationInformation}
     * string. Returns an empty string if any component cannot be parsed.
     *
     * @param locationInfo the LocationInformation registry value
     * @return PCI bus ID string, or empty string if not parseable
     */
    static String buildPciBusId(String locationInfo) {
        return DxgiUtil.buildPciBusId(locationInfo);
    }

    /**
     * Builds the PDH LUID instance prefix for the given DXGI adapter. The prefix has the form
     * {@code luid_0xHHHHHHHH_0xLLLLLLLL_phys_0} matching the Windows PDH GPU Engine and GPU Adapter Memory counter
     * instance names.
     *
     * <p>
     * The LUID is read directly from {@code DXGI_ADAPTER_DESC.AdapterLuid}, so this method works correctly on multi-GPU
     * systems. A zero LUID (both parts zero) indicates the adapter did not supply a valid LUID; in that case an empty
     * string is returned and PDH metrics will report {@code -1}.
     *
     * @param adapter the DXGI adapter info containing the LUID
     * @return PDH LUID instance prefix string, or empty string if the LUID is zero
     */
    private static String buildLuidPrefix(DxgiAdapterInfo adapter) {
        String prefix = DxgiUtil.buildLuidPrefix(adapter);
        if (!prefix.isEmpty()) {
            return prefix;
        }
        // Zero LUID is invalid; fall back to PDH enumeration for single-GPU case.
        return buildLuidPrefixFromPdh();
    }

    /**
     * Fallback LUID prefix discovery by enumerating PDH GPU Adapter Memory instances. Used when the DXGI adapter
     * reports a zero LUID.
     *
     * <p>
     * Only reliable on single-GPU systems: when multiple GPU Adapter Memory instances are present, the correct
     * per-adapter mapping cannot be determined without a valid LUID, so an empty string is returned and PDH metrics
     * will report {@code -1}.
     *
     * @return PDH LUID instance prefix string, or empty string if not determinable
     */
    private static String buildLuidPrefixFromPdh() {
        Pair<List<String>, Map<GpuAdapterMemoryProperty, List<Long>>> adapterData = GpuInformationJNA
                .queryGpuAdapterMemoryCounters();
        List<String> instances = adapterData.getA();
        if (instances.isEmpty()) {
            return "";
        }
        // GPU Adapter Memory instance names have the form: luid_0xHHHH_0xLLLL_phys_0
        // There is one instance per physical adapter. We return the full instance name as the prefix.
        // If there is only one adapter, use it directly.
        if (instances.size() == 1) {
            return instances.get(0);
        }
        // Multiple adapters: we cannot reliably match by name here since GPU Adapter Memory
        // instances do not carry a name. Return empty; callers will get -1 for PDH metrics.
        // A future improvement could correlate via DXGI LUID enumeration.
        LOG.debug("Multiple GPU Adapter Memory instances found ({}); LUID matching not yet implemented for multi-GPU",
                instances.size());
        return "";
    }

}
