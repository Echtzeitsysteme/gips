/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.os.mac;

import static com.sun.jna.platform.mac.SystemB.PROC_PIDPATHINFO_MAXSIZE;
import static com.sun.jna.platform.mac.SystemB.PROC_PIDTASKALLINFO;
import static com.sun.jna.platform.mac.SystemB.PROC_PIDVNODEPATHINFO;
import static com.sun.jna.platform.mac.SystemB.RUSAGE_INFO_V2;
import static oshi.jna.platform.unix.CLibrary.RUSAGE_SELF;
import static oshi.software.os.OSProcess.State.INVALID;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.platform.mac.IOKit.IOIterator;
import com.sun.jna.platform.mac.IOKit.IORegistryEntry;
import com.sun.jna.platform.mac.IOKitUtil;
import com.sun.jna.platform.mac.SystemB.Group;
import com.sun.jna.platform.mac.SystemB.Passwd;
import com.sun.jna.platform.unix.LibCAPI.size_t;
import com.sun.jna.platform.unix.Resource;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.jna.Struct.CloseableProcTaskAllInfo;
import oshi.jna.Struct.CloseableRUsageInfoV2;
import oshi.jna.Struct.CloseableVnodePathInfo;
import oshi.jna.platform.mac.SystemB;
import oshi.software.common.os.mac.MacOSProcess;
import oshi.software.common.os.mac.MacOperatingSystem;
import oshi.util.ParseUtil;
import oshi.util.platform.mac.SysctlUtil;
import oshi.util.tuples.Pair;

/**
 * JNA-backed macOS OSProcess.
 */
@ThreadSafe
public class MacOSProcessJNA extends MacOSProcess {

    private static final Logger LOG = LoggerFactory.getLogger(MacOSProcessJNA.class);

    private static final int ARGMAX = SysctlUtil.sysctl("kern.argmax", 0);
    private static final long TICKS_PER_MS;
    static {
        // default to 1 tick per nanosecond
        long ticksPerSec = 1_000_000_000L;
        IOIterator iter = IOKitUtil.getMatchingServices("IOPlatformDevice");
        if (iter != null) {
            IORegistryEntry cpu = iter.next();
            while (cpu != null) {
                try {
                    String s = cpu.getName().toLowerCase(Locale.ROOT);
                    if (s.startsWith("cpu") && s.length() > 3) {
                        byte[] data = cpu.getByteArrayProperty("timebase-frequency");
                        if (data != null) {
                            ticksPerSec = ParseUtil.byteArrayToLong(data, 4, false);
                            break;
                        }
                    }
                } finally {
                    cpu.release();
                }
                cpu = iter.next();
            }
            iter.release();
        }
        // Convert to ticks per millisecond
        TICKS_PER_MS = ticksPerSec / 1000L;
    }

    public MacOSProcessJNA(int pid, int major, int minor, MacOperatingSystem os) {
        super(pid, major, minor, os);
        updateAttributes();
    }

    @Override
    protected Pair<List<String>, Map<String, String>> queryArgsAndEnvironment() {
        int pid = getProcessID();
        // Get command line via sysctl
        int[] mib = new int[3];
        mib[0] = 1; // CTL_KERN
        mib[1] = 49; // KERN_PROCARGS2
        mib[2] = pid;
        // Allocate memory for arguments
        try (Memory procargs = new Memory(ARGMAX)) {
            procargs.clear();
            size_t.ByReference size = new size_t.ByReference(ARGMAX);
            // Fetch arguments
            if (0 == SystemB.INSTANCE.sysctl(mib, mib.length, procargs, size, null, size_t.ZERO)) {
                int len = (int) size.longValue();
                return parseProcArgs(procargs.getByteArray(0, len), len);
            }
            // Don't warn for pid 0
            if (pid > 0 && LOG_MAC_SYSCTL_WARNING) {
                LOG.warn(
                        "Failed sysctl call for process arguments (kern.procargs2), process {} may not exist. Error code: {}",
                        pid, Native.getLastError());
            }
        }
        return new Pair<>(Collections.emptyList(), Collections.emptyMap());
    }

    @Override
    protected int queryLogicalProcessorCount() {
        return SysctlUtil.sysctl("hw.logicalcpu", 1);
    }

    @Override
    public long getSoftOpenFileLimit() {
        if (getProcessID() == this.os.getProcessId()) {
            final Resource.Rlimit rlimit = new Resource.Rlimit();
            SystemB.INSTANCE.getrlimit(MAC_RLIMIT_NOFILE, rlimit);
            return rlimit.rlim_cur;
        } else {
            return -1L; // not supported
        }
    }

    @Override
    public long getHardOpenFileLimit() {
        if (getProcessID() == this.os.getProcessId()) {
            final Resource.Rlimit rlimit = new Resource.Rlimit();
            SystemB.INSTANCE.getrlimit(MAC_RLIMIT_NOFILE, rlimit);
            return rlimit.rlim_max;
        } else {
            return -1L; // not supported
        }
    }

    @Override
    public synchronized boolean updateAttributes() {
        long now = System.currentTimeMillis();
        try (CloseableProcTaskAllInfo taskAllInfo = new CloseableProcTaskAllInfo()) {
            if (0 > SystemB.INSTANCE.proc_pidinfo(getProcessID(), PROC_PIDTASKALLINFO, 0, taskAllInfo,
                    taskAllInfo.size()) || taskAllInfo.ptinfo.pti_threadnum < 1) {
                this.state = INVALID;
                return false;
            }
            try (Memory buf = new Memory(PROC_PIDPATHINFO_MAXSIZE)) {
                if (0 < SystemB.INSTANCE.proc_pidpath(getProcessID(), buf, PROC_PIDPATHINFO_MAXSIZE)) {
                    this.path = buf.getString(0).trim();
                    // Overwrite name with last part of path
                    String[] pathSplit = this.path.split("/", -1);
                    if (pathSplit.length > 0) {
                        this.name = pathSplit[pathSplit.length - 1];
                    }
                }
            }
            if (this.name.isEmpty()) {
                // pbi_comm contains first 16 characters of name
                this.name = Native.toString(taskAllInfo.pbsd.pbi_comm, StandardCharsets.UTF_8);
            }

            this.state = stateFromStatus(taskAllInfo.pbsd.pbi_status);
            this.parentProcessID = taskAllInfo.pbsd.pbi_ppid;
            this.userID = Integer.toString(taskAllInfo.pbsd.pbi_uid);
            Passwd pwuid = SystemB.INSTANCE.getpwuid(taskAllInfo.pbsd.pbi_uid);
            this.user = pwuid == null ? Integer.toString(taskAllInfo.pbsd.pbi_uid) : pwuid.pw_name;
            this.groupID = Integer.toString(taskAllInfo.pbsd.pbi_gid);
            Group grgid = SystemB.INSTANCE.getgrgid(taskAllInfo.pbsd.pbi_gid);
            this.group = grgid == null ? Integer.toString(taskAllInfo.pbsd.pbi_gid) : grgid.gr_name;
            this.threadCount = taskAllInfo.ptinfo.pti_threadnum;
            this.priority = taskAllInfo.ptinfo.pti_priority;
            this.virtualSize = taskAllInfo.ptinfo.pti_virtual_size;
            this.residentSetSize = taskAllInfo.ptinfo.pti_resident_size;
            // Default/fallback: RSS. Will be overwritten by phys_footprint when available.
            this.memoryFootprint = this.residentSetSize;
            this.kernelTime = taskAllInfo.ptinfo.pti_total_system / TICKS_PER_MS;
            this.userTime = taskAllInfo.ptinfo.pti_total_user / TICKS_PER_MS;
            this.startTime = taskAllInfo.pbsd.pbi_start_tvsec * 1000L + taskAllInfo.pbsd.pbi_start_tvusec / 1000L;
            this.upTime = now - this.startTime;
            this.openFiles = taskAllInfo.pbsd.pbi_nfiles;
            this.bitness = (taskAllInfo.pbsd.pbi_flags & P_LP64) == 0 ? 32 : 64;
            this.majorFaults = taskAllInfo.ptinfo.pti_pageins;
            // testing using getrusage confirms pti_faults includes both major and minor
            this.minorFaults = taskAllInfo.ptinfo.pti_faults - this.majorFaults; // NOSONAR java:S2184
            // getrusage(RUSAGE_SELF) aggregates across all threads for current process
            if (getProcessID() == this.os.getProcessId()) {
                SystemB.Rusage rusage = new SystemB.Rusage();
                if (0 == SystemB.INSTANCE.getrusage(RUSAGE_SELF, rusage)) {
                    this.voluntaryContextSwitches = rusage.ru_nvcsw.longValue();
                    this.involuntaryContextSwitches = rusage.ru_nivcsw.longValue();
                    this.contextSwitches = this.voluntaryContextSwitches + this.involuntaryContextSwitches;
                } else {
                    // getrusage failed; fall back to pti_csw (combined only)
                    this.contextSwitches = taskAllInfo.ptinfo.pti_csw;
                    this.voluntaryContextSwitches = 0L;
                    this.involuntaryContextSwitches = 0L;
                }
            } else {
                // For other processes, only combined total is available via pti_csw
                this.contextSwitches = taskAllInfo.ptinfo.pti_csw;
            }
        }
        if (this.majorVersion > 10 || (this.majorVersion == 10 && this.minorVersion >= 9)) {
            try (CloseableRUsageInfoV2 rUsageInfoV2 = new CloseableRUsageInfoV2()) {
                if (0 == SystemB.INSTANCE.proc_pid_rusage(getProcessID(), RUSAGE_INFO_V2, rUsageInfoV2)) {
                    this.bytesRead = rUsageInfoV2.ri_diskio_bytesread;
                    this.bytesWritten = rUsageInfoV2.ri_diskio_byteswritten;
                    this.memoryFootprint = rUsageInfoV2.ri_phys_footprint;
                }
            }
        }
        try (CloseableVnodePathInfo vpi = new CloseableVnodePathInfo()) {
            if (0 < SystemB.INSTANCE.proc_pidinfo(getProcessID(), PROC_PIDVNODEPATHINFO, 0, vpi, vpi.size())) {
                this.currentWorkingDirectory = Native.toString(vpi.pvi_cdir.vip_path, StandardCharsets.UTF_8);
            }
        }
        return true;
    }
}
