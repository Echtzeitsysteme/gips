/*
 * Copyright 2019-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util.platform.windows;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.platform.win32.PdhUtil;
import com.sun.jna.platform.win32.PdhUtil.PdhEnumObjectItems;
import com.sun.jna.platform.win32.PdhUtil.PdhException;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.windows.perfmon.PdhCounterWildcardProperty;
import oshi.driver.common.windows.perfmon.PerfCounter;
import oshi.driver.common.windows.wmi.WmiConstants;
import oshi.driver.common.windows.wmi.WmiQuery;
import oshi.driver.common.windows.wmi.WmiResult;
import oshi.driver.common.windows.wmi.WmiUtil;
import oshi.util.GlobalConfig;
import oshi.util.Util;
import oshi.util.tuples.Pair;

/**
 * Enables queries of Performance Counters using wild cards to filter instances
 */
@ThreadSafe
public final class PerfCounterWildcardQuery {

    private static final Logger LOG = LoggerFactory.getLogger(PerfCounterWildcardQuery.class);

    private static final boolean PERF_DISABLE_ALL_ON_FAILURE = GlobalConfig
            .get(GlobalConfig.OSHI_OS_WINDOWS_PERF_DISABLE_ALL_ON_FAILURE, false);

    // Use a thread safe set to cache failed pdh queries
    private static final Set<String> FAILED_QUERY_CACHE = ConcurrentHashMap.newKeySet();

    private PerfCounterWildcardQuery() {
    }

    /**
     * Query a Performance Counter using PDH, with WMI backup on failure, for values corresponding to the property enum.
     *
     * @param <T>          The enum type of {@code propertyEnum}
     * @param propertyEnum An enum which implements {@link PdhCounterWildcardProperty} and contains the WMI field (Enum
     *                     value) and PDH Counter string (instance and counter)
     * @param perfObject   The PDH object for this counter; all counters on this object will be refreshed at the same
     *                     time
     * @param perfWmiClass The WMI PerfData_RawData_* class corresponding to the PDH object
     * @return A pair containing a list of instances and an {@link EnumMap} of the corresponding values indexed by
     *         {@code propertyEnum} on success, or an empty list and empty map if both PDH and WMI queries failed.
     */
    public static <T extends Enum<T>> Pair<List<String>, Map<T, List<Long>>> queryInstancesAndValues(
            Class<T> propertyEnum, String perfObject, String perfWmiClass) {
        return queryInstancesAndValues(propertyEnum, perfObject, perfWmiClass, null);
    }

    /**
     * Query a Performance Counter using PDH, with WMI backup on failure, for values corresponding to the property enum.
     *
     * @param <T>          The enum type of {@code propertyEnum}
     * @param propertyEnum An enum which implements {@link PdhCounterWildcardProperty} and contains the WMI field (Enum
     *                     value) and PDH Counter string (instance and counter)
     * @param perfObject   The PDH object for this counter; all counters on this object will be refreshed at the same
     *                     time
     * @param perfWmiClass The WMI PerfData_RawData_* class corresponding to the PDH object
     * @param customFilter a custom instance filter to use. If null, uses the first element of the property enum
     * @return A pair containing a list of instances and an {@link EnumMap} of the corresponding values indexed by
     *         {@code propertyEnum} on success, or an empty list and empty map if both PDH and WMI queries failed.
     */
    public static <T extends Enum<T>> Pair<List<String>, Map<T, List<Long>>> queryInstancesAndValues(
            Class<T> propertyEnum, String perfObject, String perfWmiClass, @Nullable String customFilter) {
        if (FAILED_QUERY_CACHE.isEmpty()
                || (!PERF_DISABLE_ALL_ON_FAILURE && !FAILED_QUERY_CACHE.contains(perfObject))) {
            Pair<List<String>, Map<T, List<Long>>> instancesAndValuesMap = queryInstancesAndValuesFromPDH(propertyEnum,
                    perfObject, customFilter);
            if (!instancesAndValuesMap.getA().isEmpty()) {
                return instancesAndValuesMap;
            }
            // If we are here, query returned no results
            if (Util.isBlank(customFilter)) {
                if (PERF_DISABLE_ALL_ON_FAILURE) {
                    LOG.info("Disabling further attempts to query performance counters.");
                } else {
                    LOG.info("Disabling further attempts to query {}.", perfObject);
                }
                FAILED_QUERY_CACHE.add(perfObject);
            }
        }
        return queryInstancesAndValuesFromWMI(propertyEnum, perfWmiClass);
    }

    /**
     * Query a Performance Counter using PDH for values corresponding to the property enum.
     *
     * @param <T>          The enum type of {@code propertyEnum}
     * @param propertyEnum An enum which implements {@link PdhCounterWildcardProperty} and contains the WMI field (Enum
     *                     value) and PDH Counter string (instance and counter)
     * @param perfObject   The PDH object for this counter; all counters on this object will be refreshed at the same
     *                     time
     * @return An pair containing a list of instances and an {@link EnumMap} of the corresponding values indexed by
     *         {@code propertyEnum} on success, or an empty list and empty map if the PDH query failed.
     */
    public static <T extends Enum<T>> Pair<List<String>, Map<T, List<Long>>> queryInstancesAndValuesFromPDH(
            Class<T> propertyEnum, String perfObject) {
        return queryInstancesAndValuesFromPDH(propertyEnum, perfObject, null);
    }

    /**
     * Query a Performance Counter using PDH for values corresponding to the property enum.
     *
     * @param <T>          The enum type of {@code propertyEnum}
     * @param propertyEnum An enum which implements {@link PdhCounterWildcardProperty} and contains the WMI field (Enum
     *                     value) and PDH Counter string (instance and counter)
     * @param perfObject   The PDH object for this counter; all counters on this object will be refreshed at the same
     *                     time
     * @param customFilter a custom instance filter to use. If null, uses the first element of the property enum
     * @return An pair containing a list of instances and an {@link EnumMap} of the corresponding values indexed by
     *         {@code propertyEnum} on success, or an empty list and empty map if the PDH query failed.
     */
    public static <T extends Enum<T>> Pair<List<String>, Map<T, List<Long>>> queryInstancesAndValuesFromPDH(
            Class<T> propertyEnum, String perfObject, @Nullable String customFilter) {
        T[] props = propertyEnum.getEnumConstants();
        if (props.length < 2) {
            throw new IllegalArgumentException("Enum " + propertyEnum.getName()
                    + " must have at least two elements, an instance filter and a counter.");
        }
        // Lowercase the filter (matching the built-in default below) since instance names are compared
        // case-insensitively via toLowerCase at the wildcardMatch call.
        String defaultFilter = ((PdhCounterWildcardProperty) propertyEnum.getEnumConstants()[0]).getCounter();
        String instanceFilter = (customFilter == null || customFilter.isEmpty() ? defaultFilter : customFilter)
                .toLowerCase(Locale.ROOT);
        // Localize the perfObject using different variable for the EnumObjectItems
        // Will still use unlocalized perfObject for the query
        String perfObjectLocalized = PerfCounterQuery.localizeIfNeeded(perfObject, true);

        // Get list of instances
        PdhEnumObjectItems objectItems = null;
        try {
            objectItems = PdhUtil.PdhEnumObjectItems(null, null, perfObjectLocalized, 100);
        } catch (PdhException e) {
            LOG.warn("Failed to locate performance object for {} in the registry. Performance counters may be corrupt.",
                    perfObjectLocalized, e);
        }
        if (objectItems == null) {
            return new Pair<>(Collections.emptyList(), Collections.emptyMap());
        }
        List<String> instances = objectItems.getInstances();
        // Filter out instances not matching filter
        instances.removeIf(i -> !Util.wildcardMatch(i.toLowerCase(Locale.ROOT), instanceFilter));
        EnumMap<T, List<Long>> valuesMap = new EnumMap<>(propertyEnum);
        try (PerfCounterQueryHandler pdhQueryHandler = new PerfCounterQueryHandler()) {
            // Set up the query and counter handles
            EnumMap<T, List<PerfCounter>> counterListMap = new EnumMap<>(propertyEnum);
            // Start at 1, first counter defines instance filter
            for (int i = 1; i < props.length; i++) {
                T prop = props[i];
                List<PerfCounter> counterList = new ArrayList<>(instances.size());
                for (String instance : instances) {
                    PerfCounter counter = new PerfCounter(perfObject, instance,
                            ((PdhCounterWildcardProperty) prop).getCounter());
                    if (!pdhQueryHandler.addCounterToQuery(counter)) {
                        return new Pair<>(Collections.emptyList(), Collections.emptyMap());
                    }
                    counterList.add(counter);
                }
                counterListMap.put(prop, counterList);
            }
            // And then query. Zero timestamp means update failed
            if (0 < pdhQueryHandler.updateQuery()) {
                // Start at 1, first counter defines instance filter
                for (int i = 1; i < props.length; i++) {
                    T prop = props[i];
                    List<Long> values = new ArrayList<>();
                    for (PerfCounter counter : counterListMap.getOrDefault(prop, Collections.emptyList())) {
                        values.add(pdhQueryHandler.queryCounter(counter));
                    }
                    valuesMap.put(prop, values);
                }
            } else {
                // The PDH data collection failed. Return an empty pair (per this method's contract) so the caller
                // falls back to WMI, rather than a populated instance list paired with an empty value map, which
                // would NPE downstream consumers that index the value map by the returned instances.
                return new Pair<>(Collections.emptyList(), Collections.emptyMap());
            }
        }
        return new Pair<>(instances, valuesMap);
    }

    /**
     * Query a Performance Counter using WMI for values corresponding to the property enum.
     *
     * @param <T>          The enum type of {@code propertyEnum}
     * @param propertyEnum An enum which implements {@link PdhCounterWildcardProperty} and contains the WMI field (Enum
     *                     value) and PDH Counter string (instance and counter)
     * @param wmiClass     The WMI PerfData_RawData_* class corresponding to the PDH object
     * @return An pair containing a list of instances and an {@link EnumMap} of the corresponding values indexed by
     *         {@code propertyEnum} on success, or an empty list and empty map if the WMI query failed.
     */
    public static <T extends Enum<T>> Pair<List<String>, Map<T, List<Long>>> queryInstancesAndValuesFromWMI(
            Class<T> propertyEnum, String wmiClass) {
        WmiQuery<T> query = new WmiQuery<>(wmiClass, propertyEnum);
        WmiResult<T> result = Objects.requireNonNull(WmiQueryHandler.createInstance()).queryWMI(query);
        return mapInstancesAndValuesFromResult(propertyEnum, result);
    }

    /**
     * Maps a WMI result to its instance names and per-instance values, converting each property according to its CIM
     * type. The first property of the enum names the instance; the rest are values.
     * <p>
     * Split from the query so it can be tested against a stubbed result: real WMI data exercises whichever CIM type the
     * queried class happens to use, leaving the other conversions unreached.
     *
     * @param <T>          The enum type of {@code propertyEnum}
     * @param propertyEnum the property enum
     * @param result       the query result
     * @return the instance names and the values indexed by {@code propertyEnum}, both empty if the result had no rows
     *         <p>
     *         Note that {@code WmiUtil} here is {@link oshi.driver.common.windows.wmi.WmiUtil}, imported so it shadows
     *         the same-named class in this package. That one takes JNA's result type; this takes the backend-neutral
     *         interface, which is what makes this testable.
     *
     * @throws ClassCastException if a property has a CIM type this does not convert
     */
    // ordinal() == 0 is intentional: PdhCounterWildcardProperty's contract requires the first declared
    // enum constant to be the instance filter (see PdhCounterWildcardProperty javadoc).
    @SuppressWarnings("EnumOrdinal")
    static <T extends Enum<T>> Pair<List<String>, Map<T, List<Long>>> mapInstancesAndValuesFromResult(
            Class<T> propertyEnum, WmiResult<T> result) {
        List<String> instances = new ArrayList<>();
        EnumMap<T, List<Long>> valuesMap = new EnumMap<>(propertyEnum);
        if (result.getResultCount() > 0) {
            for (T prop : propertyEnum.getEnumConstants()) {
                // First element is instance name
                if (prop.ordinal() == 0) {
                    for (int i = 0; i < result.getResultCount(); i++) {
                        instances.add(WmiUtil.getString(result, prop, i));
                    }
                } else {
                    List<Long> values = new ArrayList<>();
                    for (int i = 0; i < result.getResultCount(); i++) {
                        switch (result.getCIMType(prop)) {
                            case WmiConstants.CIM_UINT16:
                                values.add((long) WmiUtil.getUint16(result, prop, i));
                                break;
                            case WmiConstants.CIM_UINT32:
                                values.add(WmiUtil.getUint32asLong(result, prop, i));
                                break;
                            case WmiConstants.CIM_UINT64:
                                values.add(WmiUtil.getUint64(result, prop, i));
                                break;
                            case WmiConstants.CIM_DATETIME:
                                values.add(WmiUtil.getDateTime(result, prop, i).toInstant().toEpochMilli());
                                break;
                            default:
                                throw new ClassCastException("Unimplemented CIM Type Mapping.");
                        }
                    }
                    valuesMap.put(prop, values);
                }
            }
        }
        return new Pair<>(instances, valuesMap);
    }

}
