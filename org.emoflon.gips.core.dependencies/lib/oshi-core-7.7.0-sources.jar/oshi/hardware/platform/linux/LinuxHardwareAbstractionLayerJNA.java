/*
 * Copyright 2025-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.linux;

import java.util.List;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.hardware.GraphicsCard;
import oshi.hardware.HWDiskStore;
import oshi.hardware.LogicalVolumeGroup;
import oshi.hardware.NetworkIF;
import oshi.hardware.PowerSource;
import oshi.hardware.Printer;
import oshi.hardware.UsbDevice;
import oshi.hardware.common.platform.linux.LinuxGlobalMemory;
import oshi.hardware.common.platform.linux.LinuxHardwareAbstractionLayer;
import oshi.hardware.common.platform.linux.LinuxUsbDevice;
import oshi.hardware.platform.unix.CupsPrinterJNA;
import oshi.software.os.linux.LinuxOperatingSystemJNA;

/**
 * JNA-based Linux hardware abstraction layer. Extends {@link LinuxHardwareAbstractionLayer}, overriding methods as FFM
 * equivalents are migrated to {@code LinuxHardwareAbstractionLayerFFM}.
 */
@ThreadSafe
public final class LinuxHardwareAbstractionLayerJNA extends LinuxHardwareAbstractionLayer {

    @Override
    public GlobalMemory createMemory() {
        return new LinuxGlobalMemory(LinuxOperatingSystemJNA.pageSize());
    }

    @Override
    public CentralProcessor createProcessor() {
        return new LinuxCentralProcessorJNA();
    }

    @Override
    public List<LogicalVolumeGroup> getLogicalVolumeGroups() {
        return LinuxLogicalVolumeGroupJNA.getLogicalVolumeGroups();
    }

    @Override
    public List<NetworkIF> getNetworkIFs(boolean includeLocalInterfaces) {
        return LinuxNetworkIFJNA.getNetworks(includeLocalInterfaces);
    }

    @Override
    public List<HWDiskStore> getDiskStores() {
        return LinuxHWDiskStoreJNA.getDisks();
    }

    @Override
    protected List<UsbDevice> createUsbDevices() {
        return LinuxUsbDevice.getUsbDevices(LinuxUsbDeviceJNA.queryUsbDevices());
    }

    @Override
    protected List<GraphicsCard> createGraphicsCards() {
        return LinuxGraphicsCardJNA.getGraphicsCards();
    }

    @Override
    public List<Printer> getPrinters() {
        return CupsPrinterJNA.getPrinters();
    }

    @Override
    public List<PowerSource> getPowerSources() {
        return LinuxPowerSourceJNA.getPowerSources();
    }
}
