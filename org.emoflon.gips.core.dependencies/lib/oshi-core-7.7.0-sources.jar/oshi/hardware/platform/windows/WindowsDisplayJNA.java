/*
 * Copyright 2016-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.windows;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.platform.win32.Advapi32;
import com.sun.jna.platform.win32.Guid;
import com.sun.jna.platform.win32.SetupApi;
import com.sun.jna.platform.win32.WinBase;
import com.sun.jna.platform.win32.WinError;
import com.sun.jna.platform.win32.WinNT;
import com.sun.jna.platform.win32.WinNT.HANDLE;
import com.sun.jna.platform.win32.WinReg.HKEY;

import oshi.annotation.concurrent.Immutable;
import oshi.driver.common.windows.DisplayConnector;
import oshi.driver.common.windows.DisplayConnector.Connector;
import oshi.hardware.Display;
import oshi.hardware.DisplayMode;
import oshi.hardware.common.platform.windows.WindowsDisplay;
import oshi.jna.ByRef.CloseableIntByReference;
import oshi.jna.Struct.CloseableSpDeviceInterfaceData;
import oshi.jna.Struct.CloseableSpDevinfoData;
import oshi.jna.platform.windows.User32;
import oshi.util.Constants;

/**
 * A Display
 */
@Immutable
final class WindowsDisplayJNA extends WindowsDisplay {

    private static final Logger LOG = LoggerFactory.getLogger(WindowsDisplayJNA.class);

    private static final SetupApi SU = SetupApi.INSTANCE;
    private static final Advapi32 ADV = Advapi32.INSTANCE;

    private static final Guid.GUID GUID_DEVINTERFACE_MONITOR = new Guid.GUID("E6F07B5F-EE97-4a90-B076-33F57BF4EAA7");

    // SP_DEVICE_INTERFACE_DETAIL_DATA.cbSize must be 8 on 64-bit and 6 on 32-bit; the DevicePath follows the 4-byte
    // cbSize field.
    private static final int DETAIL_CBSIZE = Native.POINTER_SIZE == 8 ? 8 : 6;
    private static final int DETAIL_PATH_OFFSET = 4;

    // Attempts allowed for the QueryDisplayConfig size-then-query pair, in case the topology changes between them.
    private static final int QDC_ATTEMPTS = 3;

    /**
     * Constructor for WindowsDisplay.
     *
     * @param edid      a byte array representing a display EDID
     * @param connector the connector this display is attached to, or {@code null} if it cannot be resolved
     */
    WindowsDisplayJNA(byte[] edid, @Nullable Connector connector) {
        super(edid, connector);
        LOG.debug("Initialized WindowsDisplay");
    }

    /**
     * Gets Display Information
     *
     * @return A list of Display objects representing monitors, etc.
     */
    public static List<Display> getDisplays() {
        List<Display> displays = new ArrayList<>();

        // Map every active connector's device interface path to its connector (e.g. "HDMI", "DisplayPort-1") and mode.
        Map<String, Connector> connectorByPath = queryConnectors();

        HANDLE hDevInfo = SU.SetupDiGetClassDevs(GUID_DEVINTERFACE_MONITOR, null, null,
                SetupApi.DIGCF_PRESENT | SetupApi.DIGCF_DEVICEINTERFACE);
        if (!hDevInfo.equals(WinBase.INVALID_HANDLE_VALUE)) {
            try (CloseableSpDeviceInterfaceData deviceInterfaceData = new CloseableSpDeviceInterfaceData();
                    CloseableSpDevinfoData info = new CloseableSpDevinfoData()) {
                deviceInterfaceData.cbSize = deviceInterfaceData.size();

                for (int memberIndex = 0; SU.SetupDiEnumDeviceInfo(hDevInfo, memberIndex, info); memberIndex++) {
                    HKEY key = SU.SetupDiOpenDevRegKey(hDevInfo, info, SetupApi.DICS_FLAG_GLOBAL, 0, SetupApi.DIREG_DEV,
                            WinNT.KEY_QUERY_VALUE);
                    try {
                        byte[] edid = new byte[1];

                        try (CloseableIntByReference pType = new CloseableIntByReference();
                                CloseableIntByReference lpcbData = new CloseableIntByReference()) {
                            if (ADV.RegQueryValueEx(key, "EDID", 0, pType, edid,
                                    lpcbData) == WinError.ERROR_MORE_DATA) {
                                edid = new byte[lpcbData.getValue()];
                                if (ADV.RegQueryValueEx(key, "EDID", 0, pType, edid,
                                        lpcbData) == WinError.ERROR_SUCCESS) {
                                    Connector connector = lookupConnector(hDevInfo, info, deviceInterfaceData,
                                            connectorByPath);
                                    displays.add(new WindowsDisplayJNA(edid, connector));
                                }
                            }
                        }
                    } finally {
                        Advapi32.INSTANCE.RegCloseKey(key);
                    }
                }
            } finally {
                SU.SetupDiDestroyDeviceInfoList(hDevInfo);
            }
        }
        return displays;
    }

    // Resolves the connector for the current device by fetching its device interface path and looking it up in the
    // CCD-derived map. Returns null if the interface or path cannot be obtained or is not an active connector.
    private static @Nullable Connector lookupConnector(HANDLE hDevInfo, CloseableSpDevinfoData info,
            CloseableSpDeviceInterfaceData deviceInterfaceData, Map<String, Connector> connectorByPath) {
        if (!SU.SetupDiEnumDeviceInterfaces(hDevInfo, info.getPointer(), GUID_DEVINTERFACE_MONITOR, 0,
                deviceInterfaceData)) {
            return null;
        }
        String path = getDeviceInterfacePath(hDevInfo, deviceInterfaceData);
        if (path == null) {
            return null;
        }
        return connectorByPath.get(DisplayConnector.normalizePath(path));
    }

    // Two-call SetupDiGetDeviceInterfaceDetail: first for the required size, then to read the device path.
    private static @Nullable String getDeviceInterfacePath(HANDLE hDevInfo,
            CloseableSpDeviceInterfaceData deviceInterfaceData) {
        try (CloseableIntByReference requiredSize = new CloseableIntByReference()) {
            SU.SetupDiGetDeviceInterfaceDetail(hDevInfo, deviceInterfaceData, null, 0, requiredSize, null);
            int size = requiredSize.getValue();
            if (size <= DETAIL_PATH_OFFSET) {
                return null;
            }
            try (Memory detail = new Memory(size)) {
                detail.clear();
                detail.setInt(0, DETAIL_CBSIZE);
                if (SU.SetupDiGetDeviceInterfaceDetail(hDevInfo, deviceInterfaceData, detail, size, requiredSize,
                        null)) {
                    return detail.getWideString(DETAIL_PATH_OFFSET);
                }
            }
        }
        return null;
    }

    // Builds a map from normalized monitor device interface path to connector and mode, from the CCD active paths. A
    // topology change between sizing and querying the buffers makes QueryDisplayConfig fail with
    // ERROR_INSUFFICIENT_BUFFER, which is retryable by re-sizing.
    private static Map<String, Connector> queryConnectors() {
        User32 u32 = User32.INSTANCE;
        for (int attempt = 0; attempt < QDC_ATTEMPTS; attempt++) {
            Map<String, Connector> map = queryConnectorsOnce(u32);
            if (map != null) {
                return map;
            }
        }
        LOG.debug("Display configuration kept changing; unable to map connectors.");
        return new HashMap<>();
    }

    // Returns null if the buffers were too small and the caller should re-size and retry.
    private static @Nullable Map<String, Connector> queryConnectorsOnce(User32 u32) {
        Map<String, Connector> map = new HashMap<>();
        try (CloseableIntByReference numPaths = new CloseableIntByReference();
                CloseableIntByReference numModes = new CloseableIntByReference()) {
            if (u32.GetDisplayConfigBufferSizes(DisplayConnector.QDC_ONLY_ACTIVE_PATHS, numPaths,
                    numModes) != WinError.ERROR_SUCCESS) {
                return map;
            }
            int pathCount = numPaths.getValue();
            int modeCount = numModes.getValue();
            if (pathCount <= 0) {
                return map;
            }
            try (Memory paths = new Memory((long) pathCount * DisplayConnector.PATH_INFO_SIZE);
                    Memory modes = new Memory(Math.max(1L, (long) modeCount * DisplayConnector.MODE_INFO_SIZE))) {
                paths.clear();
                modes.clear();
                int rc = u32.QueryDisplayConfig(DisplayConnector.QDC_ONLY_ACTIVE_PATHS, numPaths, paths, numModes,
                        modes, null);
                if (rc == WinError.ERROR_INSUFFICIENT_BUFFER) {
                    return null;
                }
                if (rc != WinError.ERROR_SUCCESS) {
                    return map;
                }
                int actualPaths = numPaths.getValue();
                int actualModes = numModes.getValue();
                for (int i = 0; i < actualPaths; i++) {
                    long base = (long) i * DisplayConnector.PATH_INFO_SIZE;
                    int flags = paths.getInt(base + DisplayConnector.PATH_FLAGS_OFFSET);
                    if ((flags & DisplayConnector.PATH_ACTIVE) == 0) {
                        continue;
                    }
                    long adapterId = paths.getLong(base + DisplayConnector.PATH_TARGET_ADAPTER_ID_OFFSET);
                    int targetId = paths.getInt(base + DisplayConnector.PATH_TARGET_ID_OFFSET);
                    DisplayMode mode = DisplayConnector.readMode(off -> paths.getInt(base + off), modes::getInt,
                            actualModes);
                    addConnector(map, u32, adapterId, targetId, mode);
                }
            }
        }
        return map;
    }

    // Fetches one target's DISPLAYCONFIG_TARGET_DEVICE_NAME and records its device path -> connector.
    private static void addConnector(Map<String, Connector> map, User32 u32, long adapterId, int targetId,
            @Nullable DisplayMode mode) {
        try (Memory tdn = new Memory(DisplayConnector.TARGET_DEVICE_NAME_SIZE)) {
            tdn.clear();
            tdn.setInt(0, DisplayConnector.DEVICE_INFO_GET_TARGET_NAME);
            tdn.setInt(DisplayConnector.TDN_HEADER_SIZE_OFFSET, DisplayConnector.TARGET_DEVICE_NAME_SIZE);
            tdn.setLong(DisplayConnector.TDN_HEADER_ADAPTER_ID_OFFSET, adapterId);
            tdn.setInt(DisplayConnector.TDN_HEADER_ID_OFFSET, targetId);
            if (u32.DisplayConfigGetDeviceInfo(tdn) != WinError.ERROR_SUCCESS) {
                return;
            }
            int outputTechnology = tdn.getInt(DisplayConnector.TDN_OUTPUT_TECHNOLOGY_OFFSET);
            int connectorInstance = tdn.getInt(DisplayConnector.TDN_CONNECTOR_INSTANCE_OFFSET);
            String key = DisplayConnector
                    .normalizePath(tdn.getWideString(DisplayConnector.TDN_MONITOR_DEVICE_PATH_OFFSET));
            if (!Constants.UNKNOWN.equals(key)) {
                map.put(key, new Connector(outputTechnology, connectorInstance, mode));
            }
        }
    }
}
