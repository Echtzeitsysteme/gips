/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.os.linux;

import static com.sun.jna.platform.unix.Resource.RLIMIT_NOFILE;
import static oshi.jna.platform.unix.CLibrary.RUSAGE_SELF;

import org.jspecify.annotations.Nullable;

import com.sun.jna.platform.unix.Resource;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.jna.platform.linux.LinuxLibc;
import oshi.software.common.os.linux.LinuxOSProcess;
import oshi.software.common.os.linux.LinuxOperatingSystem;

/**
 * JNA-based Linux OS process. Implements {@code getrlimit} and {@code getrusage} via JNA.
 */
@ThreadSafe
public class LinuxOSProcessJNA extends LinuxOSProcess {

    public LinuxOSProcessJNA(int pid, LinuxOperatingSystem os) {
        super(pid, os);
    }

    @Override
    protected long @Nullable [] queryContextSwitches() {
        LinuxLibc.Rusage rusage = new LinuxLibc.Rusage();
        if (0 == LinuxLibc.INSTANCE.getrusage(RUSAGE_SELF, rusage)) {
            return new long[] { rusage.ru_nvcsw.longValue(), rusage.ru_nivcsw.longValue() };
        }
        return null;
    }

    @Override
    protected long queryRlimitSoft() {
        final Resource.Rlimit rlimit = new Resource.Rlimit();
        if (0 == LinuxLibc.INSTANCE.getrlimit(RLIMIT_NOFILE, rlimit)) {
            return rlimit.rlim_cur;
        }
        return getProcessOpenFileLimit(getProcessID(), 1);
    }

    @Override
    protected long queryRlimitHard() {
        final Resource.Rlimit rlimit = new Resource.Rlimit();
        if (0 == LinuxLibc.INSTANCE.getrlimit(RLIMIT_NOFILE, rlimit)) {
            return rlimit.rlim_max;
        }
        return getProcessOpenFileLimit(getProcessID(), 2);
    }
}
