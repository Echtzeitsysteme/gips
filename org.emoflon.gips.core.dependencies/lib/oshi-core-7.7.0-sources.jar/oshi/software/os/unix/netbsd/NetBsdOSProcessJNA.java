/*
 * Copyright 2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.software.os.unix.netbsd;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.platform.unix.LibCAPI.size_t;
import com.sun.jna.platform.unix.Resource;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.jna.ByRef.CloseableSizeTByReference;
import oshi.jna.platform.unix.NetBsdLibc;
import oshi.software.common.os.unix.bsd.BsdPsKeyword;
import oshi.software.common.os.unix.netbsd.NetBsdOSProcess;
import oshi.software.common.os.unix.netbsd.NetBsdOperatingSystem;
import oshi.util.platform.unix.netbsd.NetBsdSysctlUtil;

/**
 * An OSProcess for NetBSD that uses JNA native calls for the process open-file limits ({@code getrlimit}) and for
 * reading the environment of other processes ({@code kern.proc_args}) when the JNA native library is available, and
 * falls back to the command-line {@link NetBsdOSProcess} implementation otherwise.
 */
@ThreadSafe
public class NetBsdOSProcessJNA extends NetBsdOSProcess {

    private static final Logger LOG = LoggerFactory.getLogger(NetBsdOSProcessJNA.class);

    // KERN_PROC_ARGS sysctl selectors from <sys/sysctl.h>
    private static final int KERN_PROC_ARGS = 48;
    private static final int KERN_PROC_ENV = 3;

    // Maximum size of process argument/environment data (kern.argmax); 0 if JNA or the call is unavailable.
    private static final int ARGMAX;
    static {
        int argmax = 0;
        if (NetBsdSysctlUtil.JNA_AVAILABLE) {
            int[] mib = { NetBsdLibc.CTL_KERN, NetBsdLibc.KERN_ARGMAX };
            try (Memory m = new Memory(Integer.BYTES);
                    CloseableSizeTByReference size = new CloseableSizeTByReference(Integer.BYTES)) {
                if (NetBsdLibc.INSTANCE.sysctl(mib, mib.length, m, size, null, size_t.ZERO) == 0) {
                    argmax = m.getInt(0);
                } else {
                    LOG.warn("Failed sysctl call for kern.argmax. Error code: {}", Native.getLastError());
                }
            }
        }
        ARGMAX = argmax;
    }

    public NetBsdOSProcessJNA(int pid, Map<BsdPsKeyword, String> psMap, NetBsdOperatingSystem os) {
        super(pid, psMap, os);
    }

    @Override
    protected long queryRlimitNofile(boolean soft) {
        if (!NetBsdSysctlUtil.JNA_AVAILABLE) {
            return super.queryRlimitNofile(soft);
        }
        Resource.Rlimit rlimit = new Resource.Rlimit();
        if (NetBsdLibc.INSTANCE.getrlimit(NetBsdLibc.RLIMIT_NOFILE, rlimit) != 0) {
            return -1L;
        }
        return soft ? rlimit.rlim_cur : rlimit.rlim_max;
    }

    @Override
    protected byte[] queryEnvironmentBytes() {
        // Other processes' environment is only accessible natively
        if (!NetBsdSysctlUtil.JNA_AVAILABLE || ARGMAX <= 0) {
            return super.queryEnvironmentBytes();
        }
        int[] mib = { NetBsdLibc.CTL_KERN, KERN_PROC_ARGS, getProcessID(), KERN_PROC_ENV };
        try (Memory m = new Memory(ARGMAX); CloseableSizeTByReference size = new CloseableSizeTByReference(ARGMAX)) {
            if (NetBsdLibc.INSTANCE.sysctl(mib, mib.length, m, size, null, size_t.ZERO) == 0) {
                return m.getByteArray(0, (int) size.getValue().longValue());
            }
        }
        return super.queryEnvironmentBytes();
    }
}
