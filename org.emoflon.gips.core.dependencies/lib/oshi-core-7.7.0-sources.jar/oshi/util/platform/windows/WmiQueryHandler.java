/*
 * Copyright 2019-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.util.platform.windows;

import java.lang.reflect.InvocationTargetException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeoutException;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.platform.win32.COM.COMException;
import com.sun.jna.platform.win32.COM.COMUtils;
import com.sun.jna.platform.win32.COM.Wbemcli;
import com.sun.jna.platform.win32.COM.WbemcliUtil;
import com.sun.jna.platform.win32.Ole32;
import com.sun.jna.platform.win32.WinError;
import com.sun.jna.platform.win32.WinNT;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.common.windows.wmi.WmiQueryExecutor;
import oshi.util.GlobalConfig;

/**
 * Utility to handle WMI Queries. Designed to be extended with user-customized behavior.
 */
@ThreadSafe
public class WmiQueryHandler implements WmiQueryExecutor {

    private static final Logger LOG = LoggerFactory.getLogger(WmiQueryHandler.class);

    private static int globalTimeout = GlobalConfig.get(GlobalConfig.OSHI_UTIL_WMI_TIMEOUT, -1);

    static {
        if (globalTimeout == 0 || globalTimeout < -1) {
            throw new GlobalConfig.PropertyException(GlobalConfig.OSHI_UTIL_WMI_TIMEOUT);
        }
    }

    // Timeout for WMI queries
    private volatile int wmiTimeout = globalTimeout;

    // Cache failed wmi classes
    private final Set<String> failedWmiClassNames = ConcurrentHashMap.newKeySet();

    // Preferred threading model
    private volatile int comThreading = Ole32.COINIT_MULTITHREADED;

    // Track initialization of Security
    private volatile boolean securityInitialized = false;

    private static final Class<?>[] EMPTY_CLASS_ARRAY = new Class<?>[0];
    private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];

    private static final String COM_EXCEPTION_FMT = "COM exception querying {}, which might not be on your system."
            + " Will not attempt to query it again. Error was {}";

    // Factory to create this or a subclass
    private static @Nullable Class<? extends WmiQueryHandler> customClass = null;

    /** Creates the WMI query handler. Subclasses may override via {@link #setInstanceClass(Class)}. */
    protected WmiQueryHandler() {
    }

    /**
     * Factory method to create an instance of this class. To override this class, use {@link #setInstanceClass(Class)}
     * to define a subclass which extends {@link oshi.util.platform.windows.WmiQueryHandler}.
     *
     * @return An instance of this class or a class defined by {@link #setInstanceClass(Class)}
     */
    public static synchronized @Nullable WmiQueryHandler createInstance() {
        if (customClass == null) {
            return new WmiQueryHandler();
        }
        try {
            return customClass.getConstructor(EMPTY_CLASS_ARRAY).newInstance(EMPTY_OBJECT_ARRAY);
        } catch (NoSuchMethodException | SecurityException e) {
            LOG.error("Failed to find or access a no-arg constructor for {}", customClass);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException
                | InvocationTargetException e) {
            LOG.error("Failed to create a new instance of {}", customClass);
        }
        return null;
    }

    /**
     * Define a subclass to be instantiated by {@link #createInstance()}. The class must extend
     * {@link oshi.util.platform.windows.WmiQueryHandler}.
     *
     * @param instanceClass The class to instantiate with {@link #createInstance()}.
     */
    public static synchronized void setInstanceClass(Class<? extends WmiQueryHandler> instanceClass) {
        customClass = instanceClass;
    }

    /**
     * Query WMI for values. Makes no assumptions on whether the user has previously initialized COM.
     *
     * @param <T>   WMI queries use an Enum to identify the fields to query, and use the enum values as keys to retrieve
     *              the results.
     * @param query A WmiQuery object encapsulating the namespace, class, and properties
     * @return a WmiResult object containing the query results, wrapping an EnumMap
     */
    public <T extends Enum<T>> WbemcliUtil.WmiResult<T> queryWMI(WbemcliUtil.WmiQuery<T> query) {
        return queryWMI(query, true);
    }

    /**
     * Query WMI for values.
     *
     * @param <T>     WMI queries use an Enum to identify the fields to query, and use the enum values as keys to
     *                retrieve the results.
     * @param query   A WmiQuery object encapsulating the namespace, class, and properties
     * @param initCom Whether to initialize COM. If {@code true}, initializes COM before the query and uninitializes
     *                after. If {@code false}, assumes the user has initialized COM separately. This can improve WMI
     *                query performance.
     * @return a WmiResult object containing the query results, wrapping an EnumMap
     */
    public <T extends Enum<T>> WbemcliUtil.WmiResult<T> queryWMI(WbemcliUtil.WmiQuery<T> query, boolean initCom) {
        WbemcliUtil.WmiResult<T> result = WbemcliUtil.INSTANCE.new WmiResult<>(query.getPropertyEnum());
        if (failedWmiClassNames.contains(query.getWmiClassName())) {
            return result;
        }
        boolean comInit = false;
        try {
            if (initCom) {
                comInit = initCOM();
            }
            result = query.execute(wmiTimeout);
        } catch (COMException e) {
            // Ignore any exceptions with OpenHardwareMonitor or LibreHardwareMonitor
            if (!WmiUtil.OHM_NAMESPACE.equals(query.getNameSpace())
                    && !WmiUtil.LHM_NAMESPACE.equals(query.getNameSpace())) {
                final int hresult = e.getHresult() == null ? -1 : e.getHresult().intValue();
                switch (hresult) {
                    case Wbemcli.WBEM_E_INVALID_NAMESPACE:
                        LOG.warn("COM exception: Invalid Namespace {}", query.getNameSpace());
                        break;
                    case Wbemcli.WBEM_E_INVALID_CLASS:
                        LOG.warn("COM exception: Invalid Class {}", query.getWmiClassName());
                        break;
                    case Wbemcli.WBEM_E_INVALID_QUERY:
                        LOG.warn("COM exception: Invalid Query: {}", WmiUtil.queryToString(query));
                        break;
                    default:
                        handleComException(query, e);
                        break;
                }
                failedWmiClassNames.add(query.getWmiClassName());
            }
        } catch (TimeoutException e) {
            LOG.warn("WMI query timed out after {} ms: {}", wmiTimeout, WmiUtil.queryToString(query));
        } finally {
            if (comInit) {
                unInitCOM();
            }
        }
        return result;
    }

    @Override
    public <T extends Enum<T>> oshi.driver.common.windows.wmi.WmiResult<T> queryWMI(
            oshi.driver.common.windows.wmi.WmiQuery<T> query) {
        return queryWMI(query, true);
    }

    @Override
    public <T extends Enum<T>> oshi.driver.common.windows.wmi.WmiResult<T> queryWMI(
            oshi.driver.common.windows.wmi.WmiQuery<T> query, boolean initCom) {
        WbemcliUtil.WmiQuery<T> jnaQuery = new WbemcliUtil.WmiQuery<>(query.getNameSpace(), query.getWmiClassName(),
                query.getPropertyEnum());
        WbemcliUtil.WmiResult<T> jnaResult = queryWMI(jnaQuery, initCom);
        return new oshi.driver.common.windows.wmi.WmiResult<T>() {
            @Override
            public int getResultCount() {
                return jnaResult.getResultCount();
            }

            @Override
            public Object getValue(T property, int index) {
                return jnaResult.getValue(property, index);
            }

            @Override
            public int getVtType(T property) {
                return jnaResult.getVtType(property);
            }

            @Override
            public int getCIMType(T property) {
                return jnaResult.getCIMType(property);
            }
        };
    }

    /**
     * COM Exception handler. Logs at debug level for known-optional classes, otherwise warns.
     *
     * @param query a {@link com.sun.jna.platform.win32.COM.WbemcliUtil.WmiQuery} object.
     * @param ex    a {@link com.sun.jna.platform.win32.COM.COMException} object.
     */
    protected void handleComException(WbemcliUtil.WmiQuery<?> query, COMException ex) {
        String className = query.getWmiClassName();
        Integer hresult = ex.getHresult() == null ? null : ex.getHresult().intValue();
        if ("MSAcpi_ThermalZoneTemperature".equals(className)) {
            LOG.debug(COM_EXCEPTION_FMT, className, hresult, ex);
        } else {
            LOG.warn(COM_EXCEPTION_FMT, className, hresult, ex);
        }
    }

    /**
     * Initializes COM library and sets security to impersonate the local user
     *
     * @return True if COM was initialized and needs to be uninitialized, false otherwise
     * @throws COMException if COM initialization fails with an unexpected error
     */
    public boolean initCOM() {
        // Step 1: --------------------------------------------------
        // Initialize COM. ------------------------------------------
        int threading = getComThreading();
        boolean comInit = initCOM(threading);
        if (!comInit) {
            // Only switch if another thread hasn't already switched away from our value
            int switched = switchComThreadingFrom(threading);
            if (switched != threading) {
                comInit = initCOM(switched);
            }
        }
        // Step 2: --------------------------------------------------
        // Set general COM security levels --------------------------
        if (comInit && !isSecurityInitialized()) {
            WinNT.HRESULT hres = Ole32.INSTANCE.CoInitializeSecurity(null, -1, null, null,
                    Ole32.RPC_C_AUTHN_LEVEL_DEFAULT, Ole32.RPC_C_IMP_LEVEL_IMPERSONATE, null, Ole32.EOAC_NONE, null);
            // If security already initialized we get RPC_E_TOO_LATE
            // This can be safely ignored
            if (COMUtils.FAILED(hres) && hres.intValue() != WinError.RPC_E_TOO_LATE) {
                Ole32.INSTANCE.CoUninitialize();
                throw new COMException("Failed to initialize security.", hres);
            }
            securityInitialized = true;
        }
        return comInit;
    }

    /**
     * Initializes COM with a specific threading model
     *
     * @param coInitThreading The threading model
     * @return True if COM was initialized and needs to be uninitialized, false otherwise
     * @throws COMException if COM initialization fails with an unexpected error
     */
    protected boolean initCOM(int coInitThreading) {
        WinNT.HRESULT hres = Ole32.INSTANCE.CoInitializeEx(null, coInitThreading);
        switch (hres.intValue()) {
            // Successful local initialization (S_OK) or was already initialized
            // (S_FALSE) but still needs uninit
            case COMUtils.S_OK:
            case COMUtils.S_FALSE:
                return true;
            // COM was already initialized with a different threading model
            case WinError.RPC_E_CHANGED_MODE:
                return false;
            // E_INVALIDARG, E_OUTOFMEMORY, or E_UNEXPECTED are possible per the docs
            default:
                throw new COMException("Failed to initialize COM library.", hres);
        }
    }

    /**
     * UnInitializes COM library. This should be called once for every successful call to initCOM.
     */
    public void unInitCOM() {
        Ole32.INSTANCE.CoUninitialize();
    }

    /**
     * Returns the current threading model for COM initialization, as OSHI is required to match if an external program
     * has COM initialized already.
     *
     * @return The current threading model
     */
    public synchronized int getComThreading() {
        return comThreading;
    }

    /**
     * Switches the current threading model for COM initialization, as OSHI is required to match if an external program
     * has COM initialized already.
     *
     * @return The new threading model after switching
     */
    public synchronized int switchComThreading() {
        if (comThreading == Ole32.COINIT_APARTMENTTHREADED) {
            comThreading = Ole32.COINIT_MULTITHREADED;
        } else {
            comThreading = Ole32.COINIT_APARTMENTTHREADED;
        }
        return comThreading;
    }

    /**
     * Switches the current threading model only if it still matches the expected value, avoiding a toggle race when
     * multiple threads call {@link #initCOM()} concurrently.
     *
     * @param expected the threading model observed before the failed initCOM attempt
     * @return the new threading model if switched, or the current value if already switched by another thread
     */
    public synchronized int switchComThreadingFrom(int expected) {
        if (comThreading != expected) {
            // Another thread already switched it, use the current value
            return comThreading;
        }
        return switchComThreading();
    }

    /**
     * Security only needs to be initialized once. This boolean identifies whether that has happened.
     *
     * @return Returns the securityInitialized.
     */
    public boolean isSecurityInitialized() {
        return securityInitialized;
    }

    /**
     * Gets the current WMI timeout. WMI queries will fail if they take longer than this number of milliseconds. A value
     * of -1 is infinite (no timeout).
     *
     * @return Returns the current value of wmiTimeout.
     */
    public int getWmiTimeout() {
        return wmiTimeout;
    }

    /**
     * Sets the WMI timeout. WMI queries will fail if they take longer than this number of milliseconds.
     *
     * @param wmiTimeout The wmiTimeout to set, in milliseconds. To disable timeouts, set timeout as -1 (infinite).
     */
    public void setWmiTimeout(int wmiTimeout) {
        this.wmiTimeout = wmiTimeout;
    }
}
