/*
 * Copyright (c) 2016-2022 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
/**
 * Provides extensions of JNA libraries for Unix. These classes should be considered non-API as they may be removed
 * if/when their code is incorporated into the JNA project.
 */
@NullUnmarked
package oshi.jna.platform.unix;

import org.jspecify.annotations.NullUnmarked;
