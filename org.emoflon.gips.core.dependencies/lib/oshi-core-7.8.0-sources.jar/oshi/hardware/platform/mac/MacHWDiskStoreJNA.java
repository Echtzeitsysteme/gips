/*
 * Copyright 2020-2026 The OSHI Project Contributors
 * SPDX-License-Identifier: MIT
 */
package oshi.hardware.platform.mac;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.mac.CoreFoundation;
import com.sun.jna.platform.mac.CoreFoundation.CFBooleanRef;
import com.sun.jna.platform.mac.CoreFoundation.CFDictionaryRef;
import com.sun.jna.platform.mac.CoreFoundation.CFIndex;
import com.sun.jna.platform.mac.CoreFoundation.CFMutableDictionaryRef;
import com.sun.jna.platform.mac.CoreFoundation.CFNumberRef;
import com.sun.jna.platform.mac.CoreFoundation.CFStringRef;
import com.sun.jna.platform.mac.CoreFoundation.CFTypeRef;
import com.sun.jna.platform.mac.DiskArbitration;
import com.sun.jna.platform.mac.DiskArbitration.DADiskRef;
import com.sun.jna.platform.mac.DiskArbitration.DASessionRef;
import com.sun.jna.platform.mac.IOKit;
import com.sun.jna.platform.mac.IOKit.IOIterator;
import com.sun.jna.platform.mac.IOKit.IORegistryEntry;
import com.sun.jna.platform.mac.IOKitUtil;
import com.sun.jna.platform.mac.IOReturnException;
import com.sun.jna.platform.mac.SystemB;
import com.sun.jna.platform.mac.SystemB.Statfs;

import oshi.annotation.concurrent.ThreadSafe;
import oshi.driver.mac.disk.Fsstat;
import oshi.hardware.HWDiskStore;
import oshi.hardware.HWPartition;
import oshi.hardware.common.platform.mac.MacHWDiskStore;
import oshi.util.ParseUtil;
import oshi.util.platform.mac.CFUtil;

/**
 * Mac hard disk implementation.
 */
@ThreadSafe
public final class MacHWDiskStoreJNA extends MacHWDiskStore {

    private static final CoreFoundation CF = CoreFoundation.INSTANCE;
    private static final DiskArbitration DA = DiskArbitration.INSTANCE;

    private static final Logger LOG = LoggerFactory.getLogger(MacHWDiskStoreJNA.class);

    private MacHWDiskStoreJNA(String name, String model, String serial, long size, String diskType,
            Optional<List<String>> backingStores, DASessionRef session, Map<String, String> mountPointMap,
            Map<CFKey, CFStringRef> cfKeyMap) {
        super(name, model, serial, size, diskType, backingStores);
        updateDiskStats(session, mountPointMap, cfKeyMap);
    }

    @Override
    public synchronized boolean updateAttributes() {
        // Open a session and create CFStrings
        DASessionRef session = DA.DASessionCreate(CF.CFAllocatorGetDefault());
        if (session == null) {
            LOG.error("Unable to open session to DiskArbitration framework.");
            return false;
        }
        try {
            Map<CFKey, CFStringRef> cfKeyMap = mapCFKeys();
            try {
                // Execute the update
                return updateDiskStats(session, Fsstat.queryPartitionToMountMap(), cfKeyMap);
            } finally {
                for (CFTypeRef value : cfKeyMap.values()) {
                    value.release();
                }
            }
        } finally {
            session.release();
        }
    }

    private boolean updateDiskStats(DASessionRef session, Map<String, String> mountPointMap,
            Map<CFKey, CFStringRef> cfKeyMap) {
        // Now look up the device using the BSD Name to get its
        // statistics
        String bsdName = getName();
        CFMutableDictionaryRef matchingDict = IOKitUtil.getBSDNameMatchingDict(bsdName);
        if (matchingDict != null) {
            // search for all IOservices that match the bsd name
            IOIterator driveListIter = IOKitUtil.getMatchingServices(matchingDict);
            if (driveListIter != null) {
                // getMatchingServices releases matchingDict
                boolean updated = false;
                IORegistryEntry drive = driveListIter.next();
                // Should only match one drive
                if (drive != null) {
                    // Should be an IOMedia object with a parent
                    // IOBlockStorageDriver or AppleAPFSContainerScheme object
                    // Get the properties from the parent
                    if (drive.conformsTo(IO_MEDIA)) {
                        IORegistryEntry parent = drive.getParentEntry("IOService");
                        if (parent != null && (parent.conformsTo("IOBlockStorageDriver")
                                || parent.conformsTo("AppleAPFSContainerScheme"))) {
                            CFMutableDictionaryRef properties = parent.createCFProperties();
                            // We now have a properties object with the
                            // statistics we need on it. Fetch them
                            Pointer result = properties.getValue(cfKeyMap.get(CFKey.STATISTICS));
                            CFDictionaryRef statistics = new CFDictionaryRef(result);
                            this.timeStamp = System.currentTimeMillis();

                            // Now get the stats we want
                            result = statistics.getValue(cfKeyMap.get(CFKey.READ_OPS));
                            CFNumberRef stat = new CFNumberRef(result);
                            this.reads = stat.longValue();
                            result = statistics.getValue(cfKeyMap.get(CFKey.READ_BYTES));
                            stat.setPointer(result);
                            this.readBytes = stat.longValue();

                            result = statistics.getValue(cfKeyMap.get(CFKey.WRITE_OPS));
                            stat.setPointer(result);
                            this.writes = stat.longValue();
                            result = statistics.getValue(cfKeyMap.get(CFKey.WRITE_BYTES));
                            stat.setPointer(result);
                            this.writeBytes = stat.longValue();

                            // Total time is in nanoseconds. Add read+write
                            // and convert total to ms
                            final Pointer readTimeResult = statistics.getValue(cfKeyMap.get(CFKey.READ_TIME));
                            final Pointer writeTimeResult = statistics.getValue(cfKeyMap.get(CFKey.WRITE_TIME));
                            // AppleAPFSContainerScheme does not have timer statistics
                            if (readTimeResult != null && writeTimeResult != null) {
                                stat.setPointer(readTimeResult);
                                long xferTime = stat.longValue();
                                stat.setPointer(writeTimeResult);
                                xferTime += stat.longValue();
                                this.transferTime = xferTime / 1_000_000L;
                            }

                            properties.release();
                        } else {
                            // This is normal for FileVault drives, Fusion
                            // drives, and other virtual bsd names
                            LOG.debug("Unable to find block storage driver properties for {}", bsdName);
                        }
                        // Now get partitions for this disk.
                        List<HWPartition> partitions = new ArrayList<>();

                        CFMutableDictionaryRef properties = drive.createCFProperties();
                        // Partitions will match BSD Unit property
                        Pointer result = properties.getValue(cfKeyMap.get(CFKey.BSD_UNIT));
                        CFNumberRef bsdUnit = new CFNumberRef(result);
                        // We need a CFBoolean that's false.
                        // Whole disk has 'true' for Whole and 'false'
                        // for leaf; store the boolean false
                        result = properties.getValue(cfKeyMap.get(CFKey.LEAF));
                        CFBooleanRef cfFalse = new CFBooleanRef(result);
                        // create a matching dict for BSD Unit
                        CFMutableDictionaryRef propertyDict = CF.CFDictionaryCreateMutable(CF.CFAllocatorGetDefault(),
                                new CFIndex(0), null, null);
                        propertyDict.setValue(cfKeyMap.get(CFKey.BSD_UNIT), bsdUnit);
                        propertyDict.setValue(cfKeyMap.get(CFKey.WHOLE), cfFalse);
                        matchingDict = CF.CFDictionaryCreateMutable(CF.CFAllocatorGetDefault(), new CFIndex(0), null,
                                null);
                        matchingDict.setValue(cfKeyMap.get(CFKey.IO_PROPERTY_MATCH), propertyDict);

                        // search for IOservices that match the BSD Unit
                        // with whole=false; these are partitions
                        IOIterator serviceIterator = IOKitUtil.getMatchingServices(matchingDict);
                        // getMatchingServices releases matchingDict
                        properties.release();
                        propertyDict.release();

                        if (serviceIterator != null) {
                            // Iterate disks
                            IORegistryEntry sdService = IOKit.INSTANCE.IOIteratorNext(serviceIterator);
                            while (sdService != null) {
                                // look up the BSD Name
                                String partBsdName = sdService.getStringProperty("BSD Name");
                                String name = partBsdName;
                                String type = "";
                                String label = "";
                                // Get the DiskArbitration dictionary for
                                // this partition
                                DADiskRef disk = DA.DADiskCreateFromBSDName(CF.CFAllocatorGetDefault(), session,
                                        partBsdName);
                                if (disk != null) {
                                    CFDictionaryRef diskInfo = DA.DADiskCopyDescription(disk);
                                    if (diskInfo != null) {
                                        // get volume name from its key
                                        result = diskInfo.getValue(cfKeyMap.get(CFKey.DA_MEDIA_NAME));
                                        type = CFUtil.cfPointerToString(result);
                                        result = diskInfo.getValue(cfKeyMap.get(CFKey.DA_VOLUME_NAME));
                                        if (result == null) {
                                            name = type;
                                        } else {
                                            String volumeName = CFUtil.cfPointerToString(result);
                                            name = volumeName;
                                            label = volumeName;
                                        }
                                        diskInfo.release();
                                    }
                                    disk.release();
                                }
                                String mountPoint = mountPointMap.getOrDefault(partBsdName, "");
                                Long size = sdService.getLongProperty("Size");
                                Integer bsdMajor = sdService.getIntegerProperty("BSD Major");
                                Integer bsdMinor = sdService.getIntegerProperty("BSD Minor");
                                String uuid = sdService.getStringProperty("UUID");
                                partitions.add(new HWPartition(partBsdName, name, type,
                                        ParseUtil.getStringValueOrUnknown(uuid), label, size == null ? 0L : size,
                                        bsdMajor == null ? 0 : bsdMajor, bsdMinor == null ? 0 : bsdMinor, mountPoint));
                                // iterate
                                sdService.release();
                                sdService = IOKit.INSTANCE.IOIteratorNext(serviceIterator);
                            }
                            serviceIterator.release();
                        }
                        setPartitionList(Collections.unmodifiableList(partitions.stream()
                                .sorted(Comparator.comparing(HWPartition::getName)).collect(Collectors.toList())));
                        if (parent != null) {
                            parent.release();
                        }
                        updated = true;
                    } else {
                        LOG.error("Unable to find IOMedia device or parent for {}", bsdName);
                    }
                    drive.release();
                }
                driveListIter.release();
                return updated;
            }
        }
        return false;
    }

    /**
     * Gets the disks on this machine
     *
     * @return a list of {@link HWDiskStore} objects representing the disks
     */
    public static List<HWDiskStore> getDisks() {
        Map<String, String> mountPointMap = Fsstat.queryPartitionToMountMap();
        Map<CFKey, CFStringRef> cfKeyMap = mapCFKeys();

        List<HWDiskStore> diskList = new ArrayList<>();

        try {
            // Open a DiskArbitration session
            DASessionRef session = DA.DASessionCreate(CF.CFAllocatorGetDefault());
            if (session == null) {
                LOG.error("Unable to open session to DiskArbitration framework.");
                return Collections.emptyList();
            }
            try {

                // Get IOMedia objects representing whole drives
                List<String> bsdNames = new ArrayList<>();
                IOIterator iter = IOKitUtil.getMatchingServices(IO_MEDIA);
                if (iter != null) {
                    IORegistryEntry media = iter.next();
                    while (media != null) {
                        Boolean whole = media.getBooleanProperty(WHOLE);
                        if (whole != null && whole) {
                            DADiskRef disk = DA.DADiskCreateFromIOMedia(CF.CFAllocatorGetDefault(), session, media);
                            if (disk != null) {
                                String bsdName = DA.DADiskGetBSDName(disk);
                                if (bsdName != null) {
                                    bsdNames.add(bsdName);
                                }
                                disk.release();
                            }
                        }
                        media.release();
                        media = iter.next();
                    }
                    iter.release();
                }

                // Now iterate the bsdNames
                for (String bsdName : bsdNames) {
                    String model = "";
                    String serial = "";
                    long size = 0L;

                    // Get a reference to the disk - only matching /dev/disk*
                    String path = "/dev/" + bsdName;

                    // Get the DiskArbitration dictionary for this disk, which has model
                    // and size (capacity)
                    DADiskRef disk = DA.DADiskCreateFromBSDName(CF.CFAllocatorGetDefault(), session, path);
                    if (disk != null) {
                        CFDictionaryRef diskInfo = DA.DADiskCopyDescription(disk);
                        if (diskInfo != null) {
                            // Parse out model and size from their respective keys
                            Pointer result = diskInfo.getValue(cfKeyMap.get(CFKey.DA_DEVICE_MODEL));
                            model = CFUtil.cfPointerToString(result);
                            result = diskInfo.getValue(cfKeyMap.get(CFKey.DA_MEDIA_SIZE));
                            CFNumberRef sizePtr = new CFNumberRef(result);
                            size = sizePtr.longValue();
                            diskInfo.release();

                            // Read the serial from this disk's own block storage device; fall back to
                            // matching on the model for devices that do not publish it there
                            serial = queryDeviceSerial(bsdName);
                            if (serial.isEmpty() && !"Disk Image".equals(model)) {
                                CFStringRef modelNameRef = CFStringRef.createCFString(model);
                                CFMutableDictionaryRef propertyDict = CF.CFDictionaryCreateMutable(
                                        CF.CFAllocatorGetDefault(), new CFIndex(0), null, null);
                                propertyDict.setValue(cfKeyMap.get(CFKey.MODEL), modelNameRef);
                                CFMutableDictionaryRef matchingDict = CF.CFDictionaryCreateMutable(
                                        CF.CFAllocatorGetDefault(), new CFIndex(0), null, null);
                                matchingDict.setValue(cfKeyMap.get(CFKey.IO_PROPERTY_MATCH), propertyDict);

                                // search for all IOservices that match the model
                                IOIterator serviceIterator = IOKitUtil.getMatchingServices(matchingDict);
                                // getMatchingServices releases matchingDict
                                modelNameRef.release();
                                propertyDict.release();

                                if (serviceIterator != null) {
                                    IORegistryEntry sdService = serviceIterator.next();
                                    while (sdService != null) {
                                        // look up the serial number
                                        serial = sdService.getStringProperty("Serial Number");
                                        sdService.release();
                                        if (serial != null) {
                                            break;
                                        }
                                        sdService = serviceIterator.next();
                                    }
                                    serviceIterator.release();
                                }
                                if (serial == null) {
                                    serial = "";
                                }
                            }
                        }
                        disk.release();

                        // If empty, ignore
                        if (size <= 0) {
                            continue;
                        }
                        HWDiskStore diskStore = new MacHWDiskStoreJNA(bsdName, model.trim(), serial.trim(), size,
                                detectDiskType(bsdName), queryBackingStores(bsdName), session, mountPointMap, cfKeyMap);
                        diskList.add(diskStore);
                    }
                }
                return Collections.unmodifiableList(diskList);
            } finally {
                session.release();
            }
        } finally {
            for (CFTypeRef value : cfKeyMap.values()) {
                value.release();
            }
        }
    }

    /**
     * Temporarily cache pointers to keys. The values from this map must be released after use.}
     *
     * @return A map of keys in the {@link CFKey} enum to corresponding {@link CFStringRef}.
     */
    private static Map<CFKey, CFStringRef> mapCFKeys() {
        Map<CFKey, CFStringRef> keyMap = new EnumMap<>(CFKey.class);
        for (CFKey cfKey : CFKey.values()) {
            keyMap.put(cfKey, CFStringRef.createCFString(cfKey.getKey()));
        }
        return keyMap;
    }

    /**
     * Finds what a disk is built on by walking up the IOService plane from its IOMedia object to the first ancestor
     * that is either another media object or a disk image device. Reaching the platform expert without finding one
     * means the disk is not layered.
     *
     * @param bsdName the disk's BSD name
     * @return the backing stores, an empty list for a disk that is not layered, or empty if they could not be read
     */
    private static Optional<List<String>> queryBackingStores(String bsdName) {
        CFMutableDictionaryRef matchingDict = IOKitUtil.getBSDNameMatchingDict(bsdName);
        if (matchingDict == null) {
            return Optional.empty();
        }
        IOIterator iter = IOKitUtil.getMatchingServices(matchingDict);
        if (iter == null) {
            return Optional.empty();
        }
        try {
            IORegistryEntry media = iter.next();
            if (media == null) {
                return Optional.empty();
            }
            IORegistryEntry entry;
            try {
                entry = media.getParentEntry("IOService");
            } finally {
                media.release();
            }
            while (entry != null) {
                IORegistryEntry current = entry;
                try {
                    if (current.conformsTo(IO_MEDIA)) {
                        return mediaBackingStore(current.getStringProperty(BSD_NAME),
                                current.getBooleanProperty(WHOLE));
                    }
                    if (current.conformsTo(DISK_IMAGE_DEVICE)) {
                        String imageUrl = current.getStringProperty(DISK_IMAGE_URL);
                        return imageUrl == null ? Optional.empty()
                                : imageBackingStore(imageUrl, MacHWDiskStoreJNA::queryMountPoint);
                    }
                    if (current.conformsTo(LEGACY_DISK_IMAGE_DEVICE)) {
                        return Optional.empty();
                    }
                    if (current.conformsTo(PLATFORM_EXPERT)) {
                        return Optional.of(Collections.emptyList());
                    }
                    entry = current.getParentEntry("IOService");
                } finally {
                    current.release();
                }
            }
            // The walk ended below the platform expert, so a parent could not be read
            return Optional.empty();
        } catch (IOReturnException e) {
            LOG.debug("Unable to walk the IORegistry for {}", bsdName, e);
            return Optional.empty();
        } finally {
            iter.release();
        }
    }

    private static String queryMountPoint(String path) {
        Statfs fs = new Statfs();
        return SystemB.INSTANCE.statfs64(path, fs) == 0 ? Native.toString(fs.f_mntonname, StandardCharsets.UTF_8) : "";
    }

    private static String detectDiskType(String bsdName) {
        CFMutableDictionaryRef matchingDict = IOKitUtil.getBSDNameMatchingDict(bsdName);
        if (matchingDict == null) {
            return "Unknown";
        }
        IOIterator iter = IOKitUtil.getMatchingServices(matchingDict);
        if (iter == null) {
            return "Unknown";
        }
        try {
            IORegistryEntry media = iter.next();
            if (media == null) {
                return "Unknown";
            }
            try {
                // Check removable at the IOMedia level
                Boolean removable = media.getBooleanProperty("Removable");
                if (removable != null && removable) {
                    return "Removable";
                }
                return parseMediumType(queryDeviceCharacteristic(media, "Medium Type"));
            } finally {
                media.release();
            }
        } finally {
            iter.release();
        }
    }

    /**
     * Reads the {@code Serial Number} device characteristic of the block storage device backing a whole disk.
     *
     * @param bsdName the BSD name of the whole disk, such as {@code disk0}
     * @return the serial number, or an empty string if the device does not publish one
     */
    private static String queryDeviceSerial(String bsdName) {
        CFMutableDictionaryRef matchingDict = IOKitUtil.getBSDNameMatchingDict(bsdName);
        if (matchingDict == null) {
            return "";
        }
        IOIterator iter = IOKitUtil.getMatchingServices(matchingDict);
        if (iter == null) {
            return "";
        }
        try {
            IORegistryEntry media = iter.next();
            if (media == null) {
                return "";
            }
            try {
                return ParseUtil.getStringValueOrEmpty(queryDeviceCharacteristic(media, "Serial Number"));
            } finally {
                media.release();
            }
        } finally {
            iter.release();
        }
    }

    /**
     * Reads a device characteristic, such as {@code Medium Type} or {@code Serial Number}, by traversing up from the
     * IOMedia node to the block storage device, which is where the characteristics are published.
     *
     * @param media the IOMedia registry entry
     * @param key   the key in the device's {@code Device Characteristics} dictionary
     * @return the characteristic's string value, or {@code null} if any step of the traversal finds nothing
     */
    private static @Nullable String queryDeviceCharacteristic(IORegistryEntry media, String key) {
        // Traverse up: IOMedia -> IOBlockStorageDriver -> IOBlockStorageDevice
        IORegistryEntry driver = media.getParentEntry("IOService");
        if (driver == null) {
            return null;
        }
        try {
            IORegistryEntry device = driver.getParentEntry("IOService");
            if (device == null) {
                return null;
            }
            try {
                CFMutableDictionaryRef props = device.createCFProperties();
                if (props == null) {
                    return null;
                }
                try {
                    CFDictionaryRef characteristics = CFUtil.getDictionary(props, "Device Characteristics");
                    return characteristics == null ? null : CFUtil.getString(characteristics, key);
                } finally {
                    props.release();
                }
            } finally {
                device.release();
            }
        } finally {
            driver.release();
        }
    }

}
